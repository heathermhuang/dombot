import { readFileSync } from 'node:fs';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { Miniflare, convertV4MiniflareOptions } from 'miniflare';
import { Hono } from 'hono';
import { aesGcmCipher, EncryptedDocStore } from '../core/storage/encrypted';
import { runMigrations } from '../core/storage/migrations';
import { D1DocStore } from './storage/d1-doc-store';
import { MemoryDocStore } from '../core/storage/doc-store';
import { configureStore, hydrateStores } from '../core/storage/namespace';
import { emptyOwnerSite, selectedSite } from '../shared/owner-site';
import { sampleSite } from '../shared/owner-site.fixture';
import { emptyDraft, privateListing } from '../shared/publication';
import { PublicationStore, PublicationConflict } from './publication-store';
import { buildAuthConfig, createSession, type AuthConfig } from './auth';
import { deriveEncryptionKey } from './keys';
import { createPublicationRoutes } from './publication-routes';
import { publicationBackupMethods } from './publication-backup';
import {
  createPublicPortfolioRoutes,
  renderPortfolio,
} from './public-portfolio';

let mf: Miniflare;
let db: D1Database;
let store: PublicationStore;
let auth: AuthConfig;
let cookie: string;
let privateReads = 0;
const root = new Uint8Array(32).fill(7);
const origin = 'http://localhost';
const env = {
  DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
  DOMBOT_PASSWORD: 'test-password',
  DOMBOT_OWNER_SITE_V2: '',
};
const draft = {
  ...emptyDraft(),
  title: 'Test collection',
  contactEmail: 'owner@example.com',
  listings: [
    {
      ...privateListing('visible.com'),
      visibility: 'inquiry' as const,
      askingPrice: 200,
    },
    privateListing('private.com'),
  ],
};
let app: Hono<{ Bindings: Env; Variables: { auth: AuthConfig } }>;
const call = (
  path: string,
  method = 'GET',
  body?: unknown,
  authenticated = true,
  requestOrigin = origin,
) =>
  app.request(
    `${origin}${path}`,
    {
      method,
      headers: {
        ...(authenticated ? { Cookie: cookie } : {}),
        Origin: requestOrigin,
        'Content-Type': 'application/json',
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    },
    { ...env, DB: db } as Env,
  );

beforeAll(async () => {
  mf = new Miniflare(
    convertV4MiniflareOptions({
      workers: [
        {
          name: 'publication-test',
          modules: true,
          script: 'export default { fetch() { return new Response("ok"); } }',
          compatibilityDate: '2026-09-06',
          d1Databases: ['DB'],
        },
      ],
    }),
  );
  db = await mf.getD1Database('DB');
  await db.exec(
    readFileSync('migrations/0003_session_revocations.sql', 'utf8')
      .replace(/^--.*$/gm, '')
      .replace(/\n/g, ' '),
  );
  await db.exec(
    readFileSync(
      new URL('../../migrations/0002_publication.sql', import.meta.url),
      'utf8',
    )
      .replace(/^--.*$/gm, '')
      .replace(/\n/g, ' '),
  );
  const cipher = await aesGcmCipher(await deriveEncryptionKey(root));
  store = new PublicationStore(db, cipher);
  auth = await buildAuthConfig(env, root);
  cookie = `dombot_session=${await createSession(auth.sessionKey!)}`;
  app = new Hono();
  app.route('/', createPublicPortfolioRoutes());
  app.use('*', async (c, next) => {
    c.set('auth', auth);
    await next();
  });
  app.route(
    '/publishing',
    createPublicationRoutes(async (_c, next) => {
      privateReads++;
      await hydrateStores();
      await next();
    }),
  );
}, 30_000);
afterAll(async () => {
  await mf?.dispose();
});
beforeEach(async () => {
  await db.batch([
    db.prepare('DELETE FROM portfolio_drafts'),
    db.prepare('DELETE FROM published_portfolios'),
  ]);
  privateReads = 0;
  env.DOMBOT_OWNER_SITE_V2 = '';
  const memory = new MemoryDocStore();
  await memory.put('registrar-credentials', 'dynadot', {
    apiKey: 'NEVER_PUBLIC_CREDENTIAL',
    apiSecret: 'NEVER_PUBLIC_SECRET',
  });
  await memory.put('registrar-domains', 'dynadot', {
    fetchedAt: Date.now(),
    data: {
      lastSyncedAt: Date.now(),
      lastError: null,
      domains: [
        'visible.com',
        'private.com',
        'selected.example',
        'inquiries.example',
        'never-disclose.example',
      ].map((domainName) => ({
        domainName,
        registrar: 'dynadot',
        notes: 'NEVER_PUBLIC_NOTES',
        renewal: 15,
      })),
    },
  });
  configureStore(memory);
  await hydrateStores();
});

describe('publication database and HTTP boundary', () => {
  it('migrates sealed hosted data while preserving account proxy routes and publication rows', async () => {
    await db.exec(
      readFileSync(
        new URL('../../migrations/0001_docs.sql', import.meta.url),
        'utf8',
      )
        .replace(/^--.*$/gm, '')
        .replace(/\n/g, ' '),
    );
    const saved = await call('/publishing', 'PUT', { draft, revision: null });
    const { revision } = await saved.json();
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    const publicationRows = async () => ({
      draft: (await db.prepare('SELECT * FROM portfolio_drafts').all()).results,
      published: (await db.prepare('SELECT * FROM published_portfolios').all())
        .results,
    });
    const before = await publicationRows();
    const raw = new D1DocStore(db);
    const sealed = new EncryptedDocStore(
      raw,
      await aesGcmCipher(await deriveEncryptionKey(root)),
    );
    const accountId = '11111111-2222-4333-8444-555555555555';
    const proxyId = '22222222-3333-4444-8555-666666666666';
    const account = {
      id: accountId,
      registrar: 'namecheap',
      label: 'Secondary',
      proxyId,
    };
    const credentials = {
      username: 'test-user',
      apiKey: 'NEVER_PUBLIC_CREDENTIAL',
      clientIp: '9.9.9.10',
    };
    const proxy = {
      id: proxyId,
      url: 'http://user:NEVER_PUBLIC_SECRET@9.9.9.9:3128/',
      egressIp: '9.9.9.10',
    };
    await sealed.put('registrar-accounts', accountId, account);
    await sealed.put('credentials', accountId, credentials);
    await sealed.put('proxies', proxyId, proxy);
    await sealed.put('cache-portfolio', accountId, {
      fetchedAt: 123,
      data: {
        lastSyncedAt: 123,
        lastError: null,
        domains: [
          { domainName: 'visible.com', registrar: 'namecheap', accountId },
        ],
      },
    });
    await sealed.put('folders', 'assignments', {
      [`${accountId}:visible.com`]: '__archive__',
    });
    await sealed.put('pricing-overrides', `${accountId}:visible.com`, 25);
    const credentialCiphertext = await raw.get('credentials', accountId);
    const proxyCiphertext = await raw.get('proxies', proxyId);

    await runMigrations(raw, sealed);

    expect(await sealed.get('registrar-accounts', accountId)).toEqual(account);
    expect(await sealed.get('registrar-credentials', accountId)).toEqual(
      credentials,
    );
    expect(await sealed.get('registrar-proxies', proxyId)).toEqual(proxy);
    expect(await raw.get('registrar-credentials', accountId)).toEqual(
      credentialCiphertext,
    );
    expect(await raw.get('registrar-proxies', proxyId)).toEqual(
      proxyCiphertext,
    );
    expect(await sealed.get('registrar-domains', accountId)).toMatchObject({
      data: { domains: [{ domainName: 'visible.com', accountId }] },
    });
    expect(await sealed.list('domain-folders')).toEqual({
      'visible.com': '__hidden__',
    });
    expect(await sealed.get('domain-prices', 'visible.com')).toEqual({
      amount: '25.00',
      currency: 'USD',
    });
    expect(await publicationRows()).toEqual(before);
    const after = await raw.loadAll();
    await runMigrations(raw, sealed);
    expect(await raw.loadAll()).toEqual(after);
  });

  it('requires authentication for read, preview, save, publish and unpublish before private hydration', async () => {
    for (const [path, method] of [
      ['/publishing', 'GET'],
      ['/publishing/preview', 'GET'],
      ['/publishing', 'PUT'],
      ['/publishing/publish', 'POST'],
      ['/publishing/unpublish', 'POST'],
    ]) {
      expect((await call(path, method, undefined, false)).status).toBe(401);
    }
    expect(privateReads).toBe(0);
  });
  it('rejects cross-origin mutations and unknown private fields', async () => {
    expect(
      (
        await call(
          '/publishing',
          'PUT',
          { draft, revision: null },
          true,
          'https://evil.example',
        )
      ).status,
    ).toBe(403);
    expect(
      (
        await call('/publishing', 'PUT', {
          draft: { ...draft, apiKey: 'bad' },
          revision: null,
        })
      ).status,
    ).toBe(400);
    expect((await store.draft()).revision).toBeNull();
  });
  it('keeps drafts encrypted and private until explicit publication, then serves only the projection', async () => {
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      404,
    );
    const save = await call('/publishing', 'PUT', { draft, revision: null });
    expect(save.status).toBe(200);
    const { revision } = await save.json();
    const raw = await db
      .prepare('SELECT sealed FROM portfolio_drafts')
      .first<{ sealed: string }>();
    expect(raw!.sealed).not.toContain('private.com');
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      404,
    );
    const preview = await call('/publishing/preview');
    expect(preview.status).toBe(200);
    expect(await preview.text()).toContain('Draft preview');
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    const ownerState = await (await call('/publishing')).json();
    expect(
      ownerState.publishedSnapshot.listings.map(
        (item: { domain: string }) => item.domain,
      ),
    ).toEqual(['visible.com']);
    expect(JSON.stringify(ownerState.publishedSnapshot)).not.toContain(
      'NEVER_PUBLIC',
    );
    privateReads = 0;
    const published = await call('/p/portfolio', 'GET', undefined, false);
    const html = await published.text();
    expect(html).toContain('visible.com');
    for (const forbidden of [
      'private.com',
      'NEVER_PUBLIC',
      'apiKey',
      'dynadot',
      'lastSyncedAt',
    ])
      expect(html).not.toContain(forbidden);
    expect(privateReads).toBe(0);
    expect(published.headers.get('Cache-Control')).toBe('no-store');
    expect(published.headers.get('Content-Security-Policy')).toContain(
      "default-src 'none'",
    );
  });
  it('rejects stale saves and publishes across separate store instances', async () => {
    const revision = await store.save(draft, null);
    const next = await store.save({ ...draft, title: 'Newer draft' }, revision);
    await expect(store.save(draft, revision)).rejects.toBeInstanceOf(
      PublicationConflict,
    );
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(409);
    expect((await store.draft()).revision).toBe(next);
    expect(await store.published()).toBeNull();
    await expect(
      store.publish(
        { ...draft, listings: [], publishedAt: Date.now() },
        revision,
      ),
    ).rejects.toBeInstanceOf(PublicationConflict);
  });
  it('editing does not update the public page; changing a handle removes the old route', async () => {
    let revision = await store.save(draft, null);
    await call('/publishing/publish', 'POST', { revision });
    revision = await store.save(
      { ...draft, handle: 'new-handle', title: 'New title' },
      revision,
    );
    expect(
      await (await call('/p/portfolio', 'GET', undefined, false)).text(),
    ).toContain('Test collection');
    await call('/publishing/publish', 'POST', { revision });
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      404,
    );
    expect((await call('/p/new-handle', 'GET', undefined, false)).status).toBe(
      200,
    );
  });
  it('unpublishes immediately, keeps the draft, and invalidates outstanding previews', async () => {
    const revision = await store.save(draft, null);
    await call('/publishing/publish', 'POST', { revision });
    const removed = await call('/publishing/unpublish', 'POST', { revision });
    expect(removed.status).toBe(200);
    const receipt = await removed.json();
    expect(receipt.revision).toBe((await store.draft()).revision);
    expect(receipt.revision).not.toBe(revision);
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      404,
    );
    expect((await store.draft()).draft).toEqual(draft);
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(409);
    const next = await store.save(
      { ...draft, title: 'Another tab' },
      receipt.revision,
    );
    expect(next).not.toBe(receipt.revision);
    expect(
      (await call('/publishing', 'PUT', { draft, revision: receipt.revision }))
        .status,
    ).toBe(409);
  });
  it('a stale unpublish cannot remove a newer publication', async () => {
    const revision = await store.save(draft, null);
    const next = await store.save({ ...draft, title: 'Newer' }, revision);
    await call('/publishing/publish', 'POST', { revision: next });
    expect(
      (await call('/publishing/unpublish', 'POST', { revision })).status,
    ).toBe(409);
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      200,
    );
  });
  it('escapes content and filters public listings without exposing draft inventory', () => {
    const html = renderPortfolio(
      {
        ...draft,
        title: '<script>alert(1)</script>',
        listings: [
          {
            ...draft.listings[0],
            visibility: 'inquiry',
            description: '<img src=x onerror=alert(1)>',
          },
        ],
        publishedAt: Date.now(),
      },
      new URL('https://test/p/portfolio?q=%22%3E%3Cscript%3E'),
    );
    expect(html).toContain('&lt;script&gt;');
    expect(html).not.toContain('<script>');
    expect(html).not.toContain('<img src=x');
    expect(html).toContain('No domains match');
  });

  it('round-trips the draft through backup after key rotation without republishing', async () => {
    const revision = await store.save(draft, null);
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    const backup = await publicationBackupMethods(store).exportData.handler();
    const rotatedStore = new PublicationStore(
      db,
      await aesGcmCipher(new Uint8Array(32).fill(9)),
    );
    await expect(rotatedStore.draft()).rejects.toThrow();
    await publicationBackupMethods(rotatedStore).importData.handler(backup);
    expect((await rotatedStore.draft()).draft).toEqual(draft);
    expect(await rotatedStore.published()).toBeNull();
  });

  it('rejects an invalid backup before changing publication state', async () => {
    const revision = await store.save(draft, null);
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    const methods = publicationBackupMethods(store);
    const backup = JSON.parse(await methods.exportData.handler());
    backup.publicationDraft = { ...draft, unexpected: 'private field' };
    await expect(
      methods.importData.handler(JSON.stringify(backup)),
    ).rejects.toThrow(/Nothing was imported/);
    expect((await store.published())?.revision).toBe(revision);
  });

  it('fails closed if a stored public projection contains private fields', async () => {
    await db
      .prepare(
        "INSERT INTO published_portfolios (id, handle, revision, payload) VALUES ('main', 'portfolio', 'test', ?1)",
      )
      .bind(
        JSON.stringify({
          ...draft,
          listings: [draft.listings[0]],
          publishedAt: Date.now(),
          credentials: 'NEVER_PUBLIC',
        }),
      )
      .run();
    const response = await call('/p/portfolio', 'GET', undefined, false);
    expect(response.status).toBe(503);
    expect(await response.text()).not.toContain('NEVER_PUBLIC');
    expect(privateReads).toBe(0);
  });

  it('preserves membership in multiple public collections when filtering', () => {
    const snapshot = {
      ...draft,
      publishedAt: Date.now(),
      listings: [
        {
          ...draft.listings[0],
          visibility: 'inquiry' as const,
          collection: 'Short names; Web3',
        },
      ],
    };
    const html = renderPortfolio(
      snapshot,
      new URL('http://localhost/p/portfolio?collection=Web3'),
    );
    expect(html).toContain('<option value="Short names">');
    expect(html).toContain('<option value="Web3" selected>');
    expect(html).toContain('visible.com');
    expect(
      renderPortfolio(
        snapshot,
        new URL('http://localhost/p/portfolio?collection=Other'),
      ),
    ).toContain('No domains match');
  });
});

describe('versioned owner site database and HTTP boundary', () => {
  it('starts off and refuses client attempts to enable v2; enforces auth/origin on every new endpoint', async () => {
    const site = emptyOwnerSite();
    expect(
      (await call('/publishing/site', 'PUT', { draft: site, revision: null }))
        .status,
    ).toBe(403);
    expect(
      (await call('/publishing/site/convert', 'POST', { revision: null }))
        .status,
    ).toBe(403);
    env.DOMBOT_OWNER_SITE_V2 = 'true';
    for (const [path, method] of [
      ['/publishing/site', 'GET'],
      ['/publishing/site', 'PUT'],
      ['/publishing/site/convert', 'POST'],
    ])
      expect((await call(path, method, undefined, false)).status).toBe(401);
    expect(
      (
        await call(
          '/publishing/site',
          'PUT',
          { draft: site, revision: null },
          true,
          'https://attacker.example',
        )
      ).status,
    ).toBe(403);
    expect((await store.draft()).revision).toBeNull();
  });
  it('publishes a zero-domain profile and supports disabled-editor recovery without private public reads', async () => {
    env.DOMBOT_OWNER_SITE_V2 = 'true';
    const site = emptyOwnerSite();
    site.profile.name = 'Sample profile only';
    const saved = await call('/publishing/site', 'PUT', {
      draft: site,
      revision: null,
    });
    expect(saved.status).toBe(200);
    const { revision } = await saved.json();
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    privateReads = 0;
    const response = await call('/p/portfolio', 'GET', undefined, false);
    const html = await response.text();
    expect(response.status).toBe(200);
    expect(html).toContain('Sample profile only');
    expect(html).not.toMatch(/visible.com|private.com|Search|0 holdings/);
    expect(privateReads).toBe(0);
    env.DOMBOT_OWNER_SITE_V2 = '';
    expect(
      (await call('/publishing/site', 'PUT', { draft: site, revision })).status,
    ).toBe(403);
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(403);
    expect((await call('/publishing', 'PUT', { draft, revision })).status).toBe(
      409,
    );
    expect((await call('/publishing/site')).status).toBe(200);
    const backup = JSON.parse(
      await publicationBackupMethods(store).exportData.handler(),
    );
    expect(backup.publicationDraft.version).toBe(2);
    expect(
      (await call('/publishing/unpublish', 'POST', { revision })).status,
    ).toBe(200);
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      404,
    );
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(409);
  });
  it('keeps a v1 publication byte-identical during explicit conversion; locks the handle and prevents stale legacy overwrite', async () => {
    const revision = await store.save(draft, null);
    await call('/publishing/publish', 'POST', { revision });
    const before = await (
      await call('/p/portfolio', 'GET', undefined, false)
    ).text();
    env.DOMBOT_OWNER_SITE_V2 = 'true';
    const converted = await call('/publishing/site/convert', 'POST', {
      revision,
    });
    expect(converted.status).toBe(200);
    const next = await converted.json();
    expect(
      await (await call('/p/portfolio', 'GET', undefined, false)).text(),
    ).toBe(before);
    expect(
      (await call('/publishing', 'PUT', { draft, revision: next.revision }))
        .status,
    ).toBe(409);
    const saved = await store.draft();
    if (!('version' in saved.draft)) throw new Error('Expected conversion');
    expect(
      (
        await call('/publishing/site', 'PUT', {
          draft: { ...saved.draft, handle: 'changed' },
          revision: next.revision,
        })
      ).status,
    ).toBe(400);
    expect(
      (await call('/publishing/publish', 'POST', { revision: next.revision }))
        .status,
    ).toBe(200);
    expect(
      await (await call('/p/portfolio', 'GET', undefined, false)).text(),
    ).toContain('Browse selected holdings');
    expect(
      (await call('/p/portfolio?collection=absent', 'GET', undefined, false))
        .status,
    ).toBe(404);
  });
  it('reads only published collection content and fails closed on hidden, corrupt and foreign references', async () => {
    env.DOMBOT_OWNER_SITE_V2 = 'true';
    const site = sampleSite();
    const saved = await call('/publishing/site', 'PUT', {
      draft: site,
      revision: null,
    });
    const { revision } = await saved.json();
    expect(
      (await call('/publishing/publish', 'POST', { revision })).status,
    ).toBe(200);
    privateReads = 0;
    for (const path of [
      '/p/portfolio',
      '/p/portfolio/c/one',
      '/p/portfolio?collection=Selected%20ideas',
      '/p/portfolio?view=catalogue&q=never',
    ]) {
      const html = await (await call(path, 'GET', undefined, false)).text();
      expect(html).not.toMatch(
        /never-disclose|NEVER_DISCLOSE|apiKey|dynadot|lastSyncedAt/,
      );
    }
    expect(
      (await call('/p/portfolio/c/hidden', 'GET', undefined, false)).status,
    ).toBe(404);
    expect(
      (await call('/p/another-owner/c/one', 'GET', undefined, false)).status,
    ).toBe(404);
    expect(privateReads).toBe(0);
    await db
      .prepare("UPDATE published_portfolios SET payload = 'not-json'")
      .run();
    expect((await call('/p/portfolio', 'GET', undefined, false)).status).toBe(
      503,
    );
  });
  it('restores a sealed v2 backup under a new root without publication and rejects future versions before mutation', async () => {
    env.DOMBOT_OWNER_SITE_V2 = 'true';
    const site = sampleSite();
    const { revision } = await (
      await call('/publishing/site', 'PUT', { draft: site, revision: null })
    ).json();
    await call('/publishing/publish', 'POST', { revision });
    const backup = await publicationBackupMethods(store).exportData.handler();
    const bad = JSON.parse(backup);
    bad.publicationDraft.version = 3;
    await expect(
      publicationBackupMethods(store).importData.handler(JSON.stringify(bad)),
    ).rejects.toThrow(/Nothing was imported/);
    expect((await store.published())?.revision).toBe(revision);
    await expect(
      publicationBackupMethods(store, false).importData.handler(backup),
    ).rejects.toThrow(/Nothing was imported/);
    expect((await store.published())?.revision).toBe(revision);
    const rotated = new PublicationStore(
      db,
      await aesGcmCipher(new Uint8Array(32).fill(9)),
    );
    await publicationBackupMethods(rotated).importData.handler(backup);
    expect((await rotated.draft()).draft).toEqual(site);
    expect(await rotated.published()).toBeNull();
    expect((await rotated.draft()).revision).not.toBe(revision);
  });
  it('rejects v2 races across store instances and never resurrects an unpublished snapshot', async () => {
    const site = sampleSite();
    const other = new PublicationStore(
      db,
      await aesGcmCipher(await deriveEncryptionKey(root)),
    );
    const revision = await store.save(site, null);
    const next = await other.save(
      { ...site, profile: { ...site.profile, name: 'Newer' } },
      revision,
    );
    await expect(store.save(site, revision)).rejects.toBeInstanceOf(
      PublicationConflict,
    );
    await expect(
      store.publish(
        { ...selectedSite(site), publishedAt: Date.now() },
        revision,
      ),
    ).rejects.toBeInstanceOf(PublicationConflict);
    await other.publish(
      { ...selectedSite(site), publishedAt: Date.now() },
      next,
    );
    await store.unpublish(next);
    await expect(
      other.publish({ ...selectedSite(site), publishedAt: Date.now() }, next),
    ).rejects.toBeInstanceOf(PublicationConflict);
    expect(await store.published()).toBeNull();
  });
});
