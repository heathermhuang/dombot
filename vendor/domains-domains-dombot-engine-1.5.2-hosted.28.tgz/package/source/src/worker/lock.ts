// One request at a time per isolate.
//
// The core keeps every namespace in module-level memory and the Worker
// re-hydrates it from D1 at the start of each request. A Workers isolate
// serves concurrent requests, interleaving them at every `await` — so without
// this, a poll arriving while a bulk step is mid-registrar-call would
// re-hydrate under it (and reset the bulk runner's in-memory job), a login
// burst would read the same attempts counter, and two writers would each
// persist their own stale view. DomBot is a single-user app: serializing the
// requests that touch state costs nothing noticeable and makes the
// hydrate → handle → flush cycle atomic within the isolate.
//
// Asset requests never take the lock (they touch no state). This lock alone
// cannot serialize other isolates. The hosted SaaS routes all stateful work
// and cron runs through one WorkspaceCoordinator per workspace; rehydration
// alone does not prevent cross-isolate read/modify/write races.

let tail: Promise<void> = Promise.resolve();
let depth = 0;

/** Runs `fn` once every earlier `withRequestLock` call has finished. */
export function withRequestLock<T>(fn: () => Promise<T>): Promise<T> {
  const previous = tail;
  let release!: () => void;
  // Share a coordination gate, never the previous request's I/O promise.
  // Each caller resumes its own async function before starting its I/O.
  tail = new Promise<void>((resolve) => {
    release = resolve;
  });
  return (async () => {
    await previous;
    depth++;
    try {
      return await fn();
    } finally {
      depth--;
      release();
    }
  })();
}

/** Whether a locked section is running right now (tests, diagnostics). */
export function requestLockHeld(): boolean {
  return depth > 0;
}
