import { isDomainKey, toAscii } from '../../shared/domain-name';
import { HIDDEN_FOLDER_ID } from '../../shared/ipc';
import type { DocStore } from './doc-store';
import { RENEWAL_PRICES_NAMESPACE } from './names';
import { toRenewalPrice, type RenewalPrice } from '../../shared/renewal-prices';

// Storage schema migrations (docs/storage-model.md). Each host calls
// `runMigrations` once, before `hydrateStores()`; a data bundle from an older
// DomBot goes through `upgradeLegacyNamespaces` instead, so both paths share
// one table of renames and one set of re-keying rules.

/** The storage schema this build writes. Stored at `meta/schemaVersion`. */
export const SCHEMA_VERSION = 4;

/** v0 → v1: old namespace name → new. */
export const RENAMED_NAMESPACES: Readonly<Record<string, string>> = {
  'cache-portfolio': 'registrar-domains',
  'cache-detail': 'registrar-details',
  'tld-rates': 'registrar-tld-rates',
  credentials: 'registrar-credentials',
  proxies: 'registrar-proxies',
  'registrar-state': 'registrars',
  'pricing-overrides': 'domain-prices',
};

/** v3 → v4: the names you add yourself became imported domains. Never in a
 *  release; only stores and bundles built from main between the two. */
export const LEGACY_IMPORTED_NAMESPACE = 'manual-domains';
const IMPORTED_NAMESPACE = 'imported-domains';

/** Renamed namespaces whose keys also change, from account-scoped to name. */
const REKEYED_BY_NAME = new Set(['pricing-overrides']);

// Folder assignments lived in `folders` under this key until v1.
const LEGACY_ASSIGNMENTS_KEY = 'assignments';
// The built-in "hide this name" folder was Archive (`__archive__`) between
// the Hidden → Archive rename and v2, when it became Hidden again.
const LEGACY_ARCHIVE_FOLDER_ID = '__archive__';

/** `${accountId ?? registrar}:${domain}` → `toAscii(domain)`, or null when the
 *  key doesn't end in a domain name. */
export function nameKeyOf(legacyKey: string): string | null {
  const key = toAscii(legacyKey.slice(legacyKey.lastIndexOf(':') + 1));
  return isDomainKey(key) ? key : null;
}

/**
 * Re-keys account-scoped entries by domain name. A name held by two accounts
 * keeps the first entry found; the rest are logged and dropped.
 */
export function rekeyByName<T>(
  entries: Record<string, T>,
  label: string,
): Record<string, T> {
  const out: Record<string, T> = {};
  for (const [legacyKey, value] of Object.entries(entries)) {
    const key = nameKeyOf(legacyKey);
    if (!key) {
      console.warn(`[storage] ${label}: dropping ${legacyKey} (not a domain)`);
    } else if (Object.hasOwn(out, key)) {
      console.warn(
        `[storage] ${label}: ${legacyKey} conflicts with another account's entry for ${key}; keeping the first`,
      );
    } else {
      out[key] = value;
    }
  }
  return out;
}

/** A folder id with the old Archive folder mapped to Hidden (v2). */
export function hiddenFolderId(folderId: string): string {
  return folderId === LEGACY_ARCHIVE_FOLDER_ID ? HIDDEN_FOLDER_ID : folderId;
}

/** The pre-v1 `folders/assignments` map, keyed by name, with the old
 *  Archive folder mapped to Hidden. */
export function assignmentsByName(raw: unknown): Record<string, string> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const ids: Record<string, string> = {};
  for (const [key, folderId] of Object.entries(raw)) {
    if (typeof folderId !== 'string') continue;
    ids[key] = hiddenFolderId(folderId);
  }
  return rekeyByName(ids, 'folder assignments');
}

/** v2 for a v4 bundle's `domain-folders`: Archive assignments become Hidden. */
export function hiddenFolderAssignments(
  entries: Record<string, unknown>,
): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(entries).map(([name, id]) => [
      name,
      typeof id === 'string' ? hiddenFolderId(id) : id,
    ]),
  );
}

/** A v1–v3 bundle's namespaces under the current names and keys. */
export function upgradeLegacyNamespaces(
  namespaces: Record<string, Record<string, unknown>>,
): Record<string, Record<string, unknown>> {
  const out = { ...namespaces };
  for (const [from, to] of Object.entries(RENAMED_NAMESPACES)) {
    const entries = out[from];
    if (!entries) continue;
    delete out[from];
    out[to] = REKEYED_BY_NAME.has(from) ? rekeyByName(entries, from) : entries;
  }
  const folders = out.folders;
  if (folders && Object.hasOwn(folders, LEGACY_ASSIGNMENTS_KEY)) {
    const { [LEGACY_ASSIGNMENTS_KEY]: assignments, ...definitions } = folders;
    out.folders = definitions;
    out['domain-folders'] = assignmentsByName(assignments);
  }
  return out;
}

/**
 * Brings a store written by an older DomBot up to SCHEMA_VERSION, one step
 * at a time. Idempotent: a step with nothing to move is skipped, and the
 * version is recorded after each step.
 *
 * `raw` is the store beneath any EncryptedDocStore. Renames copy values
 * exactly as stored, so a sealed value moves still sealed and a value the
 * cipher can't open right now (a locked keyring) is never dropped. `store` is
 * the host's configured store: the version marker goes through it, and so do
 * the values that have to be read (folder assignments).
 */
export async function runMigrations(
  raw: DocStore,
  store: DocStore,
): Promise<void> {
  const stored = await store.get('meta', 'schemaVersion');
  const version = typeof stored === 'number' ? stored : 0;
  if (version < 1) {
    await migration1(raw, store);
    await store.put('meta', 'schemaVersion', 1);
  }
  if (version < 2) {
    await migration2(store);
    await store.put('meta', 'schemaVersion', 2);
  }
  if (version < 3) {
    await migration3(store);
    await store.put('meta', 'schemaVersion', 3);
  }
  if (version < 4) {
    await migration4(raw);
    await store.put('meta', 'schemaVersion', 4);
  }
}

/** v1: namespace renames, and folders and prices keyed by name. */
async function migration1(raw: DocStore, store: DocStore): Promise<void> {
  const assignments = await store.get('folders', LEGACY_ASSIGNMENTS_KEY);
  if (assignments === null) {
    if ((await raw.get('folders', LEGACY_ASSIGNMENTS_KEY)) !== null) {
      // Stored but unreadable: leave everything as is and retry next start.
      throw new Error("[storage] can't read folder assignments to migrate");
    }
  } else {
    await store.putMany(
      'domain-folders',
      Object.entries(assignmentsByName(assignments)),
    );
    await store.delete('folders', LEGACY_ASSIGNMENTS_KEY);
  }

  for (const [from, to] of Object.entries(RENAMED_NAMESPACES)) {
    const entries = await raw.list(from);
    if (Object.keys(entries).length === 0) continue;
    const moved = REKEYED_BY_NAME.has(from)
      ? rekeyByName(entries, from)
      : entries;
    await raw.putMany(to, Object.entries(moved));
    await raw.clear(from);
  }
}

/** v2: the Archive folder becomes Hidden (Archive is now an ownership action). */
async function migration2(store: DocStore): Promise<void> {
  const entries = await store.list('domain-folders');
  const moved = Object.entries(entries).filter(
    ([, id]) => id === LEGACY_ARCHIVE_FOLDER_ID,
  );
  if (moved.length === 0) return;
  await store.putMany(
    'domain-folders',
    moved.map(([name]) => [name, HIDDEN_FOLDER_ID]),
  );
}

/**
 * v3: manual renewal prices gain a currency. Each stored USD number becomes
 * `{ amount, currency: 'USD' }` (docs/domain-import-export.md); a value that
 * doesn't hold is dropped.
 */
async function migration3(store: DocStore): Promise<void> {
  const entries = await store.list(RENEWAL_PRICES_NAMESPACE);
  const legacy = Object.entries(entries).filter(
    ([, value]) => typeof value === 'number',
  );
  if (legacy.length === 0) return;
  const converted = legacy.map(
    ([name, value]) => [name, toRenewalPrice(value)] as const,
  );
  await store.putMany(
    RENEWAL_PRICES_NAMESPACE,
    converted.filter((e): e is [string, RenewalPrice] => e[1] !== null),
  );
  for (const [name, price] of converted)
    if (price === null) await store.delete(RENEWAL_PRICES_NAMESPACE, name);
}

/** v4: `manual-domains` becomes `imported-domains`, values copied as stored. */
async function migration4(raw: DocStore): Promise<void> {
  const entries = await raw.list(LEGACY_IMPORTED_NAMESPACE);
  if (Object.keys(entries).length === 0) return;
  await raw.putMany(IMPORTED_NAMESPACE, Object.entries(entries));
  await raw.clear(LEGACY_IMPORTED_NAMESPACE);
}
