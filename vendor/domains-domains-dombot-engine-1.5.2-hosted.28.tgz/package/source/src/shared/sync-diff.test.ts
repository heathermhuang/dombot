import { describe, expect, it } from 'vitest';
import { localDay, type DomainEvent } from './domain-events';
import { ownershipByDomain } from './ownership';
import {
  diffSync,
  isOpenAlert,
  resolvedIds,
  type AccountHoldings,
} from './sync-diff';

const NOW = Date.UTC(2026, 8, 22, 12);

function account(
  accountId: string,
  names: string[],
  synced = true,
  known = true,
): AccountHoldings {
  return { accountId, names, synced, known };
}

let n = 0;
const newEvent = (
  fields: Omit<DomainEvent, 'id' | 'createdAt' | 'updatedAt'>,
  now: number,
): DomainEvent => ({
  ...fields,
  id: `E${String(++n).padStart(4, '0')}`,
  createdAt: now,
  updatedAt: null,
});

function run(
  before: AccountHoldings[],
  after: AccountHoldings[],
  events: DomainEvent[] = [],
  tracked: string[] = [],
) {
  return diffSync(before, after, events, new Set(tracked), NOW, newEvent);
}

const brief = (events: DomainEvent[]) =>
  events.map((e) => ({
    type: e.type,
    domain: e.domain,
    ...(e.accountId ? { accountId: e.accountId } : {}),
    ...(e.fromAccountId ? { from: e.fromAccountId, to: e.toAccountId } : {}),
    ...(e.resolves ? { resolves: e.resolves } : {}),
    ...(e.dismissed ? { dismissed: true } : {}),
  }));

describe('diffSync', () => {
  it('treats the first successful sync as a starting point', () => {
    const result = run([], [account('dynadot', ['a.com', 'b.com'])]);
    expect(result.events).toEqual([]);
    expect(result.newlyTracked).toEqual(['dynadot']);
  });

  it('does not start tracking an account whose sync failed', () => {
    const result = run([], [account('dynadot', ['a.com'], false)]);
    expect(result).toEqual({
      events: [],
      newlyTracked: [],
      retracted: [],
      landed: [],
    });
  });

  it('records a name leaving and a name arriving, dated by the sync', () => {
    const result = run(
      [account('dynadot', ['a.com', 'B.com'])],
      [account('dynadot', ['b.com', 'Münich.de'])],
      [],
      ['dynadot'],
    );
    expect(brief(result.events)).toEqual([
      { type: 'removed', domain: 'a.com', accountId: 'dynadot' },
      { type: 'added', domain: 'xn--mnich-kva.de', accountId: 'dynadot' },
    ]);
    expect(result.events.every((e) => e.source === 'sync')).toBe(true);
    expect(result.events[0].date).toBe(localDay(NOW));
  });

  it('records one move when a name leaves one account and joins another', () => {
    const result = run(
      [account('dynadot', ['a.com']), account('porkbun', [])],
      [account('dynadot', []), account('porkbun', ['a.com'])],
      [],
      ['dynadot', 'porkbun'],
    );
    expect(brief(result.events)).toEqual([
      { type: 'moved', domain: 'a.com', from: 'dynadot', to: 'porkbun' },
    ]);
  });

  it('closes an open departure when the name later turns up in another account', () => {
    const first = run(
      [account('dynadot', ['a.com']), account('porkbun', [], false)],
      [account('dynadot', []), account('porkbun', [], false)],
      [],
      ['dynadot'],
    );
    const removal = first.events[0];
    expect(removal.type).toBe('removed');
    const second = run(
      [account('dynadot', []), account('porkbun', [])],
      [account('dynadot', [], false), account('porkbun', ['a.com'])],
      first.events,
      ['dynadot', 'porkbun'],
    );
    expect(brief(second.events)).toEqual([
      {
        type: 'moved',
        domain: 'a.com',
        from: 'dynadot',
        to: 'porkbun',
        resolves: removal.id,
      },
    ]);
    const all = [...first.events, ...second.events];
    expect(isOpenAlert(removal, resolvedIds(all))).toBe(false);
  });

  it('closes a departure quietly when the name comes back to the same account', () => {
    const left = run(
      [account('dynadot', ['a.com'])],
      [account('dynadot', [])],
      [],
      ['dynadot'],
    );
    const back = run(
      [account('dynadot', [])],
      [account('dynadot', ['a.com'])],
      left.events,
      ['dynadot'],
    );
    expect(brief(back.events)).toEqual([
      {
        type: 'added',
        domain: 'a.com',
        accountId: 'dynadot',
        resolves: left.events[0].id,
        dismissed: true,
      },
    ]);
    const owned = ownershipByDomain([...left.events, ...back.events]);
    expect(owned.get('a.com')?.archived).toBe(false);
  });

  it('does not alert twice for a name that is already gone', () => {
    const left = run(
      [account('dynadot', ['a.com']), account('porkbun', ['a.com'])],
      [account('dynadot', []), account('porkbun', ['a.com'])],
      [],
      ['dynadot', 'porkbun'],
    );
    // Held elsewhere: a move, not a departure.
    expect(left.events.map((e) => e.type)).toEqual(['moved']);
  });

  it('records a departure after you marked the name as nothing to review', () => {
    const sold = newEvent(
      { domain: 'a.com', type: 'sold', source: 'user', date: '2026-09-01' },
      NOW,
    );
    const result = run(
      [account('dynadot', ['a.com'])],
      [account('dynadot', [])],
      [sold],
      ['dynadot'],
    );
    expect(brief(result.events)).toEqual([
      {
        type: 'removed',
        domain: 'a.com',
        accountId: 'dynadot',
        dismissed: true,
      },
    ]);
    // Still Sold, not "left".
    expect(
      ownershipByDomain([sold, ...result.events]).get('a.com'),
    ).toMatchObject({ archived: true, label: 'sold', event: sold });
  });

  it('keeps a Sold name labeled through a move and a purchase', () => {
    const sold = newEvent(
      { domain: 'a.com', type: 'sold', source: 'user', date: '2026-09-01' },
      NOW,
    );
    const moved = newEvent(
      {
        domain: 'a.com',
        type: 'moved',
        source: 'sync',
        date: '2026-09-02',
        fromAccountId: 'porkbun',
        toAccountId: 'dynadot',
      },
      NOW,
    );
    const bought = newEvent(
      { domain: 'a.com', type: 'purchased', source: 'user', date: null },
      NOW,
    );
    const result = run(
      [account('dynadot', ['a.com'])],
      [account('dynadot', [])],
      [sold, moved, bought],
      ['dynadot'],
    );
    expect(result.events[0]).toMatchObject({
      type: 'removed',
      dismissed: true,
    });
  });

  it('starts over quietly when there is no record of the last sync', () => {
    const result = run(
      [account('dynadot', [], false, false)],
      [account('dynadot', ['a.com', 'b.com'])],
      [],
      ['dynadot'],
    );
    expect(result.events).toEqual([]);
  });

  it('leaves other accounts alone when a new registrar syncs for the first time', () => {
    const result = run(
      [account('dynadot', ['a.com']), account('porkbun', [], false, false)],
      [account('dynadot', ['a.com'], false), account('porkbun', ['z.com'])],
      [],
      ['dynadot'],
    );
    expect(result).toEqual({
      events: [],
      newlyTracked: ['porkbun'],
      retracted: [],
      landed: [],
    });
  });
});

describe('ownershipByDomain', () => {
  it('labels Archive by the latest disposition, and a return makes it owned', () => {
    const e = (id: string, type: DomainEvent['type'], extra = {}) =>
      ({
        id,
        domain: 'a.com',
        type,
        source: 'user',
        date: null,
        createdAt: 0,
        updatedAt: null,
        ...extra,
      }) as DomainEvent;
    const left = e('E1', 'removed', { source: 'sync', accountId: 'dyn' });
    expect(ownershipByDomain([left]).get('a.com')).toMatchObject({
      archived: true,
      label: 'removed',
      lastAccountId: 'dyn',
    });
    const dropped = e('E2', 'dropped', { resolves: 'E1' });
    expect(ownershipByDomain([left, dropped]).get('a.com')?.label).toBe(
      'dropped',
    );
    const back = e('E3', 'added', { source: 'sync', accountId: 'pork' });
    expect(ownershipByDomain([left, dropped, back]).get('a.com')).toMatchObject(
      { archived: false, label: null, lastAccountId: 'pork' },
    );
  });

  describe('renewals', () => {
    const LAST = NOW - 86_400_000;
    const at = (
      accountId: string,
      expirations: Record<string, string> | undefined,
      awaiting?: Record<string, number>,
    ): AccountHoldings => ({
      ...account(accountId, Object.keys(expirations ?? {})),
      expirations,
      ...(awaiting ? { awaiting } : {}),
    });
    const renewed = (
      domain: string,
      source: DomainEvent['source'],
      years: number,
      createdAt: number,
      id = `R${createdAt}`,
    ): DomainEvent => ({
      id,
      domain,
      type: 'renewed',
      source,
      date: null,
      createdAt,
      updatedAt: null,
      accountId: 'dynadot',
      years,
    });

    it('records an expiry a year or more later as a renewal', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2026-10-01', 'b.com': '2026-11-01' })],
        [at('dynadot', { 'a.com': '2027-10-01', 'b.com': '2029-11-01' })],
        [],
        ['dynadot'],
      );
      expect(
        result.events.map((e) => [e.type, e.domain, e.years, e.accountId]),
      ).toEqual([
        ['renewed', 'a.com', 1, 'dynadot'],
        ['renewed', 'b.com', 3, 'dynadot'],
      ]);
      expect(result.events[0]).toMatchObject({
        source: 'sync',
        date: localDay(NOW),
      });
      expect(result.events[0].amount).toBeUndefined();
    });

    it('records nothing for a small shift', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2026-10-01', 'b.com': '2026-10-01' })],
        [at('dynadot', { 'a.com': '2026-10-02', 'b.com': '2027-03-01' })],
        [],
        ['dynadot'],
      );
      expect(result.events).toEqual([]);
    });

    it('records nothing when the last sync kept no expiries', () => {
      const result = run(
        [at('dynadot', undefined)].map((h) => ({ ...h, names: ['a.com'] })),
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [],
        ['dynadot'],
      );
      expect(result.events).toEqual([]);
    });

    it('lands an awaited DomBot renewal instead of recording it again', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2026-10-01' }, { 'a.com': 1 })],
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [renewed('a.com', 'user', 1, NOW - 1000)],
        ['dynadot'],
      );
      expect(result.events).toEqual([]);
      expect(result.landed).toEqual([
        { accountId: 'dynadot', domain: 'a.com' },
      ]);
    });

    it('records only the years a jump adds beyond an awaited renewal', () => {
      // Renewed in DomBot for a year, and transferred (another year).
      const result = run(
        [
          at('dynadot', { 'a.com': '2026-10-01' }, { 'a.com': 1 }),
          { ...at('pork', {}), names: [] },
        ],
        [at('dynadot', {}), at('pork', { 'a.com': '2028-10-01' })],
        [],
        ['dynadot', 'pork'],
      );
      expect(result.events.map((e) => [e.type, e.years ?? null])).toEqual([
        ['moved', null],
        ['renewed', 1],
      ]);
      expect(result.events[1].accountId).toBe('pork');
      expect(result.landed).toEqual([
        { accountId: 'dynadot', domain: 'a.com' },
      ]);
    });

    it('records the next yearly jump after one sync recorded', () => {
      // The last sync wrote a renewal at the same moment it saved its record.
      const result = run(
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [at('dynadot', { 'a.com': '2028-10-01' })],
        [renewed('a.com', 'sync', 1, LAST)],
        ['dynadot'],
      );
      expect(brief(result.events)).toEqual([
        { type: 'renewed', domain: 'a.com', accountId: 'dynadot' },
      ]);
    });

    it('records a jump no DomBot renewal is awaiting', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2026-10-01' })],
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [renewed('a.com', 'user', 1, NOW - 1000)],
        ['dynadot'],
      );
      expect(result.events.map((e) => e.type)).toEqual(['renewed']);
      expect(result.landed).toEqual([]);
    });

    it('retracts the sync renewal when the expiry moves back', () => {
      const jump = renewed('a.com', 'sync', 1, LAST - 1000);
      const result = run(
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [at('dynadot', { 'a.com': '2026-10-01' })],
        [jump],
        ['dynadot'],
      );
      expect(result.events).toEqual([]);
      expect(result.retracted).toEqual([jump.id]);
    });

    it('retracts a remainder-years renewal when the whole jump is undone', () => {
      // +2 years seen: 1 from a DomBot renewal, 1 written by sync.
      const rest = renewed('a.com', 'sync', 1, LAST - 1000);
      const result = run(
        [at('dynadot', { 'a.com': '2028-10-01' })],
        [at('dynadot', { 'a.com': '2026-10-01' })],
        [rest],
        ['dynadot'],
      );
      expect(result.retracted).toEqual([rest.id]);
    });

    it('keeps a sync renewal of more years than the expiry moved back', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2028-10-01' })],
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [renewed('a.com', 'sync', 2, LAST - 1000)],
        ['dynadot'],
      );
      expect(result.retracted).toEqual([]);
    });

    it('never retracts a renewal you made', () => {
      const result = run(
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [at('dynadot', { 'a.com': '2026-10-01' })],
        [renewed('a.com', 'user', 1, LAST - 1000)],
        ['dynadot'],
      );
      expect(result.retracted).toEqual([]);
    });

    it('records a move with a later expiry as moved plus renewed', () => {
      const result = run(
        [
          at('dynadot', { 'a.com': '2026-10-01' }),
          { ...at('pork', {}), names: [] },
        ],
        [at('dynadot', {}), at('pork', { 'a.com': '2027-10-01' })],
        [],
        ['dynadot', 'pork'],
      );
      expect(brief(result.events)).toEqual([
        { type: 'moved', domain: 'a.com', from: 'dynadot', to: 'pork' },
        { type: 'renewed', domain: 'a.com', accountId: 'pork' },
      ]);
      expect(result.events[1].years).toBe(1);
    });

    it('leaves a renewal of a name marked Sold in Archive', () => {
      const sold: DomainEvent = {
        ...renewed('a.com', 'user', 1, LAST - 1000, 'E0000'),
        type: 'sold',
      };
      const result = run(
        [at('dynadot', { 'a.com': '2026-10-01' })],
        [at('dynadot', { 'a.com': '2027-10-01' })],
        [sold],
        ['dynadot'],
      );
      expect(result.events.map((e) => e.type)).toEqual(['renewed']);
      expect(
        ownershipByDomain([sold, ...result.events]).get('a.com'),
      ).toMatchObject({ archived: true, label: 'sold' });
    });

    it('is never an open alert', () => {
      const e = renewed('a.com', 'sync', 1, NOW);
      expect(isOpenAlert(e, new Set())).toBe(false);
    });
  });
});
