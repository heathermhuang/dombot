import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { PasswordInput } from '@/components/ui/password-input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  MAX_BUNDLE_BYTES,
  isSealedBundle,
  openBundle,
  sealBundle,
} from '../../../shared/bundle-seal';
import { isDemo } from '../../lib/platform';
import { useAppStore } from '../../store/app';
import { ImportDomainsDialog } from '../../components/domains/ImportDomainsDialog';
import { SettingsCard, SettingsField } from './SettingsCard';
import { Download, Upload } from 'lucide-react';
import { domainsCsvTemplate } from '../../../shared/domain-csv';
import { exportAllDomains } from '../../lib/domain-export';

/** Auto-sync interval choices (minutes). `0` disables the background sync. */
const INTERVAL_OPTIONS: { label: string; minutes: number }[] = [
  { label: 'Every hour', minutes: 60 },
  { label: 'Every 6 hours', minutes: 360 },
  { label: 'Every 12 hours', minutes: 720 },
  { label: 'Every 24 hours', minutes: 1440 },
  { label: 'Every 48 hours', minutes: 2880 },
  { label: 'Every 7 days', minutes: 10080 },
  { label: 'Off', minutes: 0 },
];

const DEFAULT_INTERVAL_MINUTES = 1440;

/**
 * Data & cache settings. DomBot caches your portfolio, per-domain detail, and
 * renewal prices on disk (timestamped) so the app opens fully populated with no
 * network calls. This tab also controls the background sync
 * that keeps that cache fresh, and clearing the cache.
 */
export default function DataSettings() {
  const clearAllCaches = useAppStore((s) => s.clearAllCaches);
  const settings = useAppStore((s) => s.settings);
  const loadSettings = useAppStore((s) => s.loadSettings);
  const setAutoSyncInterval = useAppStore((s) => s.setAutoSyncInterval);
  const [clearing, setClearing] = useState(false);
  const [cleared, setCleared] = useState(false);

  useEffect(() => {
    void loadSettings();
  }, [loadSettings]);

  const onClear = async () => {
    setClearing(true);
    setCleared(false);
    try {
      await clearAllCaches();
      setCleared(true);
    } finally {
      setClearing(false);
    }
  };

  const stored = settings?.autoSyncIntervalMinutes ?? null;
  // A value that isn't a preset (only reachable outside the UI) shows as the
  // default rather than an empty select.
  const interval =
    stored != null && !INTERVAL_OPTIONS.some((o) => o.minutes === stored)
      ? DEFAULT_INTERVAL_MINUTES
      : stored;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold">Data & sync</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          DomBot keeps a copy of your portfolio and refreshes it from the
          registrars on a schedule. Manage spreadsheet import/export and private
          backups here, alongside sync and cache controls.
        </p>
      </div>

      <SettingsCard title="Auto-sync">
        <SettingsField
          label="Sync frequency"
          htmlFor="auto-sync-interval"
          description="How often DomBot re-syncs your whole portfolio in the background. Larger portfolios may prefer a longer interval or Off."
        >
          <div className="flex items-center gap-3">
            <Select
              value={interval == null ? undefined : String(interval)}
              onValueChange={(v) => void setAutoSyncInterval(Number(v))}
            >
              <SelectTrigger id="auto-sync-interval" className="w-52">
                <SelectValue placeholder="Loading…" />
              </SelectTrigger>
              <SelectContent>
                {INTERVAL_OPTIONS.map((opt) => (
                  <SelectItem key={opt.minutes} value={String(opt.minutes)}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {interval === 0 && (
              <span className="text-sm text-muted-foreground">
                Auto-sync is off — refresh manually or via the agent’s sync
                tools.
              </span>
            )}
          </div>
        </SettingsField>
      </SettingsCard>

      <SpreadsheetCard />
      <ExportCard />
      <ImportCard />

      <SettingsCard title="Cached data" contentClassName="flex flex-col gap-4">
        <p className="text-sm text-muted-foreground">
          Clear the cached portfolio and start over. Your saved registrar
          credentials, manual prices, and folders are kept. The next “Sync
          domains” re-fetches everything fresh.
        </p>
        <div className="flex items-center gap-3">
          <Button
            variant="destructive"
            onClick={() => void onClear()}
            disabled={clearing}
          >
            {clearing ? 'Clearing…' : 'Clear cache'}
          </Button>
          {cleared && (
            <span className="text-sm text-muted-foreground">
              Cache cleared.
            </span>
          )}
        </div>
      </SettingsCard>
    </div>
  );
}

/**
 * Your domains as a spreadsheet: import names (with what you paid, sold for,
 * and are asking) from any CSV, export them all as a DomBot CSV, or start
 * from the template (docs/domain-import-export.md).
 */
function SpreadsheetCard() {
  const [importing, setImporting] = useState(false);

  async function onExport() {
    try {
      const n = await exportAllDomains();
      if (n !== null) toast.success(`Exported ${n} name${n === 1 ? '' : 's'}`);
    } catch (err) {
      toast.error('Export failed', {
        description: err instanceof Error ? err.message : String(err),
      });
    }
  }

  async function onTemplate() {
    try {
      const result = await window.api.saveTextFile(
        domainsCsvTemplate(),
        'dombot-domains-template.csv',
      );
      if (result.saved) toast.success('Template downloaded');
    } catch (err) {
      toast.error('Download failed', {
        description: err instanceof Error ? err.message : String(err),
      });
    }
  }

  return (
    <SettingsCard title="Spreadsheet" contentClassName="flex flex-col gap-3">
      <p className="text-sm text-muted-foreground">
        Import domains from a CSV: a DomBot export, a registrar or marketplace
        export, or your own list. You match the columns and review every change
        before anything is saved, and names already here are only added to.
        Export writes every name, Owned and Archive, one per row, in a file
        DomBot can import again.
      </p>
      <div className="flex flex-wrap gap-2">
        <Button className="gap-2" onClick={() => setImporting(true)}>
          <Upload className="size-4" />
          Import domains…
        </Button>
        <Button
          variant="outline"
          className="gap-2"
          onClick={() => void onExport()}
        >
          <Download className="size-4" />
          Export all domains
        </Button>
        <Button variant="ghost" onClick={() => void onTemplate()}>
          Download template
        </Button>
      </div>
      {importing && <ImportDomainsDialog onClose={() => setImporting(false)} />}
    </SettingsCard>
  );
}

/**
 * Backup of the whole store as one JSON file. Optionally sealed with a
 * passphrase, since the file holds registrar API keys.
 */
function ExportCard() {
  const [exportPass, setExportPass] = useState('');
  const [exporting, setExporting] = useState(false);

  const onExport = async () => {
    setExporting(true);
    try {
      let text = await window.api.exportData();
      if (exportPass) text = await sealBundle(text, exportPass);
      const stamp = new Date().toISOString().slice(0, 10);
      const result = await window.api.saveTextFile(
        text,
        `dombot-data-${stamp}.json`,
      );
      if (result.saved) toast.success('Data exported');
    } catch (err) {
      toast.error('Export failed', {
        description: err instanceof Error ? err.message : String(err),
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <SettingsCard title="Export" contentClassName="flex flex-col gap-3">
      <p className="text-sm text-muted-foreground">
        Export everything — registrar keys, portfolio, imported domains,
        folders, prices, BIN prices, history, settings, and MCP pairings — as
        one JSON file. Use it as a backup or to move to another DomBot. Leave
        the passphrase blank and anyone who opens the file can read your
        registrar API keys. Type one and the file is locked: Import asks for
        that same passphrase, and DomBot does not keep a copy. If you forget it,
        the backup cannot be opened.
      </p>
      <div className="flex flex-wrap items-end gap-3">
        <SettingsField
          label="Passphrase (optional)"
          htmlFor="export-pass"
          className="w-56"
        >
          <PasswordInput
            id="export-pass"
            autoComplete="new-password"
            value={exportPass}
            onChange={(e) => setExportPass(e.target.value)}
          />
        </SettingsField>
        <Button onClick={() => void onExport()} disabled={exporting}>
          {exporting ? 'Exporting…' : 'Export data'}
        </Button>
      </div>
    </SettingsCard>
  );
}

/**
 * Restore a full backup, or bring in purchase fields from a spreadsheet.
 * The full import replaces the store. The spreadsheet does not.
 */
function ImportCard() {
  const fileInput = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<{
    name: string;
    text: string;
    sealed: boolean;
  } | null>(null);
  const [importPass, setImportPass] = useState('');
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);

  const onPick = async (file: File | undefined) => {
    if (!file) return;
    if (file.size > MAX_BUNDLE_BYTES) {
      toast.error('Data file is too large (maximum 32 MiB).');
      return;
    }
    const text = await file.text();
    setImportPass('');
    setImportError(null);
    setPending({ name: file.name, text, sealed: isSealedBundle(text) });
  };

  const onImport = async () => {
    if (!pending) return;
    setImporting(true);
    setImportError(null);
    try {
      const text = pending.sealed
        ? await openBundle(pending.text, importPass)
        : pending.text;
      const { namespaces, entries } = await window.api.importData(text);
      toast.success(
        `Imported ${entries} item${entries === 1 ? '' : 's'} across ${namespaces} section${namespaces === 1 ? '' : 's'}`,
      );
      setPending(null);
      // Every screen holds derived state; a reload is the honest refresh.
      setTimeout(() => window.location.reload(), 600);
    } catch (err) {
      setImportError(err instanceof Error ? err.message : String(err));
    } finally {
      setImporting(false);
    }
  };

  return (
    <SettingsCard title="Import" contentClassName="flex flex-col gap-5">
      <div className="flex flex-col gap-3">
        <p className="text-sm text-muted-foreground">
          Import replaces everything stored here with a backup file: registrar
          keys, the saved domain list, imported domains, folders, prices, BIN
          prices, history, settings, and MCP pairings. It does not contact your
          registrars. The next Sync does. Names in the file that an account no
          longer has will leave the list then, and names an account has that the
          file does not will appear. Purchase records are kept either way,
          including for names that are not in the list.
        </p>
        <div>
          <input
            ref={fileInput}
            type="file"
            accept=".json,application/json"
            className="hidden"
            onChange={(e) => {
              void onPick(e.target.files?.[0]);
              e.target.value = '';
            }}
          />
          <Button
            variant="outline"
            disabled={isDemo()}
            onClick={() => fileInput.current?.click()}
          >
            Import data…
          </Button>
        </div>
      </div>

      <Dialog
        open={pending !== null}
        onOpenChange={(o) => !o && setPending(null)}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Replace all data?</DialogTitle>
            <DialogDescription>
              Everything currently stored — registrar keys, portfolio, folders,
              prices, settings, MCP pairings — will be replaced with the
              contents of <span className="font-mono">{pending?.name}</span>.
              This can&apos;t be undone; export first if you want a copy.
            </DialogDescription>
          </DialogHeader>
          {pending?.sealed && (
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="import-pass">Passphrase</Label>
              <PasswordInput
                id="import-pass"
                autoComplete="off"
                value={importPass}
                onChange={(e) => setImportPass(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && void onImport()}
              />
            </div>
          )}
          {importError && (
            <p className="text-sm text-destructive">{importError}</p>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setPending(null)}
              disabled={importing}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => void onImport()}
              disabled={importing || (pending?.sealed && !importPass)}
            >
              {importing ? 'Importing…' : 'Replace and import'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SettingsCard>
  );
}
