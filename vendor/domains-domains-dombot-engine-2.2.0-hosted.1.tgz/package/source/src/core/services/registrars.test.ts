import { configureSyncDiagnostics } from './sync-diagnostics';
import { syncDiagnosticsSchema } from '../../shared/sync-monitor';
import {
  configureStore,
  hydrateStores,
  getStore,
  flushWrites,
} from '../storage/namespace';
import { MemoryDocStore } from '../storage/doc-store';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

// ── Boundary mocks ───────────────────────────────────────────────────────────
// registrars.ts sits on top of registrar-client, the on-disk cache, credentials,
// registrar-state, pricing, and node:dns. Mock all of them so the module's own
// logic (cache assembly/overlay, registrar resolution, last-good-on-error sync,
// cache patching) runs offline and deterministically.

// A faithful in-memory reimplementation of ./cache's contract.
interface Entry {
  data: unknown;
  fetchedAt: number;
}
const store: Record<string, Record<string, Entry>> = {
  portfolio: {},
  detail: {},
};
const readEntry = (ns: string, key: string) => store[ns][key] ?? null;
const readAll = (ns: string) => store[ns];
const writeEntry = (ns: string, key: string, data: unknown) => {
  const entry = { data, fetchedAt: Date.now() };
  store[ns][key] = entry;
  return entry;
};
const patchEntryData = (
  ns: string,
  key: string,
  update: (d: unknown) => unknown,
) => {
  const entry = store[ns][key];
  if (!entry) return;
  store[ns][key] = { ...entry, data: update(entry.data) };
};
const clearEntry = (ns: string, key: string) => {
  delete store[ns][key];
};
vi.mock('./cache', () => ({
  readEntry: (ns: string, key: string) => readEntry(ns, key),
  readAll: (ns: string) => readAll(ns),
  writeEntry: (ns: string, key: string, data: unknown) =>
    writeEntry(ns, key, data),
  patchEntryData: (ns: string, key: string, u: (d: unknown) => unknown) =>
    patchEntryData(ns, key, u),
  clearEntry: (ns: string, key: string) => clearEntry(ns, key),
  isStale: () => false,
}));

// Shared, scriptable client methods (the same fn refs land on every built client).
const clientMethods = {
  setAutoRenew: vi.fn(),
  lockDomain: vi.fn(),
  unlockDomain: vi.fn(),
  setPrivacy: vi.fn(),
  updateNameservers: vi.fn(),
  renewDomain: vi.fn(),
  registerDomain: vi.fn(),
  getDomain: vi.fn(),
  getNameservers: vi.fn(),
  getPricing: vi.fn(),
  checkAvailability: vi.fn(),
};
const listPortfolio = vi.fn();
vi.mock('@aoxborrow/registrar-client', async (importOriginal) => {
  const actual =
    await importOriginal<typeof import('@aoxborrow/registrar-client')>();
  class RegistrarClient {
    constructor() {
      Object.assign(this, clientMethods);
    }
  }
  return {
    ...actual,
    RegistrarClient,
    createRegistrar: vi.fn(() => ({})),
    listPortfolio: (...a: unknown[]) => listPortfolio(...a),
    registrars: {
      dynadot: {
        displayName: 'Dynadot',
        features: [],
        configFields: [{ name: 'apiKey', required: true }],
      },
      porkbun: {
        displayName: 'Porkbun',
        features: [],
        configFields: [{ name: 'apiKey', required: true }],
      },
      cloudflare: {
        displayName: 'Cloudflare',
        features: [],
        configFields: [{ name: 'apiKey', required: true }],
      },
      godaddy: {
        displayName: 'GoDaddy',
        features: [],
        configFields: [{ name: 'apiToken', required: true }],
      },
      namecheap: {
        displayName: 'Namecheap',
        features: [],
        configFields: [{ name: 'apiKey', required: true }],
      },
    },
  };
});

const storedCredentials: Record<string, Record<string, string>> = {};
vi.mock('./credentials', () => ({
  getStoredCredentials: (name: string) => storedCredentials[name] ?? {},
  setStoredCredentials: vi.fn(),
}));

const enabled: Record<string, boolean> = {};
vi.mock('./registrar-state', () => ({
  isRegistrarEnabled: (name: string) => enabled[name] ?? true,
  setRegistrarEnabled: (name: string, v: boolean) => {
    enabled[name] = v;
  },
}));

const setTldRate = vi.fn();
const resolvePricing = vi.fn();
vi.mock('./pricing', () => ({
  clearPortalQuotesForAccount: vi.fn(),
  usesPerNameQuote: () => false,
  tldOf: (d: string) => d.slice(d.indexOf('.') + 1),
  normalizeTld: (t: string) => t.trim().replace(/^\.+/, '').toLowerCase(),
  setTldRate: (...a: unknown[]) => setTldRate(...a),
  resolvePricing: (...a: unknown[]) => resolvePricing(...a),
}));

const resolveNs = vi.fn<(d: string) => Promise<string[]>>();
vi.mock('../dns', () => ({
  resolveNameservers: (d: string) => resolveNs(d),
}));

import {
  Feature,
  NotImplementedError,
  RateLimitError,
  registrars,
  type Domain,
  type RegistrarName,
} from '@aoxborrow/registrar-client';
import {
  LIST_ONLY_FIELDS,
  findRegistrarsForDomain,
  getRegistrarCatalog,
  getRegistrarFeatures,
  getRegistrationQuote,
  getCachedPortfolio,
  getCachedDetail,
  getRegistrarMetadata,
  getDomainDetail,
  getMergedPortfolio,
  getPortfolio,
  getRenewalPriceLive,
  registerDomainCached,
  renewDomainCached,
  setAutoRenewCached,
  setLockCached,
  setNameserversCached,
  setPrivacyCached,
  syncRegistrar,
} from './registrars';

function domain(
  partial: Partial<Domain> & { domainName: string; registrar: string },
): Domain {
  return {
    status: 'active',
    createdDate: null,
    expirationDate: null,
    renewalDate: null,
    autoRenew: false,
    locked: false,
    privacy: false,
    nameservers: [],
    syncedAt: new Date(0),
    deleted: false,
    ...partial,
  } as Domain;
}

// Seed a registrar's cached portfolio slice directly.
function seedSlice(
  name: string,
  domains: Domain[],
  opts: { lastSyncedAt?: number | null; lastError?: string | null } = {},
) {
  store.portfolio[name] = {
    data: {
      domains,
      lastSyncedAt: 'lastSyncedAt' in opts ? opts.lastSyncedAt : Date.now(),
      lastError: opts.lastError ?? null,
    },
    fetchedAt: Date.now(),
  };
}

beforeEach(async () => {
  configureStore(new MemoryDocStore());
  await hydrateStores();
  vi.clearAllMocks();
  store.portfolio = {};
  store.detail = {};
  for (const k of Object.keys(storedCredentials)) delete storedCredentials[k];
  for (const k of Object.keys(enabled)) delete enabled[k];
  // dynadot + porkbun configured; cloudflare not.
  storedCredentials.dynadot = { apiKey: 'x' };
  storedCredentials.porkbun = { apiKey: 'y' };
  listPortfolio.mockResolvedValue({ domains: [], errors: [] });
  resolveNs.mockResolvedValue([]);
});

describe('findRegistrarsForDomain', () => {
  it('finds the single holding registrar, case-insensitively', () => {
    seedSlice('dynadot', [
      domain({ domainName: 'Example.com', registrar: 'dynadot' }),
    ]);
    expect(findRegistrarsForDomain('example.COM')).toEqual(['dynadot']);
  });

  it('returns empty when the domain is not cached', () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot' }),
    ]);
    expect(findRegistrarsForDomain('ghost.com')).toEqual([]);
  });

  it('returns multiple when a stale cache lists it twice', () => {
    seedSlice('dynadot', [
      domain({ domainName: 'dup.com', registrar: 'dynadot' }),
    ]);
    seedSlice('porkbun', [
      domain({ domainName: 'dup.com', registrar: 'porkbun' }),
    ]);
    expect(findRegistrarsForDomain('dup.com').sort()).toEqual([
      'dynadot',
      'porkbun',
    ]);
  });
});

describe('getRegistrarFeatures', () => {
  afterEach(() => vi.restoreAllMocks());

  const transferOut = [
    Feature.GetTransferOut,
    Feature.ApproveTransferOut,
    Feature.RejectTransferOut,
  ];

  it('drops GoDaddy forwarding and transfer-out unless the account has every Optional setting', () => {
    const features = [
      Feature.GetAuthCode,
      Feature.GetDomainForwarding,
      Feature.SetDomainForwarding,
      ...transferOut,
    ];
    vi.spyOn(registrars.godaddy, 'features', 'get').mockReturnValue(features);
    vi.spyOn(registrars.dynadot, 'features', 'get').mockReturnValue(features);
    // No account to check: the catalog never offers it.
    expect(getRegistrarFeatures('godaddy')).toEqual([Feature.GetAuthCode]);
    expect(
      getRegistrarCatalog().find((r) => r.name === 'godaddy')?.features,
    ).toEqual([Feature.GetAuthCode]);
    storedCredentials.godaddy = { apiToken: 'pat' };
    expect(getRegistrarFeatures('godaddy', 'godaddy')).toEqual([
      Feature.GetAuthCode,
    ]);
    storedCredentials.godaddy = {
      apiToken: 'pat',
      customerId: '123456789',
      apiKey: 'key',
    };
    expect(getRegistrarFeatures('godaddy', 'godaddy')).toEqual([
      Feature.GetAuthCode,
    ]);
    storedCredentials.godaddy.apiSecret = 'secret';
    expect(getRegistrarFeatures('godaddy', 'godaddy')).toEqual(features);
    expect(getRegistrarFeatures('dynadot')).toEqual(features);
  });
});

describe('getCachedPortfolio / assemblePortfolio', () => {
  it('is null when nothing has ever synced', () => {
    expect(getCachedPortfolio()).toBeNull();
  });

  it('aggregates active registrars, taking the max fetchedAt', () => {
    seedSlice(
      'dynadot',
      [domain({ domainName: 'a.com', registrar: 'dynadot' })],
      {
        lastSyncedAt: 1000,
      },
    );
    seedSlice(
      'porkbun',
      [domain({ domainName: 'b.com', registrar: 'porkbun' })],
      {
        lastSyncedAt: 2000,
      },
    );
    const p = getCachedPortfolio()!;
    expect(p.domains.map((d) => d.domainName).sort()).toEqual([
      'a.com',
      'b.com',
    ]);
    expect(p.registrars.sort()).toEqual(['dynadot', 'porkbun']);
    expect(p.fetchedAt).toBe(2000);
    expect(p.registrarLabels.dynadot).toBe('Dynadot');
    expect(p.domains.every((d) => d.source === 'registrar')).toBe(true);
  });

  it('serves cached nameservers lowercase, as an older patch may have left them', () => {
    seedSlice('dynadot', [
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        nameservers: [
          'NS1.Afternic.com',
          'Verification-AbC1.ns101.verify.test.',
        ],
      }),
    ]);
    expect(getCachedPortfolio()!.domains[0].nameservers).toEqual([
      'ns1.afternic.com',
      'verification-abc1.ns101.verify.test',
    ]);
  });

  it('records an error-only registrar in errors but not in registrars', () => {
    seedSlice(
      'dynadot',
      [domain({ domainName: 'a.com', registrar: 'dynadot' })],
      {
        lastSyncedAt: 1000,
      },
    );
    // porkbun errored and never synced: domains empty, lastSyncedAt null, lastError set.
    seedSlice('porkbun', [], { lastSyncedAt: null, lastError: 'boom' });
    const p = getCachedPortfolio()!;
    expect(p.registrars).toEqual(['dynadot']);
    expect(p.errors).toEqual([
      {
        registrar: 'porkbun',
        accountId: 'porkbun',
        accountLabel: 'Default',
        message: 'boom',
      },
    ]);
  });

  it('does not expose credentials or upstream HTML from previously cached sync errors', () => {
    seedSlice('dynadot', [], {
      lastSyncedAt: null,
      lastError:
        "Request to 'https://api.example.test/xml.response?ApiKey=test-secret&ApiUser=private-user' failed with 500 Internal Server Error: <!DOCTYPE html><html>test-secret</html>",
    });
    const messages = [
      getCachedPortfolio()!.errors[0].message,
      getRegistrarMetadata().find((a) => a.accountId === 'dynadot')!.sync
        .lastError,
    ];
    for (const message of messages) {
      expect(message).toContain('500');
      expect(message).not.toMatch(
        /test-secret|private-user|ApiKey|DOCTYPE|<html>/,
      );
    }
  });

  it('keeps the actual proxy refusal in cached portfolio and account diagnostics', () => {
    storedCredentials.dynadot = { apiKey: 'test-secret' };
    seedSlice('dynadot', [], {
      lastSyncedAt: null,
      lastError:
        "Failed to reach 'https://api.dynadot.com/restful/v2/domains?key=test-secret': private transport text [proxy:PROXY_CONNECT_REFUSED:403]",
    });
    for (const message of [
      getCachedPortfolio()!.errors[0].message,
      getRegistrarMetadata().find((a) => a.accountId === 'dynadot')!.sync
        .lastError,
    ]) {
      expect(message).toBe(
        'The fixed-IP proxy refused the connection (HTTP 403). The registrar was not contacted.',
      );
      expect(message).not.toMatch(/test-secret|private transport/);
    }
  });

  it('hides cached rows that have no domain name', () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot' }),
      domain({ domainName: '', registrar: 'dynadot' }),
      domain({ domainName: '  ', registrar: 'dynadot' }),
    ]);
    const p = getCachedPortfolio()!;
    expect(p.domains.map((d) => d.domainName)).toEqual(['a.com']);
  });
});

describe('getMergedPortfolio', () => {
  it('overlays cached detail onto the portfolio row', () => {
    seedSlice('dynadot', [
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        nameservers: ['old.ns'],
      }),
    ]);
    store.detail['dynadot:a.com'] = {
      data: { nameservers: ['new.ns'], privacy: true },
      fetchedAt: Date.now(),
    };
    const merged = getMergedPortfolio();
    expect(merged.domains[0].nameservers).toEqual(['new.ns']);
    expect(merged.domains[0].privacy).toBe(true);
  });

  it('leaves rows without detail untouched', () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot' }),
    ]);
    expect(getMergedPortfolio().domains[0].nameservers).toEqual([]);
  });

  it('returns an empty shape when nothing is cached', () => {
    expect(getMergedPortfolio()).toEqual({
      domains: [],
      fetchedAt: null,
      registrars: [],
      errors: [],
    });
  });
});

describe('syncRegistrarInto — last-good on error (via getPortfolio)', () => {
  it('reconciles renewed expiry dates without dropping cached detail or quotes', async () => {
    const oldExpiry = new Date('2026-10-14T12:00:54.000Z');
    const newExpiry = new Date('2027-10-14T12:00:54.000Z');
    const old = domain({
      domainName: 'example.you',
      registrar: 'dynadot',
      expirationDate: oldExpiry,
      renewalDate: oldExpiry,
      nameservers: ['ns1.dyna-ns.net'],
    });
    seedSlice('dynadot', [old]);
    const otherAccount = { data: old, fetchedAt: 100 };
    store.detail['other-account:example.you'] = otherAccount;
    store.detail['dynadot:example.you'] = {
      data: {
        ...old,
        renewalQuote: { renewal: 55, currency: 'USD' },
        renewalQuoteFetchedAt: 123,
      },
      fetchedAt: 123,
    };
    listPortfolio.mockResolvedValue({
      domains: [
        {
          ...old,
          expirationDate: newExpiry,
          renewalDate: newExpiry,
          nameservers: [],
        },
      ],
      errors: [],
    });

    await syncRegistrar('dynadot');

    expect(getMergedPortfolio().domains[0]).toMatchObject({
      expirationDate: newExpiry,
      renewalDate: newExpiry,
      nameservers: ['ns1.dyna-ns.net'],
    });
    expect(await getDomainDetail('dynadot', 'example.you')).toMatchObject({
      expirationDate: newExpiry,
      renewalDate: newExpiry,
    });
    expect(store.detail['dynadot:example.you']).toMatchObject({
      fetchedAt: 123,
      data: {
        renewalQuote: { renewal: 55, currency: 'USD' },
        renewalQuoteFetchedAt: 123,
      },
    });
    expect(store.detail['other-account:example.you']).toEqual(otherAccount);
  });

  it.each(['missing dates', 'failed sync'])(
    'retains known detail dates on %s and leaves other accounts untouched',
    async (scenario) => {
      const expiry = new Date('2027-10-14T12:00:54.000Z');
      const old = domain({
        domainName: 'example.you',
        registrar: 'dynadot',
        expirationDate: expiry,
        renewalDate: expiry,
      });
      seedSlice('dynadot', [old]);
      const cached = { data: old, fetchedAt: 123 };
      store.detail['dynadot:example.you'] = cached;
      store.detail['other-account:example.you'] = cached;
      listPortfolio.mockResolvedValue({
        domains: [domain({ domainName: 'example.you', registrar: 'dynadot' })],
        errors:
          scenario === 'failed sync'
            ? [{ registrar: 'dynadot', error: new Error('unavailable') }]
            : [],
      });

      await syncRegistrar('dynadot');

      expect(store.detail['dynadot:example.you']).toEqual(cached);
      expect(store.detail['other-account:example.you']).toEqual(cached);
      expect(getMergedPortfolio().domains[0].expirationDate).toEqual(expiry);
    },
  );

  it('replaces the slice and clears the error on success', async () => {
    seedSlice('dynadot', [], { lastSyncedAt: 1, lastError: 'old' });
    listPortfolio.mockImplementation(async (clients: unknown[]) => {
      void clients;
      return {
        domains: [domain({ domainName: 'fresh.com', registrar: 'dynadot' })],
        errors: [],
      };
    });
    // Only sync dynadot: disable porkbun so it's skipped.
    enabled.porkbun = false;

    const p = await getPortfolio(true);
    expect(p.domains.map((d) => d.domainName)).toEqual(['fresh.com']);
    expect(p.errors).toEqual([]);
    expect(
      (store.portfolio.dynadot.data as { lastError: string | null }).lastError,
    ).toBeNull();
  });

  it('drops listed rows that have no domain name', async () => {
    enabled.porkbun = false;
    listPortfolio.mockResolvedValue({
      domains: [
        domain({ domainName: 'named.com', registrar: 'dynadot' }),
        domain({ domainName: '', registrar: 'dynadot' }),
      ],
      errors: [],
    });

    const p = await getPortfolio(true);
    expect(p.domains.map((d) => d.domainName)).toEqual(['named.com']);
    const slice = store.portfolio.dynadot.data as { domains: Domain[] };
    expect(slice.domains.map((d) => d.domainName)).toEqual(['named.com']);
  });

  it('keeps last-good domains and lastSyncedAt when the list reports an error', async () => {
    seedSlice(
      'dynadot',
      [domain({ domainName: 'kept.com', registrar: 'dynadot' })],
      {
        lastSyncedAt: 4242,
      },
    );
    enabled.porkbun = false;
    listPortfolio.mockResolvedValue({
      domains: [],
      errors: [{ error: new Error('rate limited') }],
    });

    const p = await getPortfolio(true);
    expect(p.domains.map((d) => d.domainName)).toEqual(['kept.com']);
    const slice = store.portfolio.dynadot.data as {
      domains: Domain[];
      lastSyncedAt: number | null;
      lastError: string | null;
    };
    expect(slice.lastSyncedAt).toBe(4242);
    expect(slice.lastError).toBe('rate limited');
    expect(p.errors).toEqual([
      {
        registrar: 'dynadot',
        accountId: 'dynadot',
        accountLabel: 'Default',
        message: 'rate limited',
      },
    ]);
  });

  it('keeps last-good domains when listPortfolio throws', async () => {
    seedSlice(
      'dynadot',
      [domain({ domainName: 'kept.com', registrar: 'dynadot' })],
      {
        lastSyncedAt: 99,
      },
    );
    enabled.porkbun = false;
    listPortfolio.mockRejectedValue(new Error('network down'));

    const p = await getPortfolio(true);
    expect(p.domains.map((d) => d.domainName)).toEqual(['kept.com']);
    expect(
      (store.portfolio.dynadot.data as { lastError: string | null }).lastError,
    ).toBe('network down');
  });
});

describe('syncRegistrar — cache lifecycle', () => {
  it('clears a registrar that is no longer configured', async () => {
    seedSlice('cloudflare', [
      domain({ domainName: 'c.com', registrar: 'cloudflare' }),
    ]);
    // cloudflare has no stored credentials → not configured.
    await syncRegistrar('cloudflare');
    expect(store.portfolio.cloudflare).toBeUndefined();
  });

  it('keeps a configured-but-disabled account’s cached slice', async () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot' }),
    ]);
    // Disabling keeps credentials and cache; syncing a disabled account must
    // not fetch and must not wipe the last-good slice.
    enabled.dynadot = false;
    await syncRegistrar('dynadot');
    expect(listPortfolio).not.toHaveBeenCalled();
    expect(store.portfolio.dynadot).toBeDefined();
  });
});

describe('GoDaddy shopper renewal quotes on sync', () => {
  const gd = (domainName: string) =>
    domain({ domainName, registrar: 'godaddy' });
  const quotedNames = () =>
    clientMethods.getPricing.mock.calls.map(([name]) => name as string);

  beforeEach(() => {
    // GoDaddy alone, so the quote calls below belong to this account.
    delete storedCredentials.dynadot;
    delete storedCredentials.porkbun;
    storedCredentials.godaddy = { apiToken: 'pat' };
  });

  it('prices each TLD off a dummy name and quotes premiums per name', async () => {
    listPortfolio.mockResolvedValue({
      domains: [gd('404cosgrove.com'), gd('cheap.io'), gd('fancy.io')],
      errors: [],
    });
    clientMethods.checkAvailability.mockResolvedValue([
      { domainName: 'cheap.io', available: false, premium: false },
      { domainName: 'fancy.io', available: false, premium: true },
    ]);
    clientMethods.getPricing.mockImplementation(async (name: string) => {
      // A name you already own comes back with no prices at all — quoting one
      // is what left every .com on the bundled list rate.
      if (name === '404cosgrove.com') return { tld: 'com', currency: 'USD' };
      if (name === 'fancy.io')
        return { tld: 'io', currency: 'USD', renewal: 199 };
      return name.endsWith('.com')
        ? { tld: 'com', currency: 'USD', registration: 11.99, renewal: 8.99 }
        : { tld: 'io', currency: 'USD', registration: 44, renewal: 44 };
    });

    await getPortfolio(true);

    expect(setTldRate.mock.calls).toEqual([
      ['godaddy', 'com', 8.99, 'godaddy'],
      ['godaddy', 'io', 44, 'godaddy'],
    ]);
    // One .com quote, and it was a dummy rather than the owned name.
    expect(quotedNames()).not.toContain('404cosgrove.com');
    expect(quotedNames().filter((n) => n.endsWith('.com'))).toHaveLength(1);
    expect(store.detail['godaddy:fancy.io'].data).toMatchObject({
      renewalQuote: { renewal: 199, currency: 'USD' },
    });
    // Standard names ride the TLD rate; nothing per-name is stored for them.
    expect(store.detail['godaddy:cheap.io']).toBeUndefined();
  });

  it('reads a register-only quote as the renewal rate', async () => {
    listPortfolio.mockResolvedValue({ domains: [gd('a.com')], errors: [] });
    // v3 omits renewalPrice when it matches the register price.
    clientMethods.getPricing.mockResolvedValue({
      tld: 'com',
      currency: 'USD',
      registration: 21.99,
    });

    await getPortfolio(true);

    expect(setTldRate.mock.calls).toEqual([
      ['godaddy', 'com', 21.99, 'godaddy'],
    ]);
    // .com carries no premium names, so no availability check is needed.
    expect(clientMethods.checkAvailability).not.toHaveBeenCalled();
  });

  it('leaves a TLD unpriced when the quote carries no prices at all', async () => {
    listPortfolio.mockResolvedValue({ domains: [gd('a.com')], errors: [] });
    clientMethods.getPricing.mockResolvedValue({ tld: 'com', currency: 'USD' });

    await getPortfolio(true);

    expect(setTldRate).not.toHaveBeenCalled();
    // Two dummies plus the owned name before giving up on the TLD.
    expect(quotedNames()).toHaveLength(3);
    expect(quotedNames().at(-1)).toBe('a.com');
  });

  it('falls back to the owned name when the dummy quotes fail', async () => {
    listPortfolio.mockResolvedValue({ domains: [gd('a.com')], errors: [] });
    clientMethods.getPricing.mockImplementation(async (name: string) => {
      if (name === 'a.com')
        return { tld: 'com', currency: 'USD', renewal: 9.5 };
      throw new Error('rate limited');
    });

    await getPortfolio(true);

    expect(setTldRate.mock.calls).toEqual([['godaddy', 'com', 9.5, 'godaddy']]);
    expect(quotedNames().at(-1)).toBe('a.com');
  });

  it('stores no per-name quote when a premium name comes back priceless', async () => {
    listPortfolio.mockResolvedValue({
      domains: [gd('cheap.io'), gd('fancy.io')],
      errors: [],
    });
    clientMethods.checkAvailability.mockResolvedValue([
      { domainName: 'cheap.io', available: false, premium: false },
      { domainName: 'fancy.io', available: false, premium: true },
    ]);
    clientMethods.getPricing.mockImplementation(async (name: string) =>
      // The known gap: an owned premium name reports no prices, so it has to
      // ride the TLD rate rather than pin an empty entry over it.
      name === 'fancy.io'
        ? { tld: 'io', currency: 'USD' }
        : { tld: 'io', currency: 'USD', renewal: 44 },
    );

    await getPortfolio(true);

    expect(setTldRate.mock.calls).toEqual([['godaddy', 'io', 44, 'godaddy']]);
    expect(store.detail['godaddy:fancy.io']).toBeUndefined();
  });

  it('still samples one name per TLD when the availability check fails', async () => {
    listPortfolio.mockResolvedValue({
      domains: [gd('cheap.io'), gd('fancy.io')],
      errors: [],
    });
    clientMethods.checkAvailability.mockRejectedValue(new Error('429'));
    clientMethods.getPricing.mockResolvedValue({
      tld: 'io',
      currency: 'USD',
      renewal: 44,
    });

    await getPortfolio(true);

    // Unknown flags mean no per-name premium quotes, but the TLD still prices.
    expect(setTldRate.mock.calls).toEqual([['godaddy', 'io', 44, 'godaddy']]);
    expect(store.detail['godaddy:fancy.io']).toBeUndefined();
  });
});

describe('Namecheap account TLD rates on sync', () => {
  const nc = (domainName: string) =>
    domain({ domainName, registrar: 'namecheap' });
  const tldOfName = (name: string) => name.slice(name.indexOf('.') + 1);
  const pricedTlds = () =>
    clientMethods.getPricing.mock.calls.map(([name]) =>
      tldOfName(name as string),
    );

  beforeEach(() => {
    delete storedCredentials.dynadot;
    delete storedCredentials.porkbun;
    storedCredentials.namecheap = { apiKey: 'k' };
    clientMethods.checkAvailability.mockResolvedValue([]);
  });

  it('stores the account renewal price once per distinct TLD', async () => {
    listPortfolio.mockResolvedValue({
      domains: [nc('a.com'), nc('b.com'), nc('c.io')],
      errors: [],
    });
    clientMethods.getPricing.mockImplementation(async (name: string) => {
      const tld = tldOfName(name);
      return tld === 'com'
        ? { tld, currency: 'USD', registration: 11.28, renewal: 13.98 }
        : { tld, currency: 'USD', registration: 34.98, renewal: 52.98 };
    });

    await getPortfolio(true);

    expect(pricedTlds()).toEqual(['com', 'io']);
    expect(setTldRate.mock.calls).toEqual([
      ['namecheap', 'com', 13.98, 'namecheap'],
      ['namecheap', 'io', 52.98, 'namecheap'],
    ]);
    // A TLD rate only — nothing per-name lands in the detail cache.
    expect(store.detail).toEqual({});
  });

  it('prices a multi-part TLD as a whole', async () => {
    listPortfolio.mockResolvedValue({ domains: [nc('a.br.com')], errors: [] });
    clientMethods.getPricing.mockResolvedValue({
      tld: 'br.com',
      currency: 'USD',
      renewal: 44.98,
    });

    await getPortfolio(true);

    // The client keeps what follows the first dot, so this is quoted as br.com.
    expect(clientMethods.getPricing).toHaveBeenCalledWith('example.br.com');
    expect(setTldRate.mock.calls).toEqual([
      ['namecheap', 'br.com', 44.98, 'namecheap'],
    ]);
  });

  it('keeps the existing rate for a TLD that comes back unpriced', async () => {
    listPortfolio.mockResolvedValue({
      domains: [nc('a.com'), nc('b.io'), nc('c.eu')],
      errors: [],
    });
    clientMethods.getPricing.mockImplementation(async (name: string) => {
      const tld = tldOfName(name);
      if (tld === 'com') return { tld, currency: 'USD' };
      if (tld === 'io') return { tld, currency: 'EUR', renewal: 40 };
      return { tld, currency: 'USD', renewal: 8.98 };
    });

    await getPortfolio(true);

    expect(setTldRate.mock.calls).toEqual([
      ['namecheap', 'eu', 8.98, 'namecheap'],
    ]);
  });

  it('stops pricing after the first failed call', async () => {
    listPortfolio.mockResolvedValue({
      domains: [nc('a.com'), nc('b.io'), nc('c.eu')],
      errors: [],
    });
    clientMethods.getPricing.mockImplementation(async (name: string) => {
      const tld = tldOfName(name);
      if (tld === 'io') throw new Error('Too many requests');
      return { tld, currency: 'USD', renewal: 13.98 };
    });

    await getPortfolio(true);

    expect(pricedTlds()).toEqual(['com', 'io']);
    expect(setTldRate.mock.calls).toEqual([
      ['namecheap', 'com', 13.98, 'namecheap'],
    ]);
  });
});

describe('Namecheap premium renewal quotes on sync', () => {
  const nc = (domainName: string) =>
    domain({ domainName, registrar: 'namecheap' });
  const checkedNames = () =>
    clientMethods.checkAvailability.mock.calls.flatMap(
      ([names]) => names as string[],
    );

  beforeEach(() => {
    delete storedCredentials.dynadot;
    delete storedCredentials.porkbun;
    storedCredentials.namecheap = { apiKey: 'k' };
    clientMethods.getPricing.mockResolvedValue({
      tld: 'io',
      currency: 'USD',
      renewal: 52.98,
    });
  });

  it('stores the premium renewal price for premium names only', async () => {
    listPortfolio.mockResolvedValue({
      domains: [nc('plain.com'), nc('cheap.io'), nc('fancy.io')],
      errors: [],
    });
    clientMethods.checkAvailability.mockResolvedValue([
      { domainName: 'cheap.io', available: false, premium: false },
      {
        domainName: 'fancy.io',
        available: false,
        premium: true,
        price: 1500,
        renewalPrice: 1200,
      },
    ]);

    await getPortfolio(true);

    // .com carries no premium names, so only the .io names are checked.
    expect(checkedNames()).toEqual(['cheap.io', 'fancy.io']);
    expect(store.detail['namecheap:fancy.io'].data).toEqual({
      renewalQuote: { renewal: 1200, currency: 'USD' },
      renewalQuoteFetchedAt: expect.any(Number),
    });
    expect(store.detail['namecheap:cheap.io']).toBeUndefined();
  });

  it('checks 50 names per call', async () => {
    const names = Array.from({ length: 51 }, (_, i) => `n${i}.io`);
    listPortfolio.mockResolvedValue({ domains: names.map(nc), errors: [] });

    await getPortfolio(true);

    expect(
      clientMethods.checkAvailability.mock.calls.map(([n]) => n.length),
    ).toEqual([50, 1]);
  });

  it('drops a stored premium quote once the name checks as standard', async () => {
    listPortfolio.mockResolvedValue({ domains: [nc('was.io')], errors: [] });
    store.detail['namecheap:was.io'] = {
      data: {
        autoRenew: true,
        renewalQuote: { renewal: 900, currency: 'USD' },
      },
      fetchedAt: 123,
    };
    clientMethods.checkAvailability.mockResolvedValue([
      { domainName: 'was.io', available: false, premium: false },
    ]);

    await getPortfolio(true);

    // The detail stays, with its age, minus the quote.
    expect(store.detail['namecheap:was.io']).toEqual({
      data: { autoRenew: true },
      fetchedAt: 123,
    });
  });

  it('keeps a stored quote when the check omits the premium flag', async () => {
    listPortfolio.mockResolvedValue({ domains: [nc('fancy.io')], errors: [] });
    const quote = { renewalQuote: { renewal: 1200, currency: 'USD' } };
    store.detail['namecheap:fancy.io'] = { data: quote, fetchedAt: 1 };
    clientMethods.checkAvailability.mockResolvedValue([
      { domainName: 'fancy.io', available: false },
    ]);

    await getPortfolio(true);

    expect(store.detail['namecheap:fancy.io'].data).toEqual(quote);
  });

  it('keeps stored quotes when the check fails', async () => {
    listPortfolio.mockResolvedValue({ domains: [nc('fancy.io')], errors: [] });
    const quote = { renewalQuote: { renewal: 1200, currency: 'USD' } };
    store.detail['namecheap:fancy.io'] = { data: quote, fetchedAt: 1 };
    clientMethods.checkAvailability.mockRejectedValue(new Error('rate limit'));

    await getPortfolio(true);

    expect(store.detail['namecheap:fancy.io'].data).toEqual(quote);
  });

  it('skips the premium check when the TLD pass fails', async () => {
    listPortfolio.mockResolvedValue({ domains: [nc('fancy.io')], errors: [] });
    clientMethods.getPricing.mockRejectedValue(new Error('rate limit'));

    await getPortfolio(true);

    expect(clientMethods.checkAvailability).not.toHaveBeenCalled();
  });

  it('serves the stored premium quote to a live price lookup', async () => {
    seedSlice('namecheap', [nc('fancy.io')]);
    const quote = { renewal: 1200, currency: 'USD' };
    store.detail['namecheap:fancy.io'] = {
      data: { renewalQuote: quote },
      fetchedAt: 1,
    };
    resolvePricing.mockReturnValue({ domain: 'fancy.io', source: 'api' });

    await getRenewalPriceLive('namecheap', 'fancy.io');

    expect(resolvePricing).toHaveBeenCalledWith(
      'namecheap',
      'fancy.io',
      quote,
      'namecheap',
    );
    expect(clientMethods.getPricing).not.toHaveBeenCalled();
  });
});

describe('getRegistrationQuote', () => {
  it('returns no fee when the registrar has no pricing API', async () => {
    clientMethods.getPricing.mockRejectedValue(
      new NotImplementedError('spaceship: getPricing is not available'),
    );
    await expect(
      getRegistrationQuote('dynadot', 'backyard.green'),
    ).resolves.toEqual({
      amount: null,
      currency: 'USD',
    });
  });

  it('returns no fee, not dollars, for a currency code it doesn’t know', async () => {
    clientMethods.getPricing.mockResolvedValue({
      tld: 'green',
      currency: 'XYZ',
      registration: 4.5,
    });
    await expect(
      getRegistrationQuote('dynadot', 'backyard.green'),
    ).resolves.toEqual({ amount: null, currency: 'USD' });
  });

  it('returns the registration fee when the registrar quotes one', async () => {
    clientMethods.getPricing.mockResolvedValue({
      tld: 'green',
      currency: 'USD',
      registration: 4.5,
    });
    await expect(
      getRegistrationQuote('dynadot', 'backyard.green'),
    ).resolves.toEqual({
      amount: '4.50',
      currency: 'USD',
    });
  });
});

describe('cache patching via setAutoRenewCached', () => {
  it('patches both caches on success', async () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot', autoRenew: false }),
    ]);
    store.detail['dynadot:a.com'] = {
      data: { autoRenew: false },
      fetchedAt: 111,
    };
    clientMethods.setAutoRenew.mockResolvedValue({
      success: true,
      message: 'ok',
    });

    const r = await setAutoRenewCached('dynadot', 'a.com', true);
    expect(r.success).toBe(true);
    expect(
      (store.portfolio.dynadot.data as { domains: Domain[] }).domains[0]
        .autoRenew,
    ).toBe(true);
    expect(
      (store.detail['dynadot:a.com'].data as Partial<Domain>).autoRenew,
    ).toBe(true);
    // patchEntryData preserves fetchedAt.
    expect(store.detail['dynadot:a.com'].fetchedAt).toBe(111);
  });

  it('does not patch on a soft failure', async () => {
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot', autoRenew: false }),
    ]);
    clientMethods.setAutoRenew.mockResolvedValue({
      success: false,
      message: 'nope',
    });

    const r = await setAutoRenewCached('dynadot', 'a.com', true);
    expect(r.success).toBe(false);
    expect(
      (store.portfolio.dynadot.data as { domains: Domain[] }).domains[0]
        .autoRenew,
    ).toBe(false);
  });
});

const sliceDomain = (name = 'dynadot') =>
  (store.portfolio[name].data as { domains: Domain[] }).domains[0];

describe('setLockCached / setPrivacyCached / setNameserversCached', () => {
  it('does not replace active nameservers in either cache for an accepted pending change', async () => {
    const current = ['ns1.old.net', 'ns2.old.net'];
    seedSlice('dynadot', [
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        nameservers: current,
      }),
    ]);
    store.detail['dynadot:a.com'] = {
      data: { nameservers: current },
      fetchedAt: 111,
    };
    clientMethods.updateNameservers.mockResolvedValue({
      success: true,
      pending: true,
      message: 'Pending registry processing',
    });
    const result = await setNameserversCached('dynadot', 'a.com', [
      'ns1.new.net',
      'ns2.new.net',
    ]);
    expect(result).toMatchObject({ success: true, pending: true });
    expect(sliceDomain().nameservers).toEqual(current);
    expect(
      (store.detail['dynadot:a.com'].data as Partial<Domain>).nameservers,
    ).toEqual(current);
  });
  beforeEach(() =>
    seedSlice('dynadot', [
      domain({ domainName: 'a.com', registrar: 'dynadot' }),
    ]),
  );

  it('lock calls lockDomain and patches on success', async () => {
    clientMethods.lockDomain.mockResolvedValue({ success: true, message: '' });
    await setLockCached('dynadot', 'a.com', true);
    expect(clientMethods.lockDomain).toHaveBeenCalled();
    expect(clientMethods.unlockDomain).not.toHaveBeenCalled();
    expect(sliceDomain().locked).toBe(true);
  });

  it('unlock calls unlockDomain', async () => {
    clientMethods.unlockDomain.mockResolvedValue({
      success: true,
      message: '',
    });
    await setLockCached('dynadot', 'a.com', false);
    expect(clientMethods.unlockDomain).toHaveBeenCalled();
    expect(sliceDomain().locked).toBe(false);
  });

  it('privacy patches on success', async () => {
    clientMethods.setPrivacy.mockResolvedValue({ success: true, message: '' });
    await setPrivacyCached('dynadot', 'a.com', true);
    expect(sliceDomain().privacy).toBe(true);
  });

  it('nameservers patches on success and not on failure', async () => {
    clientMethods.updateNameservers.mockResolvedValue({
      success: true,
      message: '',
    });
    await setNameserversCached('dynadot', 'a.com', ['ns1.x', 'ns2.x']);
    expect(sliceDomain().nameservers).toEqual(['ns1.x', 'ns2.x']);

    clientMethods.updateNameservers.mockResolvedValue({
      success: false,
      message: 'no',
    });
    await setNameserversCached('dynadot', 'a.com', ['ns3.x']);
    expect(sliceDomain().nameservers).toEqual(['ns1.x', 'ns2.x']); // unchanged
  });
});

describe('renewDomainCached', () => {
  beforeEach(() =>
    seedSlice('dynadot', [
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        expirationDate: new Date('2026-01-01'),
      }),
    ]),
  );

  it('re-fetches detail and returns + patches the fresh expiry on success', async () => {
    clientMethods.renewDomain.mockResolvedValue({
      success: true,
      message: 'Renewed',
    });
    // getDomainDetail(refresh:true) → client.getDomain returns the new record.
    clientMethods.getDomain.mockResolvedValue(
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        expirationDate: new Date('2027-01-01'),
        status: 'active',
        nameservers: ['ns1.x'],
      }),
    );

    const { result, patch } = await renewDomainCached('dynadot', 'a.com', 1);
    expect(result.success).toBe(true);
    expect(patch.expirationDate).toEqual(new Date('2027-01-01'));
    // Portfolio slice patched with the new expiry too.
    expect(sliceDomain().expirationDate).toEqual(new Date('2027-01-01'));
  });

  it('returns an empty patch and swallows a re-fetch failure', async () => {
    clientMethods.renewDomain.mockResolvedValue({
      success: true,
      message: 'Renewed',
    });
    clientMethods.getDomain.mockRejectedValue(new Error('detail down'));
    clientMethods.getNameservers.mockRejectedValue(new Error('no ns'));

    const { result, patch } = await renewDomainCached('dynadot', 'a.com', 1);
    expect(result.success).toBe(true);
    expect(patch).toEqual({});
    // Original expiry untouched.
    expect(sliceDomain().expirationDate).toEqual(new Date('2026-01-01'));
  });

  it('does not re-fetch on a soft failure', async () => {
    clientMethods.renewDomain.mockResolvedValue({
      success: false,
      message: 'declined',
    });
    const { result, patch } = await renewDomainCached('dynadot', 'a.com', 1);
    expect(result.success).toBe(false);
    expect(patch).toEqual({});
    expect(clientMethods.getDomain).not.toHaveBeenCalled();
  });
});

describe('registerDomainCached', () => {
  it('syncs the registrar slice on success so the new name enters the cache', async () => {
    clientMethods.registerDomain.mockResolvedValue({
      success: true,
      message: 'Registered',
    });
    listPortfolio.mockResolvedValue({
      domains: [domain({ domainName: 'new.com', registrar: 'dynadot' })],
      errors: [],
    });

    const r = await registerDomainCached('dynadot', 'new.com', {} as never);
    expect(r.success).toBe(true);
    expect(listPortfolio).toHaveBeenCalledTimes(1);
    expect(
      (store.portfolio.dynadot.data as { domains: Domain[] }).domains[0]
        .domainName,
    ).toBe('new.com');
  });

  it('does not sync on a failed registration', async () => {
    clientMethods.registerDomain.mockResolvedValue({
      success: false,
      message: 'taken',
    });
    const r = await registerDomainCached('dynadot', 'new.com', {} as never);
    expect(r.success).toBe(false);
    expect(listPortfolio).not.toHaveBeenCalled();
  });
});

describe('getDomainDetail — nameserver resolution', () => {
  it('serves a fresh cached entry without a network call', async () => {
    store.detail['dynadot:a.com'] = {
      data: { nameservers: ['cached.ns'] },
      fetchedAt: Date.now(),
    };
    const detail = await getDomainDetail('dynadot', 'a.com');
    expect(detail).toEqual({
      nameservers: ['cached.ns'],
      registrar: 'dynadot',
      accountId: 'dynadot',
      accountLabel: 'Default',
    });
    expect(clientMethods.getDomain).not.toHaveBeenCalled();
  });

  it('falls back to the registrar nameserver endpoint when getDomain has none', async () => {
    clientMethods.getDomain.mockResolvedValue(
      domain({ domainName: 'a.com', registrar: 'dynadot', nameservers: [] }),
    );
    clientMethods.getNameservers.mockResolvedValue(['reg.ns1', 'reg.ns2']);
    const detail = await getDomainDetail('dynadot', 'a.com', true);
    expect(detail?.nameservers).toEqual(['reg.ns1', 'reg.ns2']);
  });

  // Normalization (case, trailing dot) is the DNS module's job — see
  // core/dns.test.ts. Here the resolver already returns clean names.
  it('falls back to a live DNS query', async () => {
    clientMethods.getDomain.mockResolvedValue(
      domain({ domainName: 'a.com', registrar: 'dynadot', nameservers: [] }),
    );
    clientMethods.getNameservers.mockResolvedValue([]);
    resolveNs.mockResolvedValue(['ns1.cloudflare.com', 'ns2.cloudflare.com']);
    const detail = await getDomainDetail('dynadot', 'a.com', true);
    expect(detail?.nameservers).toEqual([
      'ns1.cloudflare.com',
      'ns2.cloudflare.com',
    ]);
  });

  it('returns null when nothing resolves and there is no prior entry', async () => {
    clientMethods.getDomain.mockRejectedValue(new Error('no detail'));
    clientMethods.getNameservers.mockRejectedValue(new Error('no ns'));
    resolveNs.mockRejectedValue(new Error('nxdomain'));
    const detail = await getDomainDetail('dynadot', 'a.com', true);
    expect(detail).toBeNull();
  });
});

it('records actual Dynadot manual, MCP and scheduled inventory attempts through recovery', async () => {
  configureSyncDiagnostics(true);
  try {
    listPortfolio.mockRejectedValueOnce(
      new Error('proxy [' + 'proxy:PROXY_QUEUE_TIMEOUT] key=secret'),
    );
    await syncRegistrar('dynadot', undefined, 'manual');
    listPortfolio.mockResolvedValue({ domains: [], errors: [] });
    await syncRegistrar('dynadot', undefined, 'mcp');
    await getPortfolio(true, 'scheduled');
    await flushWrites();
    const diagnostics = syncDiagnosticsSchema.parse(
      await getStore().get('sync-monitor', 'diagnostics'),
    );
    expect(diagnostics.events.map((e) => [e.ok, e.code, e.trigger])).toEqual([
      [false, 'queue_timeout', 'manual'],
      [true, 'none', 'mcp'],
      [true, 'none', 'scheduled'],
    ]);
    expect(JSON.stringify(diagnostics)).not.toContain('secret');
  } finally {
    configureSyncDiagnostics(false);
  }
});

describe('LIST_ONLY_FIELDS', () => {
  it('matches registrar-client’s listOnlyFields for every registrar', async () => {
    // The real library, not this file's mock of its catalog.
    const actual = await vi.importActual<
      typeof import('@aoxborrow/registrar-client')
    >('@aoxborrow/registrar-client');
    const names = Object.keys(actual.registrars) as RegistrarName[];
    const library = Object.fromEntries(
      names.map((n) => [n, actual.createRegistrar(n, {}).listOnlyFields ?? []]),
    );
    const ours = Object.fromEntries(
      names.map((n) => [n, LIST_ONLY_FIELDS[n] ?? []]),
    );
    expect(ours).toEqual(library);
  });
});

describe('Namecheap detail', () => {
  const nc = (d: Partial<Domain> & { domainName: string }) =>
    domain({ registrar: 'namecheap', ...d });
  const quote = { renewal: 1200, currency: 'USD' };

  beforeEach(() => {
    storedCredentials.namecheap = { apiKey: 'k' };
  });

  it('keeps the list’s auto-renew over a detail read that can’t see it', async () => {
    seedSlice('namecheap', [nc({ domainName: 'a.com', autoRenew: true })]);
    // registrar-client's getInfo-based read fills a default "off".
    clientMethods.getDomain.mockResolvedValue(
      nc({ domainName: 'a.com', autoRenew: false, locked: true }),
    );
    clientMethods.getNameservers.mockResolvedValue(['ns1.x', 'ns2.x']);

    const detail = await getDomainDetail('namecheap', 'a.com', true);

    expect(detail).not.toHaveProperty('autoRenew');
    expect(detail?.locked).toBe(true);
    expect(store.detail['namecheap:a.com'].data).not.toHaveProperty(
      'autoRenew',
    );
    const [row] = getMergedPortfolio().domains;
    expect(row.autoRenew).toBe(true);
    expect(row.locked).toBe(true);
  });

  it('ignores the auto-renew an older version cached', () => {
    seedSlice('namecheap', [nc({ domainName: 'a.com', autoRenew: true })]);
    store.detail['namecheap:a.com'] = {
      data: { nameservers: ['ns1.x'], autoRenew: false, locked: true },
      fetchedAt: Date.now(),
    };
    const [row] = getMergedPortfolio().domains;
    expect(row.autoRenew).toBe(true);
    expect(row.locked).toBe(true);
  });

  it('still takes auto-renew from detail at a registrar whose list omits it', async () => {
    clientMethods.getDomain.mockResolvedValue(
      domain({
        domainName: 'a.com',
        registrar: 'dynadot',
        autoRenew: true,
        nameservers: ['ns1.x'],
      }),
    );
    const detail = await getDomainDetail('dynadot', 'a.com', true);
    expect(detail?.autoRenew).toBe(true);
  });

  it('reads a premium name whose entry holds only the quote Sync stored', async () => {
    seedSlice('namecheap', [nc({ domainName: 'nerd.id' })]);
    store.detail['namecheap:nerd.id'] = {
      data: {
        renewalQuote: quote,
        expirationDate: '2027-01-01T00:00:00.000Z',
      },
      fetchedAt: Date.now(),
    };
    // Not detail yet: the overlay leaves the row alone…
    expect(getMergedPortfolio().domains[0].nameservers).toEqual([]);

    clientMethods.getDomain.mockResolvedValue(
      nc({ domainName: 'nerd.id', locked: true }),
    );
    clientMethods.getNameservers.mockResolvedValue([
      'ns1.afternic.com',
      'ns2.afternic.com',
    ]);
    // …and a cache-first read goes to the registrar.
    const detail = await getDomainDetail('namecheap', 'nerd.id');

    expect(clientMethods.getDomain).toHaveBeenCalledTimes(1);
    expect(detail?.nameservers).toEqual([
      'ns1.afternic.com',
      'ns2.afternic.com',
    ]);
    expect(detail?.locked).toBe(true);
    expect(store.detail['namecheap:nerd.id'].data).toMatchObject({
      renewalQuote: quote,
      locked: true,
    });
  });

  it('stores a premium quote without making old detail look fresh', async () => {
    listPortfolio.mockResolvedValue({
      domains: [nc({ domainName: 'fancy.io' })],
      errors: [],
    });
    clientMethods.getPricing.mockResolvedValue({
      tld: 'io',
      currency: 'USD',
      renewal: 52.98,
    });
    clientMethods.checkAvailability.mockResolvedValue([
      {
        domainName: 'fancy.io',
        available: false,
        premium: true,
        renewalPrice: 1200,
      },
    ]);
    store.detail['namecheap:fancy.io'] = {
      data: { nameservers: ['ns1.x'], locked: true },
      fetchedAt: 1,
    };

    await getPortfolio(true);

    expect(store.detail['namecheap:fancy.io']).toEqual({
      data: {
        nameservers: ['ns1.x'],
        locked: true,
        renewalQuote: quote,
        renewalQuoteFetchedAt: expect.any(Number),
      },
      fetchedAt: 1,
    });
  });

  it('keeps an earlier read’s lock when the registrar’s detail fails', async () => {
    store.detail['namecheap:a.com'] = {
      data: {
        nameservers: ['old.ns'],
        locked: true,
        privacy: true,
        renewalQuote: quote,
      },
      fetchedAt: 1,
    };
    clientMethods.getDomain.mockRejectedValue(new Error('no detail'));
    clientMethods.getNameservers.mockRejectedValue(new Error('no ns'));
    resolveNs.mockResolvedValue(['ns1.afternic.com', 'ns2.afternic.com']);

    const detail = await getDomainDetail('namecheap', 'a.com', true);

    expect(detail).toMatchObject({
      nameservers: ['ns1.afternic.com', 'ns2.afternic.com'],
      locked: true,
      privacy: true,
    });
    expect(store.detail['namecheap:a.com'].data).toEqual({
      nameservers: ['ns1.afternic.com', 'ns2.afternic.com'],
      locked: true,
      privacy: true,
      renewalQuote: quote,
    });
  });

  it('answers a cache-only read without calling out', async () => {
    store.detail['namecheap:a.com'] = {
      data: { nameservers: ['ns1.x'], locked: true },
      fetchedAt: Date.now(),
    };
    store.detail['namecheap:b.com'] = {
      data: { renewalQuote: quote },
      fetchedAt: Date.now(),
    };

    expect(
      await getDomainDetail('namecheap', 'a.com', false, undefined, true),
    ).toMatchObject({ nameservers: ['ns1.x'], locked: true });
    expect(
      await getDomainDetail('namecheap', 'b.com', false, undefined, true),
    ).toBeNull();
    expect(clientMethods.getDomain).not.toHaveBeenCalled();
    expect(resolveNs).not.toHaveBeenCalled();
  });

  it('leaves the cache alone and says so when the quota is spent', async () => {
    const before = {
      data: { nameservers: ['ns1.x'], locked: true },
      fetchedAt: 1,
    };
    store.detail['namecheap:a.com'] = before;
    // Namecheap's error 500000, which registrar-client raises as a
    // RateLimitError (status 429).
    clientMethods.getDomain.mockRejectedValue(
      new RateLimitError('Too many requests'),
    );

    await expect(getDomainDetail('namecheap', 'a.com', true)).rejects.toThrow(
      /Namecheap rate limit reached/,
    );

    expect(clientMethods.getNameservers).not.toHaveBeenCalled();
    expect(resolveNs).not.toHaveBeenCalled();
    expect(store.detail['namecheap:a.com']).toBe(before);
  });
});

describe('creation date validation and reconciliation', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-11-09T12:00:00Z'));
  });
  afterEach(() => vi.useRealTimers());
  it('suppresses a future provider creation date', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const invalid = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      createdDate: new Date('2026-12-28T00:00:00Z'),
      expirationDate: new Date('2027-12-28T00:00:00Z'),
      nameservers: ['dns1.registrar-servers.com'],
    });
    clientMethods.getDomain.mockResolvedValue(invalid);
    const detail = await getDomainDetail('namecheap', 'two-year.example', true);
    expect(detail?.createdDate).toBeNull();
    expect(detail?.createdDateIssue).toBe('future');
    expect(store.detail['namecheap:two-year.example'].data).toMatchObject({
      createdDate: null,
      createdDateIssue: 'future',
    });
  });

  it('reconciles stale creation detail after corrected inventory sync', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const correct = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      createdDate: new Date('2025-12-28T00:00:00Z'),
      expirationDate: new Date('2027-12-28T00:00:00Z'),
      renewalDate: new Date('2027-12-28T00:00:00Z'),
    });
    seedSlice('namecheap', [correct]);
    const bad = new Date('2026-12-28T00:00:00Z');
    store.detail['namecheap:two-year.example'] = {
      data: {
        ...correct,
        createdDate: bad,
        nameservers: ['dns1.registrar-servers.com'],
      },
      fetchedAt: 1,
    };
    listPortfolio.mockResolvedValue({ domains: [correct], errors: [] });
    await syncRegistrar('namecheap');
    expect(
      getCachedPortfolio()?.domains.find(
        (d) => d.domainName === 'two-year.example',
      )?.createdDate,
    ).toEqual(correct.createdDate);
    expect(
      getMergedPortfolio().domains.find(
        (d) => d.domainName === 'two-year.example',
      )?.createdDate,
    ).toEqual(correct.createdDate);
    expect(store.detail['namecheap:two-year.example'].fetchedAt).toEqual(1);
  });
  it('retains a valid known creation when a fresh list reports a future value', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const correct = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      createdDate: new Date('2025-12-28'),
      expirationDate: new Date('2027-12-28'),
    });
    seedSlice('namecheap', [correct]);
    listPortfolio.mockResolvedValue({
      domains: [{ ...correct, createdDate: new Date('2026-12-28') }],
      errors: [],
    });
    await syncRegistrar('namecheap');
    expect(getMergedPortfolio().domains[0].createdDate).toEqual(
      correct.createdDate,
    );
  });

  it('uses valid inventory when a forced detail read has a future creation', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const correct = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      autoRenew: true,
      createdDate: new Date('2025-12-28'),
      expirationDate: new Date('2027-12-28'),
    });
    seedSlice('namecheap', [correct]);
    clientMethods.getDomain.mockResolvedValue({
      ...correct,
      createdDate: new Date('2026-12-28'),
    });
    const detail = await getDomainDetail('namecheap', 'two-year.example', true);
    expect(detail?.createdDate).toEqual(correct.createdDate);
    expect(detail).not.toHaveProperty('autoRenew');
  });

  it('reconciles creation even when the list omits expiry and keeps quote age and other accounts', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const correct = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      createdDate: new Date('2025-12-28'),
    });
    seedSlice('namecheap', [correct]);
    const other = {
      data: { ...correct, createdDate: new Date('2024-12-28') },
      fetchedAt: 123,
    };
    store.detail['other:two-year.example'] = other;
    store.detail['namecheap:two-year.example'] = {
      data: {
        ...correct,
        createdDate: new Date('2026-12-28'),
        renewalQuote: { renewal: 100, currency: 'USD' },
      },
      fetchedAt: 123,
    };
    listPortfolio.mockResolvedValue({ domains: [correct], errors: [] });
    await syncRegistrar('namecheap');
    expect(store.detail['namecheap:two-year.example']).toMatchObject({
      fetchedAt: 123,
      data: {
        createdDate: correct.createdDate,
        renewalQuote: { renewal: 100, currency: 'USD' },
      },
    });
    expect(store.detail['other:two-year.example']).toBe(other);
  });
  it('keeps quote-only entries unread when inventory reports creation', async () => {
    storedCredentials.namecheap = { apiKey: 'fixture' };
    const correct = domain({
      domainName: 'two-year.example',
      registrar: 'namecheap',
      createdDate: new Date('2025-12-28'),
      expirationDate: new Date('2027-12-28'),
    });
    store.detail['namecheap:two-year.example'] = {
      data: { renewalQuote: { renewal: 100, currency: 'USD' } },
      fetchedAt: 123,
    };
    listPortfolio.mockResolvedValue({ domains: [correct], errors: [] });
    await syncRegistrar('namecheap');
    expect(getCachedDetail()).not.toHaveProperty('namecheap:two-year.example');
    expect(
      await getDomainDetail(
        'namecheap',
        'two-year.example',
        false,
        undefined,
        true,
      ),
    ).toBeNull();
    clientMethods.getDomain.mockResolvedValue({
      ...correct,
      nameservers: ['ns1.fixture.example'],
    });
    expect(
      await getDomainDetail('namecheap', 'two-year.example'),
    ).toMatchObject({ nameservers: ['ns1.fixture.example'] });
    expect(clientMethods.getDomain).toHaveBeenCalledWith('two-year.example');
  });
});
