import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { API_TIMEOUT_MS } from '../api-timeout';
import { MemoryDocStore } from '../storage/doc-store';
import {
  configureStore,
  flushWrites,
  hydrateStores,
} from '../storage/namespace';
import { EncryptedDocStore, aesGcmCipher } from '../storage/encrypted';
import { createAccount, listAccounts, renameAccount } from './accounts';
import { getStoredCredentials, setStoredCredentials } from './credentials';
import {
  getRegistrarCatalog,
  getRegistrarClient,
  getRegistrarMetadata,
  getPortfolio,
  getCachedPortfolio,
  getDomainDetail,
  getCachedDetail,
  getPortfolioPricing,
  removeRegistrarAccount,
  resetRegistrarClients,
  resolveDomainAccount,
  saveRegistrarCredentials,
  setRegistrarEnabledCached,
  syncRegistrar,
} from './registrars';
import { writeEntry, readEntry } from './cache';
import { configureConsentIp } from './consent-ip';
import { setRegistrarEnabled } from './registrar-state';
import { setManualPrice } from './pricing';
import { createFolder, assignFolder, getFolders } from './folders';
import { buildBundle, exportBundle, importBundle } from '../storage/bundle';
import { coreMethods, invoke } from '../api';
import { registerTools } from '../mcp/tools';
import {
  resetBulkMemory,
  setBulkAutoDrive,
  startBulk,
  stepBulk,
} from './bulk-jobs';
import { domainKey } from '../../shared/account-key';
import {
  Feature,
  createRegistrar,
  type Domain as ProviderDomain,
} from '@aoxborrow/registrar-client';
import type { DomainTarget, RegistrarAccount } from '../../shared/ipc';

const fakes = vi.hoisted(() => ({
  providers: new Map<string, Record<string, ReturnType<typeof vi.fn>>>(),
}));
vi.mock('@aoxborrow/registrar-client', async (original) => {
  const actual = await original<typeof import('@aoxborrow/registrar-client')>();
  return {
    ...actual,
    createRegistrar: vi.fn((_name: string, creds: { apiKey: string }) => {
      let provider = fakes.providers.get(creds.apiKey);
      if (!provider) {
        provider = Object.fromEntries(
          [
            'listDomains',
            'getDomain',
            'getNameservers',
            'testConnection',
            'setAutoRenew',
            'renewDomain',
            'updateNameservers',
            'setDnsRecords',
            'registerDomain',
            'transferIn',
            'getPricing',
            'getTransferOut',
            'getDomainForwarding',
            'resolveCustomerId',
            'setPrivacy',
          ].map((name) => [name, vi.fn()]),
        );
        provider.resolveCustomerId.mockResolvedValue('customer-uuid');
        provider.listDomains.mockResolvedValue([]);
        provider.getDomain.mockResolvedValue(null);
        provider.getNameservers.mockResolvedValue([]);
        provider.getDomainForwarding.mockResolvedValue([]);
        provider.testConnection.mockResolvedValue(
          process.env.DOMBOT_ACCOUNT_QA && creds.apiKey === 'invalid'
            ? {
                success: false,
                message:
                  'Invalid API key. Check your credentials and try again.',
              }
            : { success: true },
        );
        for (const name of [
          'setAutoRenew',
          'renewDomain',
          'updateNameservers',
          'setDnsRecords',
          'registerDomain',
          'transferIn',
          'setPrivacy',
        ])
          provider[name].mockResolvedValue({ success: true, message: 'ok' });
        fakes.providers.set(creds.apiKey, provider);
      }
      return provider;
    }),
    RegistrarClient: class {
      constructor(provider: object) {
        Object.assign(this, provider, { provider });
      }
    },
    listPortfolio: async (
      clients: { listDomains: () => Promise<ProviderDomain[]> }[],
    ) => ({ domains: await clients[0].listDomains(), errors: [] }),
  };
});
vi.mock('../dns', () => ({ resolveNameservers: vi.fn(async () => []) }));

let disk: MemoryDocStore;
const domain = (domainName: string): ProviderDomain => ({
  domainName,
  registrar: 'dynadot',
  status: 'active',
  autoRenew: false,
  locked: true,
  privacy: true,
  nameservers: [],
  createdDate: null,
  expirationDate: new Date('2027-01-01'),
  renewalDate: null,
  syncedAt: new Date(),
  deleted: false,
});
const APP = { version: 'test', platform: 'test' };
async function twoAccounts() {
  await saveRegistrarCredentials(
    'dynadot',
    { apiKey: 'personal', apiSecret: 'test-secret' },
    'dynadot',
  );
  const company = await createAccount('dynadot', 'Company');
  await saveRegistrarCredentials(
    'dynadot',
    { apiKey: 'company', apiSecret: 'test-secret' },
    company.id,
  );
  getRegistrarClient('dynadot', 'dynadot');
  getRegistrarClient('dynadot', company.id);
  fakes.providers
    .get('personal')!
    .listDomains.mockResolvedValue([domain('personal.com')]);
  fakes.providers
    .get('company')!
    .listDomains.mockResolvedValue([domain('company.com')]);
  await getPortfolio();
  return company;
}
const tools = new Map<
  string,
  {
    schema: z.ZodRawShape;
    handler: (args: unknown) => Promise<{ content: { text: string }[] }>;
  }
>();
registerTools({
  registerTool: (
    name: string,
    config: { inputSchema: z.ZodRawShape },
    handler: (args: unknown) => Promise<{ content: { text: string }[] }>,
  ) => tools.set(name, { schema: config.inputSchema, handler }),
} as unknown as McpServer);
async function mcp(name: string, args: unknown) {
  const tool = tools.get(name)!;
  return JSON.parse(
    (await tool.handler(z.object(tool.schema).parse(args))).content[0].text,
  );
}

/** Connects through the API and returns the new account. A turned-down
 *  connection test resolves with the registrar's answer; these tests expect
 *  an account, so it fails them. */
async function connectAccount(args: unknown[]): Promise<RegistrarAccount> {
  const result = await invoke(
    'connectRegistrarAccount',
    coreMethods.connectRegistrarAccount,
    args,
  );
  if (!result.success) throw new Error(result.message);
  return result.account;
}

beforeEach(async () => {
  await flushWrites();
  disk = new MemoryDocStore();
  configureStore(disk);
  await hydrateStores();
  resetRegistrarClients();
  resetBulkMemory();
  setBulkAutoDrive(false);
  fakes.providers.clear();
});

describe('multi-account storage, routing and portable migration', () => {
  it('adopts legacy IDs in place, preserving encrypted keys, disabled state, caches and annotations', async () => {
    await setStoredCredentials('dynadot', {
      apiKey: 'legacy',
      apiSecret: 'test-secret',
    });
    writeEntry('portfolio', 'dynadot', {
      domains: [domain('legacy.com')],
      lastSyncedAt: 123,
      lastError: null,
    });
    writeEntry('detail', 'dynadot:legacy.com', {
      nameservers: ['ns.legacy.com'],
    });
    setManualPrice('legacy.com', { amount: '17.00', currency: 'USD' });
    const folder = createFolder({
      name: 'Keep',
      color: 'green',
      description: '',
    });
    assignFolder('legacy.com', folder.id);
    await flushWrites();
    await hydrateStores();
    expect(getCachedPortfolio()!.domains[0]).toMatchObject({
      accountId: 'dynadot',
      accountLabel: 'Default',
    });
    expect(getPortfolioPricing()['dynadot:legacy.com'].renewal).toBe(17);
    expect(getFolders().assignments['legacy.com']).toBe(folder.id);
    setRegistrarEnabled('dynadot', false);
    await flushWrites();
    await hydrateStores();
    expect(
      getRegistrarMetadata().find((a) => a.accountId === 'dynadot'),
    ).toMatchObject({
      enabled: false,
      configured: true,
      sync: { lastSyncedAt: 123 },
    });
    expect(getCachedPortfolio()).toBeNull();
    expect(getStoredCredentials('dynadot')).toEqual({
      apiKey: 'legacy',
      apiSecret: 'test-secret',
    });
  });

  it('saves, tests, syncs and restores two independent clients after restart', async () => {
    const company = await twoAccounts();
    for (const id of ['dynadot', company.id])
      expect(
        await invoke('testRegistrarAccount', coreMethods.testRegistrarAccount, [
          'dynadot',
          id,
        ]),
      ).toMatchObject({ success: true });
    expect(getRegistrarClient('dynadot', company.id)).not.toBe(
      getRegistrarClient('dynadot', 'dynadot'),
    );
    await flushWrites();
    configureStore(disk);
    await hydrateStores();
    resetRegistrarClients();
    expect(getCachedPortfolio()!.domains.map((d) => d.accountId)).toEqual([
      'dynadot',
      company.id,
    ]);
    expect(getStoredCredentials(company.id)).toEqual({
      apiKey: 'company',
      apiSecret: 'test-secret',
    });
  });

  it('renames without changing credentials, client, cache, or domain identity', async () => {
    const company = await twoAccounts();
    const client = getRegistrarClient('dynadot', company.id);
    const prior = readEntry('portfolio', company.id);
    await renameAccount(company.id, 'Business');
    expect(getRegistrarClient('dynadot', company.id)).toBe(client);
    expect(readEntry('portfolio', company.id)).toEqual(prior);
    expect(getCachedPortfolio()!.domains[1]).toMatchObject({
      accountId: company.id,
      accountLabel: 'Business',
    });
  });

  it('failed sync keeps both last-good slices and scopes its error', async () => {
    const company = await twoAccounts();
    const prior = readEntry('portfolio', 'dynadot');
    fakes.providers
      .get('company')!
      .listDomains.mockRejectedValue(new Error('Provider offline'));
    const portfolio = await syncRegistrar('dynadot', company.id);
    expect(portfolio.domains).toHaveLength(2);
    expect(portfolio.errors).toEqual([
      {
        registrar: 'dynadot',
        accountId: company.id,
        accountLabel: 'Company',
        message: 'Provider offline',
      },
    ]);
    expect(readEntry('portfolio', 'dynadot')).toEqual(prior);
  });

  it('updating, disabling and removing one account preserves the sibling', async () => {
    const company = await twoAccounts();
    const prior = readEntry('portfolio', 'dynadot');
    await setRegistrarEnabledCached('dynadot', false, company.id);
    expect(getCachedPortfolio()!.domains).toHaveLength(1);
    expect(readEntry('portfolio', company.id)).not.toBeNull();
    await saveRegistrarCredentials(
      'dynadot',
      { apiKey: 'replacement', apiSecret: 'test-secret' },
      company.id,
    );
    await removeRegistrarAccount(company.id);
    await flushWrites();
    await hydrateStores();
    expect(getStoredCredentials(company.id)).toEqual({});
    expect(getStoredCredentials('dynadot')).toEqual({
      apiKey: 'personal',
      apiSecret: 'test-secret',
    });
    expect(readEntry('portfolio', 'dynadot')).toEqual(prior);
    expect(() => getRegistrarClient('dynadot', company.id)).toThrow(
      /Unknown account/,
    );
    await removeRegistrarAccount('dynadot');
    expect(listAccounts().some((a) => a.id === 'dynadot')).toBe(false);
    expect((await createAccount('dynadot', 'New')).id).not.toBe('dynadot');
  });

  it.each(['disable', 'remove', 'replace'] as const)(
    'in-flight sync cannot resurrect data after %s',
    async (action) => {
      const company = await twoAccounts();
      let finish!: (domains: ProviderDomain[]) => void;
      fakes.providers.get('company')!.listDomains.mockImplementation(
        () =>
          new Promise<ProviderDomain[]>((r) => {
            finish = r;
          }),
      );
      const syncing = syncRegistrar('dynadot', company.id);
      if (action === 'disable')
        await setRegistrarEnabledCached('dynadot', false, company.id);
      if (action === 'remove') await removeRegistrarAccount(company.id);
      if (action === 'replace')
        await saveRegistrarCredentials(
          'dynadot',
          { apiKey: 'new', apiSecret: 'test-secret' },
          company.id,
        );
      finish([domain('stale.com')]);
      await syncing;
      expect(getCachedPortfolio()!.domains.map((d) => d.domainName)).toEqual([
        'personal.com',
      ]);
    },
  );

  it('rejects unknown, wrong-provider, wrong-owner, disabled and ambiguous selections before mutations', async () => {
    const company = await twoAccounts();
    for (const target of [
      {
        registrar: 'dynadot',
        domainName: 'personal.com',
        accountId: company.id,
      },
      {
        registrar: 'porkbun',
        domainName: 'company.com',
        accountId: company.id,
      },
      { registrar: 'dynadot', domainName: 'company.com', accountId: 'missing' },
      { registrar: 'dynadot', domainName: 'uncached.com' },
    ]) {
      const result = await invoke('applyDomainOp', coreMethods.applyDomainOp, [
        target,
        { kind: 'renew', years: 1 },
      ]);
      expect(result.status).toBe('failed');
    }
    fakes.providers
      .get('personal')!
      .listDomains.mockResolvedValue([domain('shared.com')]);
    fakes.providers
      .get('company')!
      .listDomains.mockResolvedValue([domain('shared.com')]);
    await getPortfolio();
    expect(() => resolveDomainAccount('dynadot', 'shared.com')).toThrow(
      /Multiple accounts/,
    );
    await setRegistrarEnabledCached('dynadot', false, company.id);
    expect(() =>
      resolveDomainAccount('dynadot', 'shared.com', company.id),
    ).toThrow(/disabled/);
    for (const fake of fakes.providers.values())
      expect(fake.renewDomain).not.toHaveBeenCalled();
  });

  it('routes UI renewals, detail, manual prices, and persisted bulk work to the selected account', async () => {
    const company = await twoAccounts();
    fakes.providers.get('company')!.getDomain.mockResolvedValue({
      ...domain('company.com'),
      expirationDate: new Date('2028-01-01'),
    });
    const target: DomainTarget = {
      registrar: 'dynadot',
      domainName: 'company.com',
      accountId: company.id,
    };
    const renewed = await invoke('applyDomainOp', coreMethods.applyDomainOp, [
      target,
      { kind: 'renew', years: 2 },
    ]);
    expect(renewed).toMatchObject({ status: 'ok', target });
    expect(fakes.providers.get('company')!.renewDomain).toHaveBeenCalledWith(
      'company.com',
      2,
      expect.objectContaining({ signal: undefined }),
    );
    expect(fakes.providers.get('personal')!.renewDomain).not.toHaveBeenCalled();
    expect(
      await getDomainDetail('dynadot', 'company.com', false, company.id),
    ).toMatchObject({ expirationDate: new Date('2028-01-01') });
    expect(getCachedDetail()[domainKey(target)]).toBeDefined();
    await invoke('setManualPrice', coreMethods.setManualPrice, [
      'company.com',
      { amount: '19', currency: 'USD' },
    ]);
    expect(getPortfolioPricing()[domainKey(target)].renewal).toBe(19);
    const job = startBulk([target], {
      kind: 'nameservers',
      nameservers: ['ns.company.com'],
    });
    await flushWrites();
    resetBulkMemory();
    await hydrateStores();
    expect((await stepBulk(job.id)).job.results[0]).toMatchObject({
      target,
      status: 'ok',
    });
    expect(
      fakes.providers.get('company')!.updateNameservers,
    ).toHaveBeenCalledWith(
      'company.com',
      ['ns.company.com'],
      expect.anything(),
    );
    expect(
      fakes.providers.get('personal')!.updateNameservers,
    ).not.toHaveBeenCalled();
  });

  it('MCP infers unique owners, exposes accounts, filters, and refuses ambiguous registration/transfer/DNS', async () => {
    const company = await twoAccounts();
    expect((await mcp('registrar_list', {})).accounts).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ accountId: company.id, label: 'Company' }),
      ]),
    );
    expect(
      (await mcp('portfolio_query', { accountId: company.id })).rows,
    ).toMatchObject([{ domainName: 'company.com', accountId: company.id }]);
    await mcp('domain_dns_set', { domain: 'company.com', records: [] });
    expect(fakes.providers.get('company')!.setDnsRecords).toHaveBeenCalledTimes(
      1,
    );
    await expect(
      mcp('domain_dns_set', {
        registrar: 'dynadot',
        domain: 'company.com',
        accountId: 'dynadot',
        records: [],
      }),
    ).rejects.toThrow(/different account/);
    await expect(
      mcp('registrar_transfer_domain', {
        registrar: 'dynadot',
        domain: 'new.com',
        input: { authCode: 'test' },
      }),
    ).rejects.toThrow(/Multiple accounts/);
    const input = {
      contacts: {
        registrant: {
          firstName: 'Test',
          lastName: 'Test',
          email: 'test@example.com',
          phone: '+1.5551234567',
          address1: 'Test',
          city: 'Test',
          postalCode: '12345',
          country: 'US',
        },
      },
    };
    await expect(
      mcp('registrar_register_domain', {
        registrar: 'dynadot',
        domain: 'new.com',
        input,
      }),
    ).rejects.toThrow(/Multiple accounts/);
    await mcp('registrar_register_domain', {
      registrar: 'dynadot',
      accountId: company.id,
      domain: 'new.com',
      input,
    });
    expect(
      fakes.providers.get('company')!.registerDomain,
    ).toHaveBeenCalledOnce();
    expect(
      fakes.providers.get('personal')!.registerDomain,
    ).not.toHaveBeenCalled();
    await mcp('registrar_transfer_domain', {
      registrar: 'dynadot',
      accountId: company.id,
      domain: 'new.com',
      input: { authCode: 'test' },
    });
    expect(fakes.providers.get('company')!.transferIn).toHaveBeenCalledOnce();
  });

  it('retains unambiguous single-account MCP calls', async () => {
    await saveRegistrarCredentials('dynadot', {
      apiKey: 'personal',
      apiSecret: 'test-secret',
    });
    expect(await mcp('registrar_test', { registrar: 'dynadot' })).toMatchObject(
      { success: true },
    );
    expect(
      await mcp('domain_set_autorenew', {
        registrar: 'dynadot',
        domain: 'uncached.com',
        enabled: true,
      }),
    ).toMatchObject({ success: true, accountId: 'dynadot' });
  });

  it('round trips current desktop/web encrypted storage and imports legacy v1 without re-entering credentials', async () => {
    const company = await twoAccounts();
    const text = exportBundle({ ...APP, platform: 'darwin' });
    expect(JSON.parse(text).version).toBe(17);
    const raw = new MemoryDocStore();
    const key = crypto.getRandomValues(new Uint8Array(32));
    configureStore(new EncryptedDocStore(raw, await aesGcmCipher(key)));
    await hydrateStores();
    await importBundle(text);
    await flushWrites();
    expect(
      JSON.stringify(await raw.list('registrar-credentials')),
    ).not.toContain('personal');
    expect(await raw.get('registrar-credentials', company.id)).toMatchObject({
      __sealed: 1,
    });
    await hydrateStores();
    expect(getCachedPortfolio()!.domains).toHaveLength(2);
    const webBundle = exportBundle({ ...APP, platform: 'web' });
    configureStore(
      new EncryptedDocStore(
        new MemoryDocStore(),
        await aesGcmCipher(key),
        new Set(['registrar-credentials']),
      ),
    );
    await hydrateStores();
    await importBundle(webBundle);
    await flushWrites();
    await hydrateStores();
    expect(getStoredCredentials(company.id)).toEqual({
      apiKey: 'company',
      apiSecret: 'test-secret',
    });
    const legacy = buildBundle(APP);
    legacy.version = 1;
    delete legacy.namespaces['registrar-accounts'];
    delete legacy.namespaces['registrar-credentials'][company.id];
    delete legacy.namespaces['registrar-domains'][company.id];
    await importBundle(JSON.stringify(legacy));
    await flushWrites();
    expect(getCachedPortfolio()!.domains).toHaveLength(1);
    expect(
      getRegistrarMetadata().find((a) => a.accountId === 'dynadot'),
    ).toMatchObject({ configured: true, accountLabel: 'Default' });
  });

  it('keeps detail per account but shares a manual price by name', async () => {
    const company = await twoAccounts();
    for (const key of ['personal', 'company']) {
      fakes.providers
        .get(key)!
        .listDomains.mockResolvedValue([domain('shared.com')]);
      fakes.providers.get(key)!.getDomain.mockResolvedValue({
        ...domain('shared.com'),
        nameservers: [`ns.${key}.com`],
      });
    }
    await getPortfolio();
    await getDomainDetail('dynadot', 'shared.com', true, 'dynadot');
    await getDomainDetail('dynadot', 'shared.com', true, company.id);
    setManualPrice('shared.com', { amount: '20.00', currency: 'USD' });
    expect(getCachedDetail()['dynadot:shared.com'].nameservers).toEqual([
      'ns.personal.com',
    ]);
    expect(getCachedDetail()[`${company.id}:shared.com`].nameservers).toEqual([
      'ns.company.com',
    ]);
    // A manual price belongs to the name, so both accounts' copies show it.
    expect(getPortfolioPricing()['dynadot:shared.com'].renewal).toBe(20);
    expect(getPortfolioPricing()[`${company.id}:shared.com`].renewal).toBe(20);
  });

  it('rejects corrupt account routing metadata before import changes credentials', async () => {
    await twoAccounts();
    const bundle = buildBundle(APP);
    bundle.namespaces['registrar-accounts'].dynadot = {
      id: 'dynadot',
      registrar: 'porkbun',
      label: 'Wrong provider',
    };
    await expect(importBundle(JSON.stringify(bundle))).rejects.toThrow(
      /Invalid account metadata/,
    );
    expect(getStoredCredentials('dynadot').apiKey).toBe('personal');
  });

  it('a failed encryption write cannot leave new credentials usable in memory', async () => {
    const raw = new MemoryDocStore();
    configureStore(
      new EncryptedDocStore(
        raw,
        {
          alg: 'unavailable',
          seal: async () => {
            throw new Error('keyring unavailable');
          },
          open: async () => '',
        },
        new Set(['registrar-credentials']),
      ),
    );
    await hydrateStores();
    await expect(
      saveRegistrarCredentials('dynadot', {
        apiKey: 'unsaved',
        apiSecret: 'synthetic',
      }),
    ).rejects.toThrow(/keyring unavailable/);
    expect(getStoredCredentials('dynadot')).toEqual({});
    expect(await raw.get('registrar-credentials', 'dynadot')).toBeNull();
    await expect(flushWrites()).rejects.toThrow(/keyring unavailable/);
  });

  it('an older sync cannot overwrite a newer sync after credentials are resaved', async () => {
    const company = await twoAccounts();
    let finish!: (rows: ProviderDomain[]) => void;
    fakes.providers.get('company')!.listDomains.mockImplementationOnce(
      () =>
        new Promise<ProviderDomain[]>((r) => {
          finish = r;
        }),
    );
    const oldSync = syncRegistrar('dynadot', company.id);
    await saveRegistrarCredentials(
      'dynadot',
      { apiKey: 'company', apiSecret: 'test-secret' },
      company.id,
    );
    fakes.providers
      .get('company')!
      .listDomains.mockResolvedValue([domain('new.com')]);
    await syncRegistrar('dynadot', company.id);
    finish([domain('old.com')]);
    await oldSync;
    expect(getCachedPortfolio()!.domains.map((d) => d.domainName)).toEqual([
      'personal.com',
      'new.com',
    ]);
  });

  it('never reroutes an old queued job to a newly-added account after the default is removed', async () => {
    const company = await twoAccounts();
    const job = startBulk(
      [{ registrar: 'dynadot', domainName: 'personal.com' }],
      { kind: 'renew', years: 1 },
    );
    await flushWrites();
    const stored = (await disk.get('bulk-jobs', 'job')) as Record<
      string,
      unknown
    >;
    stored.pending = [{ registrar: 'dynadot', domainName: 'personal.com' }];
    await disk.put('bulk-jobs', 'job', stored);
    await removeRegistrarAccount('dynadot');
    fakes.providers
      .get('company')!
      .listDomains.mockResolvedValue([domain('personal.com')]);
    await syncRegistrar('dynadot', company.id);
    await flushWrites();
    resetBulkMemory();
    await hydrateStores();
    const completed = await stepBulk(job.id);
    expect(completed.job.results[0]).toMatchObject({
      status: 'failed',
      target: { accountId: 'dynadot' },
    });
    expect(fakes.providers.get('company')!.renewDomain).not.toHaveBeenCalled();
  });

  it('connects in one submission and numbers unnamed accounts', async () => {
    const first = await connectAccount([
      'dynadot',
      { apiKey: 'first', apiSecret: 'secret' },
    ]);
    const second = await connectAccount([
      'dynadot',
      { apiKey: 'second', apiSecret: 'secret' },
    ]);
    expect(first.label).toBe('Account 1');
    expect(second.label).toBe('Account 2');
    expect(getRegistrarMetadata().filter((a) => a.saved)).toHaveLength(2);
    expect(fakes.providers.get('first')!.testConnection).toHaveBeenCalledOnce();
    await flushWrites();
    await hydrateStores();
    expect(getStoredCredentials(second.id).apiKey).toBe('second');
    await expect(
      connectAccount(['dynadot', { apiKey: 'first', apiSecret: 'secret' }]),
    ).rejects.toThrow(/already connected/);
    expect(getRegistrarMetadata().filter((a) => a.saved)).toHaveLength(2);
  });

  it('numbers past the highest in use, never handing a live number to another account', async () => {
    const connect = (apiKey: string, label?: string) =>
      connectAccount(['dynadot', { apiKey, apiSecret: 'secret' }, label]);
    const one = await connect('k1');
    const two = await connect('k2');
    const three = await connect('k3');
    expect([one.label, two.label, three.label]).toEqual([
      'Account 1',
      'Account 2',
      'Account 3',
    ]);
    // Removing #1 does not renumber the others, and the next account is #4.
    await removeRegistrarAccount(one.id);
    expect((await connect('k4')).label).toBe('Account 4');
    const labels = () =>
      Object.fromEntries(
        getRegistrarMetadata()
          .filter((a) => a.saved)
          .map((a) => [a.accountId, a.accountLabel]),
      );
    expect(labels()[two.id]).toBe('Account 2');
    // A nicknamed account holds no number.
    const named = await connect('k5', 'Personal');
    expect(named.label).toBe('Personal');
    expect((await connect('k6')).label).toBe('Account 5');
  });

  it('removes a nickname when it is cleared, returning the account to the lowest free number', async () => {
    const connect = (apiKey: string) =>
      connectAccount(['dynadot', { apiKey, apiSecret: 'secret' }]);
    const one = await connect('k1');
    const two = await connect('k2');
    await invoke('renameRegistrarAccount', coreMethods.renameRegistrarAccount, [
      one.id,
      'Personal',
    ]);
    const labelOf = (id: string) =>
      getRegistrarMetadata().find((a) => a.accountId === id)!.accountLabel;
    expect(labelOf(one.id)).toBe('Personal');
    await invoke('renameRegistrarAccount', coreMethods.renameRegistrarAccount, [
      one.id,
      '  ',
    ]);
    expect(labelOf(one.id)).toBe('Account 1');
    expect(labelOf(two.id)).toBe('Account 2');
  });

  it('treats a nickname that would display like another account as taken', async () => {
    // An adopted legacy account is "Default", shown as #1.
    await saveRegistrarCredentials('dynadot', {
      apiKey: 'legacy',
      apiSecret: 'secret',
    });
    const second = await connectAccount([
      'dynadot',
      { apiKey: 'second', apiSecret: 'secret' },
    ]);
    expect(second.label).toBe('Account 2');
    for (const clash of ['Main', 'account 1', '#1'])
      await expect(renameAccount(second.id, clash)).rejects.toThrow(
        /already named "#1"/,
      );
    await renameAccount(second.id, 'Agency');
  });

  it('keeps nicknames unique per registrar, ignoring case, without a network test or a second account', async () => {
    const first = await connectAccount([
      'dynadot',
      { apiKey: 'first', apiSecret: 'secret' },
      'Personal',
    ]);
    await expect(
      connectAccount([
        'dynadot',
        { apiKey: 'second', apiSecret: 'secret' },
        ' personal ',
      ]),
    ).rejects.toThrow(/already named "Personal"/);
    // Rejected before the connection test, and nothing was saved.
    expect(fakes.providers.get('second')).toBeUndefined();
    expect(getRegistrarMetadata().filter((a) => a.saved)).toHaveLength(1);

    const second = await connectAccount([
      'dynadot',
      { apiKey: 'second', apiSecret: 'secret' },
      'Agency',
    ]);
    await expect(renameAccount(second.id, 'PERSONAL')).rejects.toThrow(
      /already named/,
    );
    // Re-saving its own name (any case) and reusing a name at another
    // registrar are both fine.
    await renameAccount(second.id, 'agency');
    await renameAccount(first.id, 'Personal');
    const elsewhere = await connectAccount([
      'porkbun',
      { apiKey: 'pb', secretApiKey: 'secret' },
      'Personal',
    ]);
    expect(elsewhere.label).toBe('Personal');
  });

  it('frees a nickname when its account is removed, and never collides with an unused placeholder', async () => {
    // No Dynadot account is saved, so the placeholder's "Default" is not taken.
    const first = await connectAccount([
      'dynadot',
      { apiKey: 'first', apiSecret: 'secret' },
      'Default',
    ]);
    await removeRegistrarAccount(first.id);
    const again = await connectAccount([
      'dynadot',
      { apiKey: 'again', apiSecret: 'secret' },
      'default',
    ]);
    expect(again.label).toBe('default');
  });

  it('a rejected connection never creates an empty account or saves its credentials', async () => {
    const { createRegistrar } = await import('@aoxborrow/registrar-client');
    createRegistrar('dynadot', { apiKey: 'bad', apiSecret: 'secret' });
    fakes.providers.get('bad')!.testConnection.mockResolvedValue({
      success: false,
      message: 'Invalid API key',
      status: 401,
    });
    // The registrar's answer comes back as a value, so its status crosses
    // IPC and HTTP too.
    await expect(
      invoke('connectRegistrarAccount', coreMethods.connectRegistrarAccount, [
        'dynadot',
        { apiKey: 'bad', apiSecret: 'secret' },
        'Company',
      ]),
    ).resolves.toEqual({
      success: false,
      message: 'Invalid API key',
      status: 401,
    });
    expect(getRegistrarMetadata().filter((a) => a.saved)).toEqual([]);
    expect(await disk.list('registrar-credentials')).toEqual({});
    expect(await disk.list('registrar-accounts')).toEqual({});
    fakes.providers
      .get('bad')!
      .testConnection.mockResolvedValue({ success: true });
    await connectAccount([
      'dynadot',
      { apiKey: 'bad', apiSecret: 'secret' },
      'Company',
    ]);
    expect(getRegistrarMetadata().filter((a) => a.saved)).toHaveLength(1);
  });

  it('keeps the provider catalog after every saved/default account is removed', async () => {
    await removeRegistrarAccount('dynadot');
    const catalog = await invoke(
      'getRegistrarCatalog',
      coreMethods.getRegistrarCatalog,
      [],
    );
    expect(
      catalog
        .find((p) => p.name === 'dynadot')!
        .configFields.map((f) => f.name),
    ).toContain('apiKey');
    const account = await connectAccount([
      'dynadot',
      { apiKey: 'new', apiSecret: 'secret' },
    ]);
    expect(account.id).not.toBe('dynadot');
  });

  it('connection form validation and storage failure leave no incomplete accounts', async () => {
    await expect(
      connectAccount(['dynadot', { apiKey: 'incomplete' }]),
    ).rejects.toThrow(/API Secret is required/);
    expect(fakes.providers.size).toBe(0);
    configureStore(
      new EncryptedDocStore(
        new MemoryDocStore(),
        {
          alg: 'unavailable',
          seal: async () => {
            throw new Error('keyring unavailable');
          },
          open: async () => '',
        },
        new Set(['registrar-credentials']),
      ),
    );
    await hydrateStores();
    await expect(
      connectAccount(['dynadot', { apiKey: 'unsaved', apiSecret: 'secret' }]),
    ).rejects.toThrow(/keyring unavailable/);
    expect(getRegistrarMetadata().filter((a) => a.saved)).toEqual([]);
    await expect(flushWrites()).rejects.toThrow(/keyring unavailable/);
  });

  it('rolls back a new account when publishing its metadata fails', async () => {
    const put = disk.put.bind(disk);
    vi.spyOn(disk, 'put').mockImplementation(async (namespace, key, value) => {
      if (namespace === 'registrar-accounts')
        throw new Error('metadata write failed');
      return put(namespace, key, value);
    });
    await expect(
      connectAccount(['dynadot', { apiKey: 'first', apiSecret: 'secret' }]),
    ).rejects.toThrow(/metadata write failed/);
    expect(getRegistrarMetadata().filter((a) => a.saved)).toEqual([]);
    expect(await disk.list('registrar-credentials')).toEqual({});
    await expect(flushWrites()).rejects.toThrow(/metadata write failed/);
  });

  it('keeps the last persisted credentials when overlapping saves both fail', async () => {
    const original = { apiKey: 'persisted', apiSecret: 'test-secret' };
    await setStoredCredentials('dynadot', original);
    vi.spyOn(disk, 'put').mockRejectedValue(
      new Error('persistence unavailable'),
    );
    const results = await Promise.allSettled([
      setStoredCredentials('dynadot', {
        apiKey: 'unsaved-first',
        apiSecret: 'test-secret',
      }),
      setStoredCredentials('dynadot', {
        apiKey: 'unsaved-second',
        apiSecret: 'test-secret',
      }),
    ]);
    await expect(flushWrites()).rejects.toThrow(/persistence unavailable/);
    expect(results.every((r) => r.status === 'rejected')).toBe(true);
    expect(getStoredCredentials('dynadot')).toEqual(original);
    expect(await disk.get('registrar-credentials', 'dynadot')).toEqual(
      original,
    );
  });

  it('publishes only one account when identical connection requests overlap', async () => {
    const args = [
      'dynadot',
      { apiKey: 'same-account', apiSecret: 'test-secret' },
    ];
    const results = await Promise.allSettled([
      invoke(
        'connectRegistrarAccount',
        coreMethods.connectRegistrarAccount,
        args,
      ),
      invoke(
        'connectRegistrarAccount',
        coreMethods.connectRegistrarAccount,
        args,
      ),
    ]);
    await flushWrites();
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((r) => r.status === 'rejected')).toHaveLength(1);
    expect(getRegistrarMetadata().filter((a) => a.saved)).toHaveLength(1);
    expect(Object.keys(await disk.list('registrar-credentials'))).toHaveLength(
      1,
    );
  });

  it('rebuilds cached clients when another host changes persisted credentials', async () => {
    await saveRegistrarCredentials('dynadot', {
      apiKey: 'old',
      apiSecret: 'test-secret',
    });
    const old = getRegistrarClient('dynadot');
    await disk.put('registrar-credentials', 'dynadot', {
      apiKey: 'new',
      apiSecret: 'test-secret',
    });
    await hydrateStores();
    expect(getRegistrarClient('dynadot')).not.toBe(old);
  });
});

describe('GoDaddy Optional settings', () => {
  const OPTIONAL = {
    customerId: '123456789',
    apiKey: 'gd-key',
    apiSecret: 'gd-secret',
  };
  const connect = (credentials: Record<string, string>, label?: string) =>
    connectAccount(['godaddy', credentials, label]);
  const featuresOf = (id: string) =>
    getRegistrarMetadata().find((a) => a.accountId === id)!.features;
  const transferOut = (target: DomainTarget) =>
    invoke('getTransferOut', coreMethods.getTransferOut, [target]);

  it('follows the PAT in the form, in the Optional section', () => {
    const godaddy = getRegistrarCatalog().find((r) => r.name === 'godaddy')!;
    expect(
      godaddy.configFields.map((f) => [f.name, f.required, f.section]),
    ).toEqual([
      ['apiToken', true, undefined],
      ['customerId', false, 'optional'],
      ['apiKey', false, 'optional'],
      ['apiSecret', false, 'optional'],
    ]);
  });

  it('offers URL forwarding and transfers out only on an account with all three', async () => {
    const plain = await connect({ apiToken: 'pat' }, 'Plain');
    const full = await connect({ apiToken: 'pat-2', ...OPTIONAL }, 'Full');
    const unlocked = [
      Feature.GetDomainForwarding,
      Feature.SetDomainForwarding,
      Feature.GetTransferOut,
      Feature.ApproveTransferOut,
      Feature.RejectTransferOut,
    ];
    expect(featuresOf(plain.id)).toContain(Feature.GetAuthCode);
    for (const feature of unlocked)
      expect(featuresOf(plain.id)).not.toContain(feature);
    expect(featuresOf(full.id)).toEqual(expect.arrayContaining(unlocked));
    const sold = (accountId: string): DomainTarget => ({
      registrar: 'godaddy',
      domainName: 'sold.com',
      accountId,
    });
    await expect(transferOut(sold(plain.id))).rejects.toThrow(
      'Add this account’s Optional settings in Settings › Registrars to use transfer-out reports.',
    );
    await expect(transferOut(sold(full.id))).resolves.toBeNull();
    expect(fakes.providers.get('gd-key')!.getTransferOut).toHaveBeenCalledWith(
      'sold.com',
      {},
    );
    // URL forwarding: the app's read, the MCP read and the write.
    const forwarding = (target: DomainTarget) =>
      invoke('getUrlForwarding', coreMethods.getUrlForwarding, [target]);
    await expect(forwarding(sold(plain.id))).rejects.toThrow(
      /Optional settings .* to use URL forwarding/,
    );
    await expect(forwarding(sold(full.id))).resolves.toEqual([]);
    await expect(
      mcp('domain_url_forwarding_get', {
        domain: 'sold.com',
        registrar: 'godaddy',
        accountId: plain.id,
      }),
    ).rejects.toThrow(/Optional settings/);
    await expect(
      mcp('domain_url_forwarding_get', {
        domain: 'sold.com',
        registrar: 'godaddy',
        accountId: full.id,
      }),
    ).resolves.toEqual([]);
    expect(
      await invoke('applyDomainOp', coreMethods.applyDomainOp, [
        sold(plain.id),
        { kind: 'urlForwarding', forwards: [] },
      ]),
    ).toMatchObject({
      status: 'unsupported',
      message: expect.stringMatching(/Optional settings/),
    });
  });

  it('resolves the account for a target that names none', async () => {
    await connect({ apiToken: 'pat', ...OPTIONAL });
    await expect(
      transferOut({ registrar: 'godaddy', domainName: 'sold.com' }),
    ).resolves.toBeNull();
  });

  it('passes them to the library alongside the PAT', async () => {
    const account = await connect({ apiToken: 'pat', ...OPTIONAL });
    expect(getStoredCredentials(account.id)).toEqual({
      apiToken: 'pat',
      ...OPTIONAL,
    });
    vi.mocked(createRegistrar).mockClear();
    getRegistrarClient('godaddy', account.id);
    expect(createRegistrar).toHaveBeenCalledWith(
      'godaddy',
      { apiToken: 'pat', ...OPTIONAL },
      { timeout: API_TIMEOUT_MS },
    );
    // Clearing them takes transfers out away again.
    await saveRegistrarCredentials('godaddy', { apiToken: 'pat' }, account.id);
    expect(featuresOf(account.id)).not.toContain(Feature.GetTransferOut);
  });

  it('requires all three once any is filled in, before a network call or save', async () => {
    await expect(
      connect({ apiToken: 'pat', customerId: '123456789' }),
    ).rejects.toThrow(
      'API Key (Legacy) is required when any Optional setting is filled in.',
    );
    expect(fakes.providers.size).toBe(0);
    const account = await connect({ apiToken: 'pat' });
    await expect(
      saveRegistrarCredentials(
        'godaddy',
        { apiToken: 'pat', apiKey: 'gd-key', apiSecret: 'gd-secret' },
        account.id,
      ),
    ).rejects.toThrow(/Customer Number is required/);
    expect(getStoredCredentials(account.id)).toEqual({ apiToken: 'pat' });
  });

  it('tries new or changed Optional settings before keeping them', async () => {
    const failure =
      'GoDaddy couldn’t look up the Customer Number with this API Key and API Secret. Check the Optional settings.';
    createRegistrar('godaddy', OPTIONAL);
    const lookup = fakes.providers.get('gd-key')!.resolveCustomerId;
    // Connecting: a failed lookup keeps the account out.
    lookup.mockRejectedValueOnce(new Error('401 Unauthorized'));
    await expect(connect({ apiToken: 'pat', ...OPTIONAL })).rejects.toThrow(
      failure,
    );
    const account = await connect({ apiToken: 'pat', ...OPTIONAL });
    expect(lookup).toHaveBeenCalledTimes(2);
    // Saving: a failed lookup keeps what was stored.
    lookup.mockClear().mockRejectedValueOnce(new Error('401 Unauthorized'));
    const changed = { apiToken: 'pat', ...OPTIONAL, apiSecret: 'new-secret' };
    await expect(
      saveRegistrarCredentials('godaddy', changed, account.id),
    ).rejects.toThrow(failure);
    expect(getStoredCredentials(account.id)).toEqual({
      apiToken: 'pat',
      ...OPTIONAL,
    });
    await saveRegistrarCredentials('godaddy', changed, account.id);
    expect(getStoredCredentials(account.id)).toEqual(changed);
    expect(lookup).toHaveBeenCalledTimes(2);
    // The lookup tries the values as they'll be stored: trimmed.
    lookup.mockClear();
    vi.mocked(createRegistrar).mockClear();
    const trimmed = {
      apiToken: 'pat',
      ...OPTIONAL,
      apiSecret: 'padded-secret',
    };
    await saveRegistrarCredentials(
      'godaddy',
      { ...trimmed, apiSecret: ' padded-secret ' },
      account.id,
    );
    expect(createRegistrar).toHaveBeenCalledWith('godaddy', trimmed, {
      timeout: API_TIMEOUT_MS,
    });

    expect(getStoredCredentials(account.id)).toEqual(trimmed);
    expect(lookup).toHaveBeenCalledTimes(1);
    // A new PAT alone, or clearing them, tries nothing.
    lookup.mockClear();
    await saveRegistrarCredentials(
      'godaddy',
      { ...trimmed, apiToken: 'pat-2' },
      account.id,
    );
    await saveRegistrarCredentials(
      'godaddy',
      { apiToken: 'pat-2' },
      account.id,
    );
    expect(lookup).not.toHaveBeenCalled();
  });

  it('reports why a target with no single account fails, not the Optional settings', async () => {
    await connect({ apiToken: 'pat' }, 'Plain');
    await connect({ apiToken: 'pat-2', ...OPTIONAL }, 'Full');
    const target: DomainTarget = {
      registrar: 'godaddy',
      domainName: 'sold.com',
    };
    await expect(transferOut(target)).rejects.toThrow(
      /Multiple accounts match/,
    );
    expect(
      await invoke('applyDomainOp', coreMethods.applyDomainOp, [
        target,
        { kind: 'approveTransfer' },
      ]),
    ).toMatchObject({
      message: expect.stringMatching(/Multiple accounts match/),
    });
  });

  it('turns privacy off with the user’s IP address as consent', async () => {
    const account = await connect({ apiToken: 'pat', ...OPTIONAL });
    const setPrivacy = fakes.providers.get('gd-key')!.setPrivacy;
    const op = (
      registrar: 'godaddy' | 'dynadot',
      accountId: string,
      enabled: boolean,
    ) =>
      invoke('applyDomainOp', coreMethods.applyDomainOp, [
        { registrar, domainName: 'sold.com', accountId },
        { kind: 'privacy', enabled },
      ]);
    // With no way to find the IP, GoDaddy is never asked.
    expect(await op('godaddy', account.id, false)).toMatchObject({
      status: 'failed',
      message: expect.stringMatching(
        /public IP address, which GoDaddy records/,
      ),
    });
    expect(setPrivacy).not.toHaveBeenCalled();
    const lookup = vi.fn(async () => '203.0.113.7');
    configureConsentIp(lookup);
    try {
      expect(await op('godaddy', account.id, false)).toMatchObject({
        status: 'ok',
      });
      expect(setPrivacy).toHaveBeenLastCalledWith(
        'sold.com',
        false,
        expect.objectContaining({ consent: { agreedBy: '203.0.113.7' } }),
      );
      // Turning it on, or off at a registrar that records nothing, sends no IP.
      expect(await op('godaddy', account.id, true)).toMatchObject({
        status: 'ok',
      });
      expect(setPrivacy.mock.lastCall![2]).not.toHaveProperty('consent');
      const dynadot = await connectAccount([
        'dynadot',
        { apiKey: 'dy-key', apiSecret: 'dy-secret' },
      ]);
      expect(await op('dynadot', dynadot.id, false)).toMatchObject({
        status: 'ok',
      });
      expect(
        fakes.providers.get('dy-key')!.setPrivacy.mock.lastCall![2],
      ).not.toHaveProperty('consent');
      expect(lookup).toHaveBeenCalledTimes(1);
    } finally {
      configureConsentIp();
    }
  });

  it('treats the same PAT with Optional settings as the account already connected', async () => {
    await connect({ apiToken: 'pat' });
    await expect(connect({ apiToken: 'pat', ...OPTIONAL })).rejects.toThrow(
      /already connected/,
    );
  });
});

// Manual renderer QA against the real shared API and synthetic providers only.
// npm run web:build && DOMBOT_ACCOUNT_QA=1 npx vitest run src/core/services/accounts.test.ts -t 'browser QA server'
it.skipIf(!process.env.DOMBOT_ACCOUNT_QA)(
  'browser QA server',
  async () => {
    const { createServer } = await import('node:http');
    const { readFile } = await import('node:fs/promises');
    const { resolve, extname } = await import('node:path');
    const root = resolve('dist/web');
    const server = createServer(async (req, res) => {
      try {
        if (req.url === '/auth/status') {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ mode: 'external', authenticated: true }));
          return;
        }
        if (req.url?.startsWith('/api/')) {
          const method = req.url.slice(5) as keyof typeof coreMethods;
          const parts: Buffer[] = [];
          for await (const part of req) parts.push(part);
          const { args = [] } = JSON.parse(Buffer.concat(parts).toString());
          let result: unknown;
          if (method in coreMethods) {
            if (method === 'syncRegistrar' || method === 'listPortfolio') {
              for (const a of listAccounts()) {
                const creds = getStoredCredentials(a.id);
                if (creds.apiKey) {
                  getRegistrarClient(a.registrar, a.id);
                  fakes.providers
                    .get(creds.apiKey)!
                    .listDomains.mockResolvedValue([
                      domain(`${creds.apiKey}.example.com`),
                    ]);
                }
              }
            }
            result = await invoke(method, coreMethods[method], args);
            await flushWrites();
          } else if (req.url === '/api/getAppInfo')
            result = { name: 'Dombot QA', version: 'test', platform: 'web' };
          else if (req.url === '/api/getMcpInfo')
            result = {
              running: false,
              url: '',
              stdioCommand: '',
              stdioArgs: [],
            };
          else throw new Error(`Unknown method ${method}`);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result }));
          return;
        }
        const path = resolve(
          root,
          '.' + (req.url === '/' ? '/index.html' : req.url!.split('?')[0]),
        );
        if (!path.startsWith(root + '/')) throw new Error('Invalid path');
        const contents = await readFile(path);
        res.setHeader(
          'Content-Type',
          (
            {
              '.html': 'text/html',
              '.js': 'text/javascript',
              '.css': 'text/css',
              '.svg': 'image/svg+xml',
            } as Record<string, string>
          )[extname(path)] ?? 'application/octet-stream',
        );
        res.end(contents);
      } catch (err) {
        res.statusCode = 400;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: String(err) }));
      }
    });
    await new Promise<void>((r) => server.listen(4173, '127.0.0.1', r));
    console.log('Synthetic account QA: http://127.0.0.1:4173');
    try {
      await new Promise((r) => setTimeout(r, 600_000));
    } finally {
      server.close();
    }
  },
  610_000,
);
