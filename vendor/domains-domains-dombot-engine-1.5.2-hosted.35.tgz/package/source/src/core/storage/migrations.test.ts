import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryDocStore } from './doc-store';
import { EncryptedDocStore, aesGcmCipher, type Cipher } from './encrypted';
import { SCHEMA_VERSION, runMigrations } from './migrations';

let raw: MemoryDocStore;
let cipher: Cipher;
beforeEach(async () => {
  raw = new MemoryDocStore();
  cipher = await aesGcmCipher(new Uint8Array(32).fill(7));
  vi.spyOn(console, 'warn').mockImplementation(() => {});
});
afterEach(() => vi.restoreAllMocks());

/** Every stored namespace with entries (listing one creates it empty). */
async function contents(): Promise<Record<string, Record<string, unknown>>> {
  const all = await raw.loadAll();
  return Object.fromEntries(
    Object.entries(all).filter(([, e]) => Object.keys(e).length > 0),
  );
}

/** The desktop layout: only credentials and proxies are sealed. */
const sealing = (names: string[], c: Cipher = cipher) =>
  new EncryptedDocStore(raw, c, new Set(names));

/** A pre-v1 desktop store, written with the old names. */
async function seedLegacy(): Promise<void> {
  const old = sealing(['credentials', 'proxies']);
  await old.put('credentials', 'dynadot', { apiKey: 'k' });
  await old.put('proxies', 'default', { id: 'default', url: 'http://p' });
  await old.put('cache-portfolio', 'dynadot', { fetchedAt: 1, data: {} });
  await old.put('cache-detail', 'dynadot:a.com', { fetchedAt: 1, data: {} });
  await old.put('tld-rates', 'godaddy:com', 8.99);
  await old.put('registrar-state', 'disabled', ['gandi']);
  await old.put('pricing-overrides', 'dynadot:Münich.de', 40);
  await old.put('pricing-overrides', 'acct-2:xn--mnich-kva.de', 99);
  await old.put('folders', 'folders', [{ id: 'f1', name: 'Keep' }]);
  await old.put('folders', 'assignments', {
    'dynadot:a.com': 'f1',
    'acct-2:B.com': '__hidden__',
  });
  await old.put('settings', 'mcpEnabled', true);
}

describe('runMigrations', () => {
  it('stamps a fresh store and moves nothing', async () => {
    const store = sealing(['registrar-credentials']);
    await runMigrations(raw, store);
    expect(await store.get('meta', 'schemaVersion')).toBe(SCHEMA_VERSION);
    expect(await contents()).toEqual({
      meta: { schemaVersion: SCHEMA_VERSION },
    });
  });

  it('renames namespaces, re-keys folders and prices by name, and keeps secrets sealed', async () => {
    await seedLegacy();
    const store = sealing(['registrar-credentials', 'registrar-proxies']);
    await runMigrations(raw, store);

    // Sealed values moved as ciphertext and still open under the new name.
    expect(await raw.get('registrar-credentials', 'dynadot')).toMatchObject({
      __sealed: 1,
    });
    expect(await store.get('registrar-credentials', 'dynadot')).toEqual({
      apiKey: 'k',
    });
    expect(await store.get('registrar-proxies', 'default')).toMatchObject({
      url: 'http://p',
    });
    expect(Object.keys(await store.list('registrar-domains'))).toEqual([
      'dynadot',
    ]);
    expect(Object.keys(await store.list('registrar-details'))).toEqual([
      'dynadot:a.com',
    ]);
    expect(await store.list('registrar-tld-rates')).toEqual({
      'godaddy:com': 8.99,
    });
    expect(await store.get('registrars', 'disabled')).toEqual(['gandi']);
    // First account wins a name both accounts priced.
    expect(await store.list('domain-prices')).toEqual({
      'xn--mnich-kva.de': { amount: '40.00', currency: 'USD' },
    });
    expect(await store.list('folders')).toEqual({
      folders: [{ id: 'f1', name: 'Keep' }],
    });
    // The built-in Hidden folder is gone (v5): its names have no folder.
    expect(await store.list('domain-folders')).toEqual({ 'a.com': 'f1' });
    // Untouched namespaces stay put; old ones are gone.
    expect(await store.get('settings', 'mcpEnabled')).toBe(true);
    for (const old of [
      'credentials',
      'proxies',
      'cache-portfolio',
      'cache-detail',
      'tld-rates',
      'registrar-state',
      'pricing-overrides',
    ]) {
      expect(await raw.list(old)).toEqual({});
    }
    expect(await store.get('meta', 'schemaVersion')).toBe(5);

    // A second run is a no-op.
    const before = await contents();
    await runMigrations(raw, store);
    expect(await contents()).toEqual(before);
  });

  it('moves credentials it cannot decrypt (a locked keyring) instead of dropping them', async () => {
    await seedLegacy();
    const locked: Cipher = {
      alg: cipher.alg,
      seal: cipher.seal,
      open: () => Promise.reject(new Error('keyring locked')),
    };
    await runMigrations(
      raw,
      sealing(['registrar-credentials', 'registrar-proxies'], locked),
    );
    // Once the keyring is back, the key opens under its new name.
    expect(
      await sealing(['registrar-credentials']).get(
        'registrar-credentials',
        'dynadot',
      ),
    ).toEqual({ apiKey: 'k' });
  });

  it('stops without changes when the folder map is stored but unreadable', async () => {
    // The web layout seals every namespace; this one under a different key.
    const other = await aesGcmCipher(new Uint8Array(32).fill(9));
    await new EncryptedDocStore(raw, other).put('folders', 'assignments', {
      'dynadot:a.com': 'f1',
    });
    await raw.put('cache-portfolio', 'dynadot', { fetchedAt: 1 });
    const before = await contents();
    await expect(
      runMigrations(raw, new EncryptedDocStore(raw, cipher)),
    ).rejects.toThrow(/can't read folder assignments/);
    expect(await contents()).toEqual(before);
  });

  it('v3 gives stored renewal prices a currency', async () => {
    const store = sealing(['registrar-credentials']);
    await store.put('meta', 'schemaVersion', 2);
    await store.putMany('domain-prices', [
      ['a.com', 12.5],
      ['b.com', { amount: '9.00', currency: 'EUR' }],
      ['c.com', -3],
    ]);
    await runMigrations(raw, store);
    expect(await store.list('domain-prices')).toEqual({
      'a.com': { amount: '12.50', currency: 'USD' },
      'b.com': { amount: '9.00', currency: 'EUR' },
    });
    expect(await store.get('meta', 'schemaVersion')).toBe(5);
  });

  it('v5 drops the built-in folders on a v1 store', async () => {
    const store = sealing(['registrar-credentials']);
    await store.put('meta', 'schemaVersion', 1);
    await store.putMany('domain-folders', [
      ['a.com', '__archive__'],
      ['b.com', 'f1'],
      ['c.com', '__hidden__'],
    ]);
    await runMigrations(raw, store);
    expect(await store.list('domain-folders')).toEqual({ 'b.com': 'f1' });
    expect(await store.get('meta', 'schemaVersion')).toBe(5);
  });

  it('v5 deletes dropped and archived events and keeps the rest', async () => {
    const store = sealing(['registrar-credentials']);
    await store.put('meta', 'schemaVersion', 4);
    const ev = (id: string, type: string) => ({
      id,
      domain: 'a.com',
      type,
      source: 'user',
      date: '2026-09-01',
      createdAt: 1,
      updatedAt: null,
    });
    await store.putMany('domain-events', [
      ['E1', ev('E1', 'removed')],
      ['E2', ev('E2', 'dropped')],
      ['E3', ev('E3', 'archived')],
      ['E4', ev('E4', 'sold')],
    ]);
    await runMigrations(raw, store);
    expect(Object.keys(await store.list('domain-events'))).toEqual([
      'E1',
      'E4',
    ]);
    expect(await store.get('meta', 'schemaVersion')).toBe(5);
  });

  it('v4 moves manual-domains to imported-domains', async () => {
    const store = sealing(['registrar-credentials']);
    await store.put('meta', 'schemaVersion', 3);
    const entry = { registrar: 'epik', addedAt: 1, updatedAt: null };
    await store.put('manual-domains', 'a.com', entry);
    await runMigrations(raw, store);
    expect(await store.list('imported-domains')).toEqual({ 'a.com': entry });
    expect(await raw.list('manual-domains')).toEqual({});
    expect(await store.get('meta', 'schemaVersion')).toBe(5);
  });
});

it('retains removed ownership history and folder intent in exportable namespaces', async () => {
  const store = new MemoryDocStore();
  await store.put('meta', 'schemaVersion', 4);
  const event = {
    id: 'old-drop',
    domain: 'kept.example',
    type: 'dropped',
    date: '2026-01-01',
    source: 'user',
  };
  await store.put('domain-events', 'old-drop', event);
  await store.put('domain-folders', 'kept.example', '__hidden__');
  await runMigrations(store, store);
  expect(await store.get('domain-events', 'old-drop')).toBeNull();
  expect(await store.get('hosted-legacy-events', 'old-drop')).toEqual(event);
  expect(await store.get('domain-folders', 'kept.example')).toBeNull();
  expect(await store.get('hosted-legacy-folders', 'kept.example')).toBe(
    '__hidden__',
  );
  await runMigrations(store, store);
  expect(await store.get('hosted-legacy-events', 'old-drop')).toEqual(event);
});
