import { isDomainKey, toAscii } from '../../shared/domain-name';
import type { DocStore } from './doc-store';
import './legacy-records';
import { RENEWAL_PRICES_NAMESPACE } from './names';
import { toRenewalPrice, type RenewalPrice } from '../../shared/renewal-prices';

// Storage schema migrations (docs/storage-model.md). Each host calls
// `runMigrations` once, before `hydrateStores()`; a data bundle from an older
// DomBot goes through `upgradeLegacyNamespaces` instead, so both paths share
// one table of renames and one set of re-keying rules.

/** The storage schema this build writes. Stored at `meta/schemaVersion`. */
export const SCHEMA_VERSION = 5;

/** v0 → v1: old namespace name → new. */
export const RENAMED_NAMESPACES: Readonly<Record<string, string>> = {
  'cache-portfolio': 'registrar-domains',
  'cache-detail': 'registrar-details',
  'tld-rates': 'registrar-tld-rates',
  credentials: 'registrar-credentials',
  proxies: 'registrar-proxies',
  'registrar-state': 'registrars',
  'pricing-overrides': 'domain-prices',
};

/** v3 → v4: the names you add yourself became imported domains. Never in a
 *  release; only stores and bundles built from main between the two. */
export const LEGACY_IMPORTED_NAMESPACE = 'manual-domains';
const IMPORTED_NAMESPACE = 'imported-domains';

/** Renamed namespaces whose keys also change, from account-scoped to name. */
const REKEYED_BY_NAME = new Set(['pricing-overrides']);

// Folder assignments lived in `folders` under this key until v1.
const LEGACY_ASSIGNMENTS_KEY = 'assignments';
// The built-in "hide this name" folder was Archive (`__archive__`) between
// the Hidden → Archive rename and v2, when it became Hidden (`__hidden__`)
// again. v5 removed it: its names went back to no folder.
const LEGACY_ARCHIVE_FOLDER_ID = '__archive__';
export const LEGACY_HIDDEN_FOLDER_ID = '__hidden__';

/** v5: event types that no longer exist (docs/owned-and-archive.md). */
export const LEGACY_EVENT_TYPES: ReadonlySet<string> = new Set([
  'dropped',
  'archived',
]);
const EVENTS_NAMESPACE = 'domain-events';
const FOLDER_ASSIGNMENTS_NAMESPACE = 'domain-folders';

/** `${accountId ?? registrar}:${domain}` → `toAscii(domain)`, or null when the
 *  key doesn't end in a domain name. */
export function nameKeyOf(legacyKey: string): string | null {
  const key = toAscii(legacyKey.slice(legacyKey.lastIndexOf(':') + 1));
  return isDomainKey(key) ? key : null;
}

/**
 * Re-keys account-scoped entries by domain name. A name held by two accounts
 * keeps the first entry found; the rest are logged and dropped.
 */
export function rekeyByName<T>(
  entries: Record<string, T>,
  label: string,
): Record<string, T> {
  const out: Record<string, T> = {};
  for (const [legacyKey, value] of Object.entries(entries)) {
    const key = nameKeyOf(legacyKey);
    if (!key) {
      console.warn(`[storage] ${label}: dropping ${legacyKey} (not a domain)`);
    } else if (Object.hasOwn(out, key)) {
      console.warn(
        `[storage] ${label}: ${legacyKey} conflicts with another account's entry for ${key}; keeping the first`,
      );
    } else {
      out[key] = value;
    }
  }
  return out;
}

/** The built-in Archive (v1) and Hidden (v2–v4) folders, gone since v5. */
export function isLegacyBuiltInFolder(folderId: unknown): boolean {
  return (
    folderId === LEGACY_ARCHIVE_FOLDER_ID ||
    folderId === LEGACY_HIDDEN_FOLDER_ID
  );
}

/** The pre-v1 `folders/assignments` map, keyed by name, without the
 *  built-in folders. */
export function assignmentsByName(raw: unknown): Record<string, string> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const ids: Record<string, string> = {};
  for (const [key, folderId] of Object.entries(raw)) {
    if (typeof folderId !== 'string' || isLegacyBuiltInFolder(folderId))
      continue;
    ids[key] = folderId;
  }
  return rekeyByName(ids, 'folder assignments');
}

/** Preserve removed folder intent as encrypted, exportable history. */
export function legacyBuiltInAssignments(raw: unknown): Record<string, string> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  return rekeyByName(
    Object.fromEntries(
      Object.entries(raw).filter(([, id]) => isLegacyBuiltInFolder(id)),
    ) as Record<string, string>,
    'legacy folders',
  );
}

/** v5 for a bundle's `domain-folders`: the built-in folders' names go back
 *  to no folder. */
export function withoutBuiltInFolders(
  entries: Record<string, unknown>,
): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(entries).filter(([, id]) => !isLegacyBuiltInFolder(id)),
  );
}

/** v5 for a bundle's `domain-events`: `dropped` and `archived` go. */
export function withoutLegacyEvents(
  entries: Record<string, unknown>,
): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(entries).filter(
      ([, e]) =>
        !(
          e &&
          typeof e === 'object' &&
          LEGACY_EVENT_TYPES.has((e as { type?: unknown }).type as string)
        ),
    ),
  );
}

/** A v1–v3 bundle's namespaces under the current names and keys. */
export function upgradeLegacyNamespaces(
  namespaces: Record<string, Record<string, unknown>>,
): Record<string, Record<string, unknown>> {
  const out = { ...namespaces };
  for (const [from, to] of Object.entries(RENAMED_NAMESPACES)) {
    const entries = out[from];
    if (!entries) continue;
    delete out[from];
    out[to] = REKEYED_BY_NAME.has(from) ? rekeyByName(entries, from) : entries;
  }
  const folders = out.folders;
  if (folders && Object.hasOwn(folders, LEGACY_ASSIGNMENTS_KEY)) {
    const { [LEGACY_ASSIGNMENTS_KEY]: assignments, ...definitions } = folders;
    out.folders = definitions;
    const legacy = legacyBuiltInAssignments(assignments);
    if (Object.keys(legacy).length)
      out['hosted-legacy-folders'] = {
        ...out['hosted-legacy-folders'],
        ...legacy,
      };
    out['domain-folders'] = assignmentsByName(assignments);
  }
  return out;
}

/**
 * Brings a store written by an older DomBot up to SCHEMA_VERSION, one step
 * at a time. Idempotent: a step with nothing to move is skipped, and the
 * version is recorded after each step.
 *
 * `raw` is the store beneath any EncryptedDocStore. Renames copy values
 * exactly as stored, so a sealed value moves still sealed and a value the
 * cipher can't open right now (a locked keyring) is never dropped. `store` is
 * the host's configured store: the version marker goes through it, and so do
 * the values that have to be read (folder assignments).
 */
export async function runMigrations(
  raw: DocStore,
  store: DocStore,
): Promise<void> {
  const stored = await store.get('meta', 'schemaVersion');
  const version = typeof stored === 'number' ? stored : 0;
  if (version < 1) {
    await migration1(raw, store);
    await store.put('meta', 'schemaVersion', 1);
  }
  // v2 moved the Archive folder's names to Hidden; v5 removes both, so
  // that step has nothing left to do.
  if (version < 2) await store.put('meta', 'schemaVersion', 2);
  if (version < 3) {
    await migration3(store);
    await store.put('meta', 'schemaVersion', 3);
  }
  if (version < 4) {
    await migration4(raw);
    await store.put('meta', 'schemaVersion', 4);
  }
  if (version < 5) {
    await migration5(store);
    await store.put('meta', 'schemaVersion', 5);
  }
}

/** v1: namespace renames, and folders and prices keyed by name. */
async function migration1(raw: DocStore, store: DocStore): Promise<void> {
  const assignments = await store.get('folders', LEGACY_ASSIGNMENTS_KEY);
  if (assignments === null) {
    if ((await raw.get('folders', LEGACY_ASSIGNMENTS_KEY)) !== null) {
      // Stored but unreadable: leave everything as is and retry next start.
      throw new Error("[storage] can't read folder assignments to migrate");
    }
  } else {
    await store.putMany(
      'hosted-legacy-folders',
      Object.entries(legacyBuiltInAssignments(assignments)),
    );
    await store.putMany(
      'domain-folders',
      Object.entries(assignmentsByName(assignments)),
    );
    await store.delete('folders', LEGACY_ASSIGNMENTS_KEY);
  }

  for (const [from, to] of Object.entries(RENAMED_NAMESPACES)) {
    const entries = await raw.list(from);
    if (Object.keys(entries).length === 0) continue;
    const moved = REKEYED_BY_NAME.has(from)
      ? rekeyByName(entries, from)
      : entries;
    await raw.putMany(to, Object.entries(moved));
    await raw.clear(from);
  }
}

/**
 * v3: manual renewal prices gain a currency. Each stored USD number becomes
 * `{ amount, currency: 'USD' }` (docs/domain-import-export.md); a value that
 * doesn't hold is dropped.
 */
async function migration3(store: DocStore): Promise<void> {
  const entries = await store.list(RENEWAL_PRICES_NAMESPACE);
  const legacy = Object.entries(entries).filter(
    ([, value]) => typeof value === 'number',
  );
  if (legacy.length === 0) return;
  const converted = legacy.map(
    ([name, value]) => [name, toRenewalPrice(value)] as const,
  );
  await store.putMany(
    RENEWAL_PRICES_NAMESPACE,
    converted.filter((e): e is [string, RenewalPrice] => e[1] !== null),
  );
  for (const [name, price] of converted)
    if (price === null) await store.delete(RENEWAL_PRICES_NAMESPACE, name);
}

/** v4: `manual-domains` becomes `imported-domains`, values copied as stored. */
async function migration4(raw: DocStore): Promise<void> {
  const entries = await raw.list(LEGACY_IMPORTED_NAMESPACE);
  if (Object.keys(entries).length === 0) return;
  await raw.putMany(IMPORTED_NAMESPACE, Object.entries(entries));
  await raw.clear(LEGACY_IMPORTED_NAMESPACE);
}

/**
 * v5: Archive holds only names you no longer have (docs/owned-and-archive.md).
 * The `dropped` and `archived` events go, so a held name that was marked
 * comes back to Owned; the Hidden folder goes, so its names return to no
 * folder. Nothing changes meaning: every other event and assignment stays.
 */
async function migration5(store: DocStore): Promise<void> {
  const events = await store.list(EVENTS_NAMESPACE);
  for (const [id, e] of Object.entries(events)) {
    const type = (e as { type?: unknown } | null)?.type;
    if (typeof type === 'string' && LEGACY_EVENT_TYPES.has(type)) {
      await store.put('hosted-legacy-events', id, e);
      await store.delete(EVENTS_NAMESPACE, id);
    }
  }
  const assignments = await store.list(FOLDER_ASSIGNMENTS_NAMESPACE);
  for (const [name, id] of Object.entries(assignments))
    if (isLegacyBuiltInFolder(id)) {
      await store.put('hosted-legacy-folders', name, id);
      await store.delete(FOLDER_ASSIGNMENTS_NAMESPACE, name);
    }
}
