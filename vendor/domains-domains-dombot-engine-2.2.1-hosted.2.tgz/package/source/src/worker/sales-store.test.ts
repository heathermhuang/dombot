import { MemoryDocStore } from '../core/storage/doc-store';
import { configureStore, hydrateStores } from '../core/storage/namespace';
import { readFileSync } from 'node:fs';
import {
  beforeAll,
  beforeEach,
  afterAll,
  describe,
  it,
  expect,
  vi,
} from 'vitest';
import { Miniflare, convertV4MiniflareOptions } from 'miniflare';
import {
  SalesStore,
  readPublicSale,
  type SaleObservation,
} from './sales-store';
import { SalesInquiryStore, tokenHash } from './sales-inquiry-store';
import {
  emptySale,
  publishedSaleSchema,
  type SaleInquiry,
} from '../shared/hosted-sales';
import { sourcePriceFingerprint } from '../core/publication/sales';
import { exportSales, restoreSales, salesBackupSchema } from './sales-backup';
import { SalesJobs } from './sales-jobs';
import { createPublicSalesRoutes } from './public-sales';
import { Hono } from 'hono';
import { renderSalesLander } from '../shared/render-sales-lander';
import { signGatewayRequest } from '../shared/gateway-proof';
import { parseBundle } from '../core/storage/bundle';
import { createSalesInternalRoutes } from './sales-internal';
import { createSalesRoutes } from './sales-routes';
import { buildAuthConfig, type AuthConfig } from './auth';
import { publicShop, publicSalesCsv } from './sales-shop';
import { PublicationStore } from './publication-store';
import { emptyDraft } from '../shared/publication';
import { emptyOwnerSite } from '../shared/owner-site';
import { aesGcmCipher } from '../core/storage/encrypted';
import { deriveEncryptionKey } from './keys';

let mf: Miniflare, db: D1Database, store: SalesStore, inbox: SalesInquiryStore;
const root = new Uint8Array(32).fill(9);
const price = {
  amount: '14800',
  currency: 'USD',
  updatedAt: 100,
  floor: 'SECRET_FLOOR',
};
const observation = (): SaleObservation => ({
  price,
  ownershipFingerprint: 'owned-by-fixture',
  controlExpiresAt: Date.now() + 3600_000,
  available: true,
  reason: null,
});
const input = (): SaleInquiry => ({
  idempotencyKey: crypto.randomUUID(),
  observedRevision: crypto.randomUUID(),
  name: 'Sample Buyer',
  email: 'buyer@example.com',
  offer: null,
  message: 'Sample inquiry',
  turnstileToken: 'test-only',
  website: '',
});
beforeAll(async () => {
  mf = new Miniflare(
    convertV4MiniflareOptions({
      workers: [
        {
          name: 'sales-test',
          modules: true,
          script: 'export default {fetch(){return new Response("ok")}}',
          compatibilityDate: '2026-10-08',
          d1Databases: ['DB'],
        },
      ],
    }),
  );
  db = await mf.getD1Database('DB');
  for (const file of [
    '0002_publication.sql',
    '0004_sales.sql',
    '0009_sales_lifecycle.sql',
    '0005_sales_inquiries.sql',
  ])
    await db.exec(
      readFileSync(`migrations/${file}`, 'utf8')
        .replace(/^--.*$/gm, '')
        .replace(/\n/g, ' '),
    );
  store = await SalesStore.from({
    DB: db,
    DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
  });
  inbox = new SalesInquiryStore(store, 'https://host.example/w/fixture');
}, 30_000);
afterAll(async () => mf?.dispose());
beforeEach(async () => {
  configureStore(new MemoryDocStore());
  await hydrateStores();
  await db.batch(
    [
      'sales_journey_daily',
      'sales_journey_receipts',
      'portfolio_drafts',
      'published_portfolios',
      'sales_events',
      'sales_leads',
      'sales_reviews',
      'sales_shop_reviews',
      'sales_jobs',
      'sales_host_bindings',
      'sales_suppression',
      'sales_shop',
      'sale_drafts',
      'sale_destinations',
      'sales_abuse',
    ].map((t) => db.prepare(`DELETE FROM ${t}`)),
  );
});
async function live(name = 'fixture.example') {
  const draft = emptySale(name, sourcePriceFingerprint(price));
  const revision = await store.save(draft, null);
  const review = await store.prepare([{ id: draft.id, revision }], observation);
  await store.publish(review.id, observation);
  return (await readPublicSale(db, name))!;
}
async function relayFixture(claim = true) {
  const p = await live();
  const lead = await inbox.intake(
    { ...input(), observedRevision: p.revision },
    p,
  );
  const [verification] = await inbox.lease();
  await inbox.claim(verification.id, verification.lease);
  await inbox.ack(verification.id, verification.lease, 'accepted', 'fixture');
  await inbox.confirm(verification.mail.url.split('/').at(-1)!);
  const [notification] = await inbox.lease();
  const raw = 'ab'.repeat(24),
    hash = await tokenHash(raw);
  const grant = {
    tokenHash: hash,
    purpose: 'email-owner' as const,
    participant: 'owner@example.com',
    expiresAt: Date.now() + 7 * 86400_000,
  };
  if (claim) {
    expect(await inbox.claim(notification.id, notification.lease, grant)).toBe(
      true,
    );
    await inbox.ack(notification.id, notification.lease, 'accepted', 'fixture');
  }
  return {
    leadId: lead.id,
    raw,
    hash,
    grant,
    notification,
    request: {
      token: raw,
      from: 'owner@example.com',
      ownerEmail: 'owner@example.com',
      messageId: '<reply-1@fixture.example>',
      body: 'Owner email reply',
    },
  };
}
describe('role-scoped email relay grants', () => {
  it('logs owner and buyer replies once, creating only the opposite participant intent', async () => {
    const f = await relayFixture();
    await inbox.checkRelay(f.request);
    await inbox.relayMessage(f.request);
    await inbox.relayMessage(f.request);
    await expect(
      inbox.relayMessage({ ...f.request, body: 'changed duplicate' }),
    ).rejects.toThrow();
    const [toBuyer] = await inbox.lease();
    expect(toBuyer.kind).toBe('buyer-reply');
    expect(toBuyer.mail.recipient).toBe('buyer@example.com');
    const buyerToken = 'cd'.repeat(24);
    expect(
      await inbox.claim(toBuyer.id, toBuyer.lease, {
        tokenHash: await tokenHash(buyerToken),
        purpose: 'email-buyer',
        participant: 'buyer@example.com',
        expiresAt: Date.now() + 86400_000,
      }),
    ).toBe(true);
    await inbox.ack(toBuyer.id, toBuyer.lease, 'accepted', 'fixture');
    await expect(
      inbox.relayMessage({ ...f.request, token: buyerToken }),
    ).rejects.toThrow();
    await expect(
      inbox.relayMessage({ ...f.request, from: 'buyer@example.com' }),
    ).rejects.toThrow();
    await inbox.relayMessage({
      ...f.request,
      token: buyerToken,
      from: 'buyer@example.com',
      body: 'Buyer email reply',
    });
    const thread = await inbox.thread(f.leadId, true);
    expect(thread.messages.map((m) => [m.direction, m.body])).toEqual([
      ['reply', 'Owner email reply'],
      ['buyer', 'Buyer email reply'],
    ]);
    const outgoing = await inbox.lease();
    expect(outgoing).toHaveLength(1);
    expect(outgoing[0].kind).toBe('seller-alert');
    const metadata = JSON.stringify(
      (
        await db
          .prepare("SELECT * FROM sales_tokens WHERE purpose LIKE 'email-%'")
          .all()
      ).results,
    );
    expect(metadata).not.toContain(f.raw);
    expect(metadata).not.toContain('owner@example.com');
  });
  it('reconciles concurrent duplicate deliveries without a permanent rejection', async () => {
    const f = await relayFixture();
    const replies = await Promise.all([
      inbox.relayMessage(f.request),
      inbox.relayMessage(f.request),
    ]);
    expect(replies[0].id).toBe(replies[1].id);
    expect((await inbox.thread(f.leadId, true)).messages).toHaveLength(1);
    const outgoing = await inbox.lease();
    expect(outgoing).toHaveLength(1);
    expect(outgoing[0].kind).toBe('buyer-reply');
  });
  it('re-admits concurrent distinct replies after a revision conflict', async () => {
    const f = await relayFixture();
    const replies = await Promise.all([
      inbox.relayMessage(f.request),
      inbox.relayMessage({
        ...f.request,
        messageId: '<reply-2@fixture.example>',
        body: 'Second owner reply',
      }),
    ]);
    expect(replies[0].id).not.toBe(replies[1].id);
    const thread = await inbox.thread(f.leadId, true);
    expect(thread.messages.map((m) => m.body).sort()).toEqual([
      'Owner email reply',
      'Second owner reply',
    ]);
    expect(await inbox.lease()).toHaveLength(2);
  });
  it('registers only one role grant when two send claims race', async () => {
    const f = await relayFixture(false);
    const results = await Promise.all([
      inbox.claim(f.notification.id, f.notification.lease, f.grant),
      inbox.claim(f.notification.id, f.notification.lease, {
        ...f.grant,
        tokenHash: await tokenHash('ef'.repeat(24)),
      }),
    ]);
    expect(results.sort()).toEqual([false, true]);
    expect(
      (
        await db
          .prepare(
            "SELECT count(*) AS n FROM sales_tokens WHERE purpose LIKE 'email-%'",
          )
          .first<{ n: number }>()
      )?.n,
    ).toBe(1);
  });
  it('refuses a buyer-purpose grant on an owner notification', async () => {
    const f = await relayFixture(false);
    expect(
      await inbox.claim(f.notification.id, f.notification.lease, {
        ...f.grant,
        purpose: 'email-buyer',
        participant: 'buyer@example.com',
      }),
    ).toBe(false);
    expect(
      (
        await db
          .prepare(
            "SELECT count(*) AS n FROM sales_tokens WHERE purpose LIKE 'email-%'",
          )
          .first<{ n: number }>()
      )?.n,
    ).toBe(0);
  });
  it.each([
    'expired',
    'fresh-link',
    'spam',
    'delete',
    'restore',
    'participant-change',
  ])(
    'rejects %s aliases without a new message or delivery intent',
    async (mode) => {
      const f = await relayFixture();
      if (mode === 'expired')
        await db
          .prepare('UPDATE sales_tokens SET expires_at=0 WHERE token_hash=?')
          .bind(f.hash)
          .run();
      if (mode === 'fresh-link') await inbox.freshLink(f.leadId);
      if (mode === 'spam') {
        let l = await inbox.lead(f.leadId);
        await inbox.update(f.leadId, l.revision, 'spam', null);
        l = await inbox.lead(f.leadId);
        await inbox.update(f.leadId, l.revision, 'new', null);
      }
      if (mode === 'delete')
        await inbox.remove(f.leadId, (await inbox.lead(f.leadId)).revision);
      if (mode === 'restore')
        await restoreSales(store, await exportSales(store));
      const before = (await db
        .prepare('SELECT count(*) AS n FROM sales_outbox')
        .first<{ n: number }>())!.n;
      await expect(
        inbox.relayMessage({
          ...f.request,
          ...(mode === 'participant-change'
            ? {
                from: 'new-owner@example.com',
                ownerEmail: 'new-owner@example.com',
              }
            : {}),
        }),
      ).rejects.toThrow();
      expect(
        (
          await db
            .prepare('SELECT count(*) AS n FROM sales_messages')
            .first<{ n: number }>()
        )?.n,
      ).toBe(0);
      expect(
        (
          await db
            .prepare('SELECT count(*) AS n FROM sales_outbox')
            .first<{ n: number }>()
        )?.n,
      ).toBe(before);
    },
  );
  it('atomically denies revocation after parsing but before committing the message', async () => {
    const f = await relayFixture(),
      original = store.seal.bind(store);
    store.seal = async (value) => {
      if ((value as { body?: string }).body === 'racing reply')
        await db
          .prepare('UPDATE sales_tokens SET revoked_at=? WHERE token_hash=?')
          .bind(Date.now(), f.hash)
          .run();
      return original(value);
    };
    try {
      await expect(
        inbox.relayMessage({ ...f.request, body: 'racing reply' }),
      ).rejects.toThrow();
    } finally {
      store.seal = original;
    }
    expect(
      (
        await db
          .prepare('SELECT count(*) AS n FROM sales_messages')
          .first<{ n: number }>()
      )?.n,
    ).toBe(0);
    expect(
      (
        await db
          .prepare(
            "SELECT count(*) AS n FROM sales_outbox WHERE kind='buyer-reply'",
          )
          .first<{ n: number }>()
      )?.n,
    ).toBe(0);
  });
  it('removes quoted role credentials and caps valid-alias traffic', async () => {
    const f = await relayFixture();
    await inbox.relayMessage({
      ...f.request,
      body: `Reply. reply+11111111.${f.raw}@replies.example https://host.example/w/fixture/t/${'x'.repeat(43)}`,
    });
    const text = JSON.stringify(await inbox.thread(f.leadId, true));
    expect(text).not.toContain(f.raw);
    expect(text).not.toContain('x'.repeat(43));
    for (let i = 0; i < 20; i++) await inbox.checkRelay(f.request);
    await expect(inbox.checkRelay(f.request)).rejects.toThrow();
  });
});
describe('sales transaction and privacy boundary', () => {
  it('keeps drafts encrypted and publishes only explicit allowlisted snapshots', async () => {
    const snapshot = await live();
    expect(JSON.stringify(snapshot)).not.toContain('SECRET_FLOOR');
    expect(
      publishedSaleSchema.safeParse({ ...snapshot, floor: 'private' }).success,
    ).toBe(false);
    const raw = await db.prepare('SELECT * FROM sale_drafts').first();
    expect(JSON.stringify(raw)).not.toContain('fixture.example');
    expect(JSON.stringify(raw)).not.toContain('owned-by-fixture');
  });
  it('rejects stale reviews and leaves every item unchanged after a zero-row CAS', async () => {
    const a = emptySale('one.example', sourcePriceFingerprint(price)),
      b = emptySale('two.example', sourcePriceFingerprint(price));
    const ar = await store.save(a, null),
      br = await store.save(b, null);
    const review = await store.prepare(
      [
        { id: a.id, revision: ar },
        { id: b.id, revision: br },
      ],
      observation,
    );
    await store.save({ ...b, description: 'Changed elsewhere' }, br);
    await expect(store.publish(review.id, observation)).rejects.toThrow();
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM published_sales')
        .first<{ n: number }>())!.n,
    ).toBe(0);
    await expect(
      store.atomic([
        db
          .prepare("UPDATE sale_drafts SET availability='sold' WHERE id=?")
          .bind(a.id),
        ...store.guard(
          'EXISTS(SELECT 1 FROM sale_drafts WHERE id=? AND revision=?)',
          [b.id, br],
        ),
      ]),
    ).rejects.toThrow();
    expect((await store.get(a.id)).availability).toBe('paused');
  });
  it('rejects changed source prices and replays a committed receipt without republishing', async () => {
    const draft = emptySale('fixture.example', sourcePriceFingerprint(price)),
      revision = await store.save(draft, null);
    const review = await store.prepare(
      [{ id: draft.id, revision }],
      observation,
    );
    await expect(
      store.publish(review.id, () => ({
        ...observation(),
        price: { ...price, amount: '20000' },
      })),
    ).rejects.toThrow();
    const receipt = await store.publish(review.id, observation);
    expect(await store.publish(review.id, observation)).toEqual(receipt);
  });
  it('pause and expired control suppress public reads immediately', async () => {
    const p = await live(),
      saved = await store.get(p.id);
    await store.availability(p.id, saved.operationalRevision, 'paused');
    expect(await readPublicSale(db, p.domain)).toBeNull();
    await db
      .prepare(
        "UPDATE sale_drafts SET availability='available',control_expires_at=0",
      )
      .run();
    expect(await readPublicSale(db, p.domain)).toBeNull();
  });
});
describe('durable inquiry and outbox', () => {
  it('accepts the full public form, uses signed original metadata, and returns only a receipt', async () => {
    const p = await live();
    const form = new URLSearchParams({
      observedRevision: p.revision,
      idempotencyKey: crypto.randomUUID(),
      name: 'Form contact',
      email: 'contact@example.test',
      message: 'Tell me more',
      website: '',
      profileUrl: 'https://example.test/profile',
      company: 'Form organization',
      companyWebsite: 'https://example.test',
      inquiryRole: 'representative',
      'cf-turnstile-response': 'fixture-challenge',
    });
    const request = new Request(
      `https://fixture.example/d/${p.domain}/inquiries`,
      {
        method: 'POST',
        body: form,
        headers: {
          Origin: 'https://fixture.example',
          'cf-connecting-ip': '192.0.2.2',
          'user-agent': 'Internal-hop browser',
        },
      },
    );
    const metadata = {
      receivedAt: Date.now(),
      ipAddress: '203.0.113.77',
      userAgent: 'Original reported browser',
      language: 'en-SG',
      country: 'SG',
      region: null,
      city: 'Singapore',
      timezone: 'Asia/Singapore',
    };
    const key = 'synthetic-public-form-key-'.repeat(3),
      workspace = crypto.randomUUID();
    request.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, null, request, {
        purpose: 'sales-public',
        host: 'fixture.example',
        listing: null,
        epoch: 0,
        inquiryRequest: metadata,
      }),
    );
    const originalFetch = globalThis.fetch;
    const fetchMock = vi
      .spyOn(globalThis, 'fetch')
      .mockImplementation((url, options) =>
        String(url) ===
        'https://challenges.cloudflare.com/turnstile/v0/siteverify'
          ? Promise.resolve(
              Response.json({
                success: true,
                hostname: 'fixture.example',
                action: 'sales-inquiry',
              }),
            )
          : originalFetch(url, options),
      );
    try {
      const response = await createPublicSalesRoutes().request(
        request,
        undefined,
        {
          DB: db,
          DOMBOT_AUTH: 'gateway',
          DOMBOT_GATEWAY_SECRET: key,
          DOMBOT_WORKSPACE_ID: workspace,
          DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
          SALES_INQUIRIES_ENABLED: 'true',
          SALES_PRIVACY_REVIEWED: 'true',
          SALES_TURNSTILE_SECRET: 'fixture-only',
          SALES_TURNSTILE_SITEKEY: 'fixture-sitekey',
          DOMBOT_SALES_ORIGIN: 'https://fixture.example',
        } as Env,
      );
      expect(response.status).toBe(202);
      const html = await response.text();
      expect(html).toContain('Inquiry saved');
      expect(html).not.toMatch(
        /203\.0\.113\.77|Original reported browser|Form organization/,
      );
      const row = await db
        .prepare('SELECT id FROM sales_leads')
        .first<{ id: string }>();
      const thread = await inbox.thread(row!.id);
      expect(thread.buyerDetails).toEqual({
        profileUrl: 'https://example.test/profile',
        company: 'Form organization',
        companyWebsite: 'https://example.test',
        inquiryRole: 'representative',
      });
      expect(thread.requestMetadata).toEqual(metadata);
    } finally {
      fetchMock.mockRestore();
    }
  });

  it('seals identity details and original request context, exposes them only to the owner, and round-trips them through recovery', async () => {
    const p = await live();
    const value = {
      ...input(),
      observedRevision: p.revision,
      buyerDetails: {
        profileUrl: 'https://example.test/profile',
        company: 'PRIVATE_COMPANY',
        companyWebsite: 'https://example.test',
        inquiryRole: 'organization' as const,
      },
    };
    const metadata = {
      receivedAt: Date.now(),
      ipAddress: '203.0.113.71',
      userAgent: 'PRIVATE_BROWSER',
      language: 'en-SG',
      country: 'SG',
      region: null,
      city: 'Singapore',
      timezone: 'Asia/Singapore',
    };
    const receipt = await inbox.intake(value, p, metadata);
    expect(
      await inbox.intake(value, p, { ...metadata, ipAddress: '192.0.2.3' }),
    ).toEqual(receipt);
    expect((await inbox.thread(receipt.id)).requestMetadata).toEqual(metadata);
    expect((await inbox.thread(receipt.id)).buyerDetails).toEqual(
      value.buyerDetails,
    );
    const row = JSON.stringify(
      await db.prepare('SELECT * FROM sales_leads').all(),
    );
    expect(row).not.toMatch(/PRIVATE_COMPANY|PRIVATE_BROWSER|203\.0\.113\.71/);
    expect(JSON.stringify(await inbox.thread(receipt.id, true))).not.toMatch(
      /PRIVATE_COMPANY|PRIVATE_BROWSER|203\.0\.113\.71/,
    );
    expect(
      JSON.stringify(await inbox.emailContext(receipt.id, null)),
    ).not.toMatch(/PRIVATE_COMPANY|PRIVATE_BROWSER|203\.0\.113\.71/);
    expect((await inbox.lease())[0].mail.context.name).toBe(value.name);
    await expect(
      inbox.intake(
        {
          ...value,
          buyerDetails: { ...value.buyerDetails, company: 'Different' },
        },
        p,
        metadata,
      ),
    ).rejects.toThrow(/different content/);
    const backup = await exportSales(store);
    expect(backup.version).toBe(4);
    await restoreSales(store, backup);
    const restored = await inbox.thread(receipt.id);
    expect(restored.requestMetadata).toEqual(metadata);
    expect(restored.buyerDetails).toEqual(value.buyerDetails);
    await inbox.remove(receipt.id, restored.revision);
    await expect(inbox.lead(receipt.id)).rejects.toThrow(/not found/);
  });
  it('reads legacy inquiry records without fabricating identity or network details', async () => {
    const p = await live();
    const receipt = await inbox.intake(
      { ...input(), observedRevision: p.revision },
      p,
    );
    const thread = await inbox.thread(receipt.id);
    expect(thread.buyerDetails).toBeNull();
    expect(thread.requestMetadata).toBeNull();
  });

  it('projects complete email details without leaking private notes or unrelated messages', async () => {
    const p = await live();
    const r = await inbox.intake(
      { ...input(), observedRevision: p.revision },
      p,
    );
    const [verification] = await inbox.lease();
    expect(verification.mail.context).toMatchObject({
      name: 'Sample Buyer',
      email: 'buyer@example.com',
      message: 'Sample inquiry',
      snapshot: { domain: p.domain },
      latest: null,
    });
    await inbox.confirm(verification.mail.url.split('/').at(-1)!);
    let lead = await inbox.lead(r.id);
    const note = await inbox.message(r.id, {
      direction: 'private-note',
      body: 'PRIVATE_EMAIL_NOTE',
      revision: lead.revision,
      idempotencyKey: crypto.randomUUID(),
    });
    expect((await inbox.emailContext(r.id, note.id)).latest).toBeNull();
    lead = await inbox.lead(r.id);
    await inbox.message(r.id, {
      direction: 'reply',
      body: 'Complete public reply',
      revision: lead.revision,
      idempotencyKey: crypto.randomUUID(),
    });
    const reply = (await inbox.lease()).find((v) => v.kind === 'buyer-reply')!;
    expect(reply.mail.context.latest?.body).toBe('Complete public reply');
    expect(JSON.stringify(reply.mail.context)).not.toContain(
      'PRIVATE_EMAIL_NOTE',
    );
  });
  it('deduplicates requests, binds their content and seals buyer PII', async () => {
    const p = await live(),
      v = { ...input(), observedRevision: p.revision };
    const a = await inbox.intake(v, p),
      b = await inbox.intake(v, p);
    expect(a).toEqual(b);
    expect(
      await inbox.intake(
        { ...v, buyerDetails: { company: '', inquiryRole: '' } },
        p,
      ),
    ).toEqual(a);
    await expect(
      inbox.intake({ ...v, message: 'different' }, p),
    ).rejects.toThrow();
    expect(
      JSON.stringify(await db.prepare('SELECT * FROM sales_leads').all()),
    ).not.toContain('buyer@example.com');
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sales_outbox')
        .first<{ n: number }>())!.n,
    ).toBe(1);
  });
  it('GET-style token inspection cannot verify; confirmation enqueues one seller notification', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p);
    const [mail] = await inbox.lease();
    const raw = mail.mail.url.split('/').at(-1)!;
    expect((await inbox.token(raw, 'verify'))!.consumed_at).toBeNull();
    expect((await inbox.lead(r.id)).verification).toBe('pending');
    await inbox.confirm(raw);
    await inbox.confirm(raw);
    expect((await inbox.lead(r.id)).verification).toBe('verified');
    expect(
      (await inbox.lease()).filter((v) => v.kind === 'seller-alert'),
    ).toHaveLength(1);
  });
  it('two drainers cannot share a lease, expired sends become unknown, stale ACK fails', async () => {
    const p = await live();
    await inbox.intake({ ...input(), observedRevision: p.revision }, p);
    const [a, b] = await Promise.all([inbox.lease(), inbox.lease()]);
    expect(a.length + b.length).toBe(1);
    const item = [...a, ...b][0];
    await db.prepare('UPDATE sales_outbox SET lease_expires_at=0').run();
    expect(await inbox.lease()).toHaveLength(0);
    await expect(
      inbox.ack(item.id, item.lease, 'accepted', 'receipt'),
    ).rejects.toThrow();
    expect(
      (await db
        .prepare('SELECT state FROM sales_outbox')
        .first<{ state: string }>())!.state,
    ).toBe('unknown');
  });
  it('claims each send once and rejects cached leases after spam, deletion or expiry', async () => {
    const p = await live();
    const first = await inbox.intake(
      { ...input(), observedRevision: p.revision },
      p,
    );
    const [mail] = await inbox.lease();
    const lead = await inbox.lead(first.id);
    await inbox.update(first.id, lead.revision, 'spam', null);
    expect(await inbox.claim(mail.id, mail.lease)).toBe(false);
    const reopened = await inbox.lead(first.id);
    await inbox.update(first.id, reopened.revision, 'new', null);
    await inbox.freshLink(first.id);
    const [fresh] = await inbox.lease();
    expect(await inbox.claim(fresh.id, fresh.lease)).toBe(true);
    expect(await inbox.claim(fresh.id, fresh.lease)).toBe(false);
    await inbox.freshLink(first.id);
    const [expired] = await inbox.lease();
    await db
      .prepare('UPDATE sales_outbox SET lease_expires_at=0 WHERE id=?')
      .bind(expired.id)
      .run();
    expect(await inbox.claim(expired.id, expired.lease)).toBe(false);
    await inbox.freshLink(first.id);
    const [removed] = await inbox.lease();
    await inbox.remove(first.id, (await inbox.lead(first.id)).revision);
    expect(await inbox.claim(removed.id, removed.lease)).toBe(false);
  });
  it('fresh-link recovery cancels only unsent obsolete links and preserves unknown delivery evidence', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p),
      [old] = await inbox.lease();
    await inbox.ack(old.id, old.lease, 'retryable', null);
    await inbox.freshLink(r.id);
    expect(
      (await db
        .prepare('SELECT state FROM sales_outbox WHERE id=?')
        .bind(old.id)
        .first<{ state: string }>())!.state,
    ).toBe('suppressed');
    expect(await inbox.claim(old.id, old.lease)).toBe(false);
    const [fresh] = await inbox.lease();
    await inbox.ack(fresh.id, fresh.lease, 'unknown', null);
    await inbox.freshLink(r.id);
    expect(
      (await db
        .prepare('SELECT state FROM sales_outbox WHERE id=?')
        .bind(fresh.id)
        .first<{ state: string }>())!.state,
    ).toBe('unknown');
    expect(await inbox.lease()).toHaveLength(1);
  });
  it('private notes never reach the buyer and reply tokens are purpose-bound', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p);
    const [mail] = await inbox.lease(),
      raw = mail.mail.url.split('/').at(-1)!;
    await inbox.confirm(raw);
    const lead = await inbox.lead(r.id);
    await inbox.message(r.id, {
      direction: 'private-note',
      body: 'PRIVATE_NOTE_SENTINEL',
      revision: lead.revision,
      idempotencyKey: crypto.randomUUID(),
    });
    expect(JSON.stringify(await inbox.thread(r.id, true))).not.toContain(
      'PRIVATE_NOTE_SENTINEL',
    );
    expect(JSON.stringify(await inbox.thread(r.id))).toContain(
      'PRIVATE_NOTE_SENTINEL',
    );
    expect(await inbox.token(raw, 'thread')).toBeNull();
  });
});

describe('backup, jobs and public HTTP', () => {
  it('rotates keys, restores private data silently, and removes all capabilities and delivery intents', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p);
    const backup = await exportSales(store);
    const other = await SalesStore.from({
      DB: db,
      DOMBOT_SECRET: btoa(String.fromCharCode(...new Uint8Array(32).fill(17))),
    });
    await restoreSales(other, backup);
    expect(await readPublicSale(db, p.domain)).toBeNull();
    expect((await other.get(p.id)).availability).toBe('paused');
    const restored = new SalesInquiryStore(other, 'https://host.example');
    expect((await restored.lead(r.id)).payload.email).toBe('buyer@example.com');
    expect(await restored.lease()).toHaveLength(0);
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sales_tokens')
        .first<{ n: number }>())!.n,
    ).toBe(0);
    expect(
      salesBackupSchema.safeParse({
        ...backup,
        leads: [{ ...backup.leads[0], payload: { email: 'bad' } }],
      }).success,
    ).toBe(false);
    expect(() =>
      parseBundle(
        JSON.stringify({
          format: 'dombot-data',
          version: 9,
          namespaces: {},
          sales: backup,
        }),
      ),
    ).toThrow(/hosted sales/);
    // Return the normal root for the next test; previous rows are removed in beforeEach.
  });
  it('resumes only pending bulk items and retains a stale-item receipt', async () => {
    const a = emptySale('a.example', sourcePriceFingerprint(price)),
      b = emptySale('b.example', sourcePriceFingerprint(price));
    const ar = await store.save(a, null),
      br = await store.save(b, null),
      jobs = new SalesJobs(store);
    const job = await jobs.create(
      [
        { id: a.id, revision: ar },
        { id: b.id, revision: br },
      ],
      { kind: 'shop', include: true },
      crypto.randomUUID(),
    );
    await store.save({ ...b, description: 'changed' }, br);
    const first = await jobs.step(job.id, observation),
      saved = await store.get(a.id);
    expect(first.counts).toEqual(
      expect.arrayContaining([
        { state: 'complete', count: 1 },
        { state: 'needs-review', count: 1 },
      ]),
    );
    await jobs.step(job.id, observation);
    expect((await store.get(a.id)).revision).toBe(saved.revision);
    expect(saved.draft.includeInShop).toBe(true);
  });
  it('serves landers without the root key and blocks mismatched signed hostname epochs', async () => {
    const p = await live(),
      app = new Hono<{ Bindings: Env }>();
    app.route('/', createPublicSalesRoutes());
    const publicResponse = await app.request(
      `https://host.example/d/${p.domain}`,
      {},
      { DB: db, DOMBOT_AUTH: 'password' } as Env,
    );
    expect(publicResponse.status).toBe(200);
    const html = await publicResponse.text();
    expect(html).not.toContain('SECRET_FLOOR');
    const form = renderSalesLander(p, '', 'test-sitekey', {
      privacyUrl: 'https://accounts.example/privacy',
      inquiryPath: '/inquiries',
    });
    expect(form).toContain('href="https://accounts.example/privacy"');
    expect(form).toContain('action="/inquiries"');
    expect(html).toContain('domains.domains');
    const key = 'test-edge-secret-for-sales'.repeat(3),
      workspace = crypto.randomUUID();
    const request = new Request(`https://fixture.example/d/${p.domain}`);
    request.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, null, request, {
        purpose: 'sales-public',
        host: 'fixture.example',
        listing: p.id,
        epoch: 1,
      }),
    );
    await db
      .prepare(
        'INSERT INTO sales_host_bindings(hostname,listing_id,epoch,enabled) VALUES(?,?,2,1)',
      )
      .bind('fixture.example', p.id)
      .run();
    expect(
      (
        await app.request(request, undefined, {
          DB: db,
          DOMBOT_AUTH: 'gateway',
          DOMBOT_SALES_EDGE_SECRET: key,
          DOMBOT_WORKSPACE_ID: workspace,
        } as Env)
      ).status,
    ).toBe(404);
  });
  it('returns current public terms and preserves buyer fields when a publication changes', async () => {
    const p = await live(),
      app = createPublicSalesRoutes();
    const response = await app.request(
      `https://fixture.example/d/${p.domain}/inquiries`,
      {
        method: 'POST',
        headers: {
          Origin: 'https://fixture.example',
          'Content-Type': 'application/x-www-form-urlencoded',
          'cf-connecting-ip': '192.0.2.1',
        },
        body: new URLSearchParams({
          observedRevision: crypto.randomUUID(),
          idempotencyKey: crypto.randomUUID(),
          profileUrl: 'https://example.test/profile',
          company: 'Preserved organization',
          companyWebsite: 'https://example.test',
          inquiryRole: 'representative',
          name: 'Preserved Buyer',
          email: 'buyer@example.com',
          message: 'Preserved message',
          website: '',
          'cf-turnstile-response': '',
        }),
      },
      {
        DB: db,
        DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
        SALES_INQUIRIES_ENABLED: 'true',
        SALES_PRIVACY_REVIEWED: 'true',
        SALES_TURNSTILE_SECRET: 'fixture-only',
        SALES_TURNSTILE_SITEKEY: 'fixture-sitekey',
        DOMBOT_SALES_ORIGIN: 'https://fixture.example',
      } as Env,
    );
    expect(response.status).toBe(409);
    const html = await response.text();
    expect(html).toContain('Preserved Buyer');
    expect(html).toContain('Preserved message');
    expect(html).toContain('https://example.test/profile');
    expect(html).toContain('Preserved organization');
    expect(html).toContain('value="representative" selected');
    expect(html).not.toContain('buying');
    expect(html).toContain(p.revision);
    expect(html).toContain('terms changed');
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sales_leads')
        .first<{ n: number }>())!.n,
    ).toBe(0);
  });
  it('escapes buyer-facing content, never embeds notes, and retains public schema strictness', async () => {
    const p = await live();
    const html = renderSalesLander(
      { ...p, description: '<script>private-sentinel</script>' },
      '',
      null,
    );
    expect(html).toContain('&lt;script&gt;');
    expect(html).not.toContain('<script>private-sentinel');
    expect(html).not.toContain('SECRET_FLOOR');
  });
});

describe('sales recovery and isolation regressions', () => {
  async function verifiedLead() {
    const p = await live(),
      receipt = await inbox.intake(
        { ...input(), observedRevision: p.revision },
        p,
      );
    const [mail] = await inbox.lease();
    await inbox.confirm(mail.mail.url.split('/').at(-1)!);
    return { p, id: receipt.id };
  }
  it('requires fresh buyer confirmation after restoring a verified conversation', async () => {
    const { id } = await verifiedLead(),
      backup = await exportSales(store);
    await restoreSales(store, backup);
    const lead = await inbox.lead(id);
    expect(lead.verification).toBe('expired');
    await expect(
      inbox.message(id, {
        direction: 'reply',
        body: 'Must not send',
        revision: lead.revision,
        idempotencyKey: crypto.randomUUID(),
      }),
    ).rejects.toThrow(/verified/);
    await inbox.freshLink(id);
    expect((await inbox.lease())[0].kind).toBe('verification');
  });
  it('rekeys a blocked-recipient lookup even after its inquiry was deleted', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p),
      lead = await inbox.lead(r.id);
    await inbox.update(r.id, lead.revision, 'spam', null);
    await inbox.remove(r.id, (await inbox.lead(r.id)).revision);
    const before = (await db
      .prepare('SELECT email_hash,sealed FROM sales_suppression')
      .first<{ email_hash: string; sealed: string }>())!;
    expect(JSON.stringify(before)).not.toContain('buyer@example.com');
    const backup = await exportSales(store),
      other = await SalesStore.from({
        DB: db,
        DOMBOT_SECRET: btoa(String.fromCharCode(...new Uint8Array(32).fill(4))),
      });
    await restoreSales(other, backup);
    expect(
      await new SalesInquiryStore(other, 'https://fixture.example').suppressed(
        'buyer@example.com',
      ),
    ).toBe(true);
    expect(
      (await db
        .prepare('SELECT email_hash FROM sales_suppression')
        .first<{ email_hash: string }>())!.email_hash,
    ).not.toBe(before.email_hash);
  });
  it('retention erases messages, grants, outbox and outcome evidence together', async () => {
    const p = await live(),
      r = await inbox.intake({ ...input(), observedRevision: p.revision }, p),
      lead = await inbox.lead(r.id);
    await inbox.update(r.id, lead.revision, 'new', null, {
      state: 'handed-off',
      source: 'seller-entered',
      evidence: 'PRIVATE_EVIDENCE',
      price: null,
      provider: 'Manual',
    });
    await db
      .prepare('UPDATE sales_leads SET created_at=? WHERE id=?')
      .bind(Date.now() - 8 * 86400000, r.id)
      .run();
    await inbox.cleanup();
    for (const table of [
      'sales_leads',
      'sales_messages',
      'sales_tokens',
      'sales_outbox',
    ])
      expect(
        (await db
          .prepare(`SELECT count(*) AS n FROM ${table}`)
          .first<{ n: number }>())!.n,
      ).toBe(0);
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sales_events WHERE lead_id=?')
        .bind(r.id)
        .first<{ n: number }>())!.n,
    ).toBe(0);
  });
  it('message pages are chronological, opaque, and cannot expose notes through an owner cursor', async () => {
    const { id } = await verifiedLead();
    const writes = [];
    for (let sequence = 1; sequence <= 107; sequence++)
      writes.push(
        db
          .prepare(
            'INSERT INTO sales_messages(id,lead_id,request_hash,payload_hash,direction,created_at,sealed,sequence) VALUES(?,?,?,?,?,?,?,?)',
          )
          .bind(
            crypto.randomUUID(),
            id,
            `fixture-${sequence}`,
            'fixture',
            sequence === 50 || sequence === 100 ? 'private-note' : 'buyer',
            Date.now(),
            await store.seal({
              body:
                sequence === 50 || sequence === 100
                  ? 'PRIVATE_NOTE_SENTINEL'
                  : `Message ${sequence}`,
              recipient: null,
            }),
            sequence,
          ),
      );
    await db.batch(writes);
    const buyer = await inbox.thread(id, true);
    expect(buyer.messages[0].body).toBe('Message 6');
    expect(buyer.messages.at(-1)!.body).toBe('Message 107');
    expect(JSON.stringify(buyer)).not.toContain('PRIVATE_NOTE_SENTINEL');
    expect(buyer.messages[0]).not.toHaveProperty('sequence');
    const older = await inbox.thread(id, true, buyer.cursor!);
    expect(older.messages.map((m) => m.body)).toEqual([
      'Message 1',
      'Message 2',
      'Message 3',
      'Message 4',
      'Message 5',
    ]);
    const owner = await inbox.thread(id);
    await expect(inbox.thread(id, true, owner.cursor!)).rejects.toThrow(
      /cursor/,
    );
  });
  it('due-work discovery includes expired orphan leases', async () => {
    const p = await live();
    await inbox.intake({ ...input(), observedRevision: p.revision }, p);
    await inbox.lease();
    await db.prepare('UPDATE sales_outbox SET lease_expires_at=1').run();
    const key = 'internal-fixture-key'.repeat(3),
      workspace = crypto.randomUUID(),
      app = new Hono<{ Bindings: Env }>();
    app.route('/sales-internal', createSalesInternalRoutes());
    const request = new Request('https://fixture.example/sales-internal/due');
    request.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, null, request, {
        purpose: 'sales-notifications',
      }),
    );
    const response = await app.request(request, undefined, {
      DB: db,
      DOMBOT_GATEWAY_SECRET: key,
      DOMBOT_WORKSPACE_ID: workspace,
    } as Env);
    expect(response.status).toBe(200);
    expect((await response.json()).dueAt).toBe(1);
  });
  it('private sales reads require explicit owner admission before hydration', async () => {
    const key = 'owner-fixture-key'.repeat(3),
      workspace = crypto.randomUUID(),
      env = {
        DB: db,
        DOMBOT_AUTH: 'gateway',
        DOMBOT_GATEWAY_SECRET: key,
        DOMBOT_WORKSPACE_ID: workspace,
        DOMBOT_SALES_V1: 'true',
      } as Env;
    const auth = await buildAuthConfig(env, root),
      app = new Hono<{ Bindings: Env; Variables: { auth: AuthConfig } }>();
    let hydrations = 0;
    app.use('*', async (c, next) => {
      c.set('auth', auth);
      await next();
    });
    app.route(
      '/sales',
      createSalesRoutes(async (_c, next) => {
        hydrations++;
        await next();
      }),
    );
    const legacy = new Request('https://fixture.example/sales/capabilities');
    legacy.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, 'seller', legacy),
    );
    expect((await app.request(legacy, undefined, env)).status).toBe(403);
    expect(hydrations).toBe(0);
    const owner = new Request('https://fixture.example/sales/capabilities');
    owner.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, 'seller', owner, {
        purpose: 'sales-owner',
        recipientVerified: false,
      }),
    );
    expect((await app.request(owner, undefined, env)).status).toBe(200);
    expect(hydrations).toBe(1);
  });
  it('returns recognizable kept, added and removed names in the exact shop review', async () => {
    const kept = await live('kept.example'),
      added = await live('added.example'),
      removed = await live('removed.example');
    const prior = {
      version: 1 as const,
      handle: 'sample',
      title: 'Sample',
      intro: '',
      listingIds: [kept.id, removed.id],
    };
    const first = await store.saveShop(prior, null);
    await db
      .prepare("UPDATE sales_shop SET published=? WHERE id='main'")
      .bind(JSON.stringify(prior))
      .run();
    const revision = await store.saveShop(
      { ...prior, listingIds: [kept.id, added.id] },
      first,
    );
    const key = 'shop-review-fixture'.repeat(3),
      workspace = crypto.randomUUID();
    const env = {
      DB: db,
      DOMBOT_AUTH: 'gateway',
      DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
      DOMBOT_GATEWAY_SECRET: key,
      DOMBOT_WORKSPACE_ID: workspace,
      DOMBOT_SALES_V1: 'true',
    } as Env;
    const auth = await buildAuthConfig(env, root),
      app = new Hono<{ Bindings: Env; Variables: { auth: AuthConfig } }>();
    app.use('*', async (c, next) => {
      c.set('auth', auth);
      await next();
    });
    app.route(
      '/sales',
      createSalesRoutes(async (_c, next) => {
        await next();
      }),
    );
    const request = new Request('https://fixture.example/sales/shop/reviews', {
      method: 'POST',
      headers: {
        Origin: 'https://fixture.example',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ revision }),
    });
    request.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, 'seller', request, {
        purpose: 'sales-owner',
        recipientVerified: true,
      }),
    );
    const response = await app.request(request, undefined, env);
    expect(response.status, await response.clone().text()).toBe(200);
    const review = await response.json();
    expect(review.terms.map((term: { domain: string }) => term.domain)).toEqual(
      ['kept.example', 'added.example'],
    );
    expect(review.removed).toEqual([
      { id: removed.id, domain: 'removed.example' },
    ]);
    expect(JSON.stringify(review)).not.toContain('SECRET_FLOOR');
  });
  it('shop filters and CSV recheck availability and exclude unpublished names', async () => {
    const a = await live('one.example'),
      b = await live('two.example'),
      privateDraft = emptySale(
        'private.example',
        sourcePriceFingerprint(price),
      );
    await store.save(privateDraft, null);
    const shop = {
      version: 1 as const,
      handle: 'sample',
      title: 'Sample shop',
      intro: 'Sample data',
      listingIds: [a.id, b.id, privateDraft.id],
    };
    await store.saveShop(shop, null);
    await db
      .prepare("UPDATE sales_shop SET published=? WHERE id='main'")
      .bind(JSON.stringify(shop))
      .run();
    await store.availability(
      b.id,
      (await store.get(b.id)).operationalRevision,
      'sold',
    );
    const result = await publicShop(db, 'sample', {
      currency: 'USD',
      min: '14000',
      max: '15000',
    });
    expect(result.items.map((s) => s.domain)).toEqual(['one.example']);
    const csv = publicSalesCsv(result.items);
    expect(csv).not.toContain('private.example');
    expect(csv).not.toContain('two.example');
    expect(csv).not.toContain('SECRET_FLOOR');
    expect((await publicShop(db, 'sample', { q: '%' })).items).toHaveLength(0);
    const app = createPublicSalesRoutes();
    const html = await (
      await app.request('https://host.example/shop/sample', {}, {
        DB: db,
      } as Env)
    ).text();
    expect(html).toContain('<details class="shop-filters" >');
    expect(html).toContain('1 domain shown');
    expect(html).toContain('value="inquiry"');
    expect(html).toContain('Domain inquiry');
    expect(html).not.toContain('private.example');
    const filtered = await (
      await app.request(
        'https://host.example/shop/sample?mode=inquiry&q=%3Cscript%3E',
        {},
        { DB: db } as Env,
      )
    ).text();
    expect(filtered).toContain('<details class="shop-filters" open>');
    expect(filtered).toContain('Reset filters');
    expect(filtered).toContain('&lt;script&gt;');
    expect(filtered).not.toContain('<script>');
  });
  it('gives unavailable canonical inquiry proofs safe generic recovery without leaking inquiry data', async () => {
    const app = createPublicSalesRoutes();
    const env = {
      DB: db,
      DOMBOT_SALES_ORIGIN: 'https://host.example',
      DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
    } as Env;
    const responses = [];
    for (const token of ['invalid', 'ab'.repeat(24)]) {
      const response = await app.request(
        'https://host.example/i/' + token,
        {},
        env,
      );
      expect(response.status).toBe(403);
      const html = await response.text();
      expect(html).toContain('Go to domains.domains');
      expect(html).toContain('mailto:domains@domains.domains');
      expect(html).not.toContain('buyer@example.com');
      expect(html).not.toContain('fixture.example');
      expect(html).not.toContain('/confirm');
      responses.push(html);
    }
    expect(responses[0]).toBe(responses[1]);
  });
  it('deleting a domain erases dependent sales data without removing another listing', async () => {
    const { p, id } = await verifiedLead(),
      other = await live('other.example'),
      saved = await store.get(p.id);
    const review = await store.prepare(
        [{ id: p.id, revision: saved.revision }],
        observation,
      ),
      jobs = new SalesJobs(store),
      job = await jobs.create(
        [{ id: p.id, revision: saved.revision }],
        { kind: 'shop', include: true },
        crypto.randomUUID(),
      );
    await store.removeNames(['FIXTURE.EXAMPLE']);
    expect(await readPublicSale(db, p.domain)).toBeNull();
    expect(await readPublicSale(db, other.domain)).not.toBeNull();
    await expect(inbox.lead(id)).rejects.toThrow(/not found/);
    await expect(store.review(review.id)).rejects.toThrow(/not found/);
    await expect(jobs.get(job.id)).rejects.toThrow(/not found/);
  });
});

describe('global listing filters and reviewed publication jobs', () => {
  it('searches private names through authorized hashed candidates and filters stale price sources', async () => {
    const draft = {
      ...emptySale('unlisted.example', sourcePriceFingerprint(price)),
      mode: 'offer' as const,
    };
    await store.save(draft, null);
    expect(
      (
        await store.list('', 100, {
          q: 'unlisted',
          domains: ['unlisted.example'],
          mode: 'offer',
        })
      ).items.map((i) => i.draft.id),
    ).toEqual([draft.id]);
    expect(
      (await store.list('', 100, { q: 'other', domains: [] })).items,
    ).toHaveLength(0);
    const stale = await store.stalePriceIds({
      'unlisted.example': { ...price, amount: '20000' },
    });
    expect(stale).toEqual([draft.id]);
    expect(
      (await store.list('', 100, { state: 'Needs attention', staleIds: stale }))
        .items,
    ).toHaveLength(1);
    expect(
      JSON.stringify(await db.prepare('SELECT * FROM sale_drafts').all()),
    ).not.toContain('unlisted.example');
  });
  it('requires exact approval and advances only its own shop revision across publication batches', async () => {
    const foundation = await live('foundation.example'),
      shop = {
        version: 1 as const,
        handle: 'sample',
        title: 'Sample shop',
        intro: '',
        listingIds: [foundation.id],
      };
    await store.saveShop(shop, null);
    await db
      .prepare("UPDATE sales_shop SET published=? WHERE id='main'")
      .bind(JSON.stringify(shop))
      .run();
    const refs = [],
      reviews = [];
    for (const domain of ['first.example', 'second.example']) {
      const d = {
        ...emptySale(domain, sourcePriceFingerprint(price)),
        includeInShop: true,
      };
      const revision = await store.save(d, null);
      refs.push({ id: d.id, revision });
      reviews.push(
        (await store.prepare([{ id: d.id, revision }], observation)).id,
      );
    }
    const jobs = new SalesJobs(store),
      job = await jobs.create(
        refs,
        { kind: 'publish', reviewIds: reviews },
        crypto.randomUUID(),
      );
    await expect(jobs.step(job.id, observation)).rejects.toThrow(/approve/);
    const manifest = await jobs.review(job.id);
    await expect(jobs.approve(job.id, 'wrong')).rejects.toThrow(/manifest/);
    await jobs.approve(job.id, manifest.digest);
    const result = await jobs.step(job.id, observation);
    expect(result.counts).toEqual([{ state: 'complete', count: 2 }]);
    expect((await store.shop()).published!.listingIds).toEqual(
      expect.arrayContaining([foundation.id, ...refs.map((r) => r.id)]),
    );
    const revisions = (
      await db.prepare('SELECT revision FROM published_sales ORDER BY id').all()
    ).results;
    await jobs.step(job.id, observation);
    expect(
      (
        await db
          .prepare('SELECT revision FROM published_sales ORDER BY id')
          .all()
      ).results,
    ).toEqual(revisions);
  });
});

describe('bounded bulk restore', () => {
  it('restores 500 drafts and 500 messages without one D1 query per row', async () => {
    const p = await live(),
      receipt = await inbox.intake(
        { ...input(), observedRevision: p.revision },
        p,
      ),
      backup = await exportSales(store);
    for (let i = 1; i < 500; i++)
      backup.drafts.push(
        emptySale(`sample${i}.example`, sourcePriceFingerprint(price)),
      );
    backup.messages = Array.from({ length: 500 }, (_, i) => ({
      id: crypto.randomUUID(),
      leadId: receipt.id,
      direction: 'buyer' as const,
      sequence: i + 1,
      createdAt: Date.now(),
      payload: { body: 'Sample recovery message', recipient: null },
    }));
    let prepared = 0;
    const tracked = new Proxy(db, {
      get(target, property) {
        if (property === 'prepare')
          return (sql: string) => {
            prepared++;
            return target.prepare(sql);
          };
        const value = Reflect.get(target, property);
        return typeof value === 'function' ? value.bind(target) : value;
      },
    });
    const rotated = await SalesStore.from({
      DB: tracked,
      DOMBOT_SECRET: btoa(String.fromCharCode(...new Uint8Array(32).fill(22))),
    });
    await restoreSales(rotated, backup);
    expect(prepared).toBeLessThan(50);
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sale_drafts')
        .first<{ n: number }>())!.n,
    ).toBe(500);
    expect(
      (await db
        .prepare('SELECT count(*) AS n FROM sales_messages')
        .first<{ n: number }>())!.n,
    ).toBe(500);
    expect(await readPublicSale(db, p.domain)).toBeNull();
  }, 15000);
});

describe('body-bound publication admission', () => {
  it('retains a verified seller-recipient claim after parsing the signed JSON body', async () => {
    const memory = new MemoryDocStore(),
      account = crypto.randomUUID(),
      now = Date.now();
    await memory.put('registrar-accounts', account, {
      id: account,
      registrar: 'dynadot',
      label: 'Sample',
    });
    await memory.put('registrar-credentials', account, {
      apiKey: 'sample-only',
      apiSecret: 'sample-only',
    });
    await memory.put('registrar-domains', account, {
      fetchedAt: now,
      data: {
        lastSyncedAt: now,
        lastError: null,
        domains: [
          {
            domainName: 'fixture.example',
            registrar: 'dynadot',
            accountId: account,
          },
        ],
      },
    });
    await memory.put('domain-list-prices', 'fixture.example', price);
    configureStore(memory);
    await hydrateStores();
    const draft = emptySale('fixture.example', sourcePriceFingerprint(price)),
      revision = await store.save(draft, null),
      key = 'body-proof-fixture'.repeat(3),
      workspace = crypto.randomUUID(),
      env = {
        DB: db,
        DOMBOT_AUTH: 'gateway',
        DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
        DOMBOT_GATEWAY_SECRET: key,
        DOMBOT_WORKSPACE_ID: workspace,
        DOMBOT_SALES_V1: 'true',
      } as Env;
    const auth = await buildAuthConfig(env, root),
      app = new Hono<{ Bindings: Env; Variables: { auth: AuthConfig } }>();
    app.use('*', async (c, next) => {
      c.set('auth', auth);
      await next();
    });
    app.route(
      '/sales',
      createSalesRoutes(async (_c, next) => {
        await next();
      }),
    );
    const request = new Request('https://fixture.example/sales/reviews', {
      method: 'POST',
      headers: {
        Origin: 'https://fixture.example',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ items: [{ id: draft.id, revision }] }),
    });
    request.headers.set(
      'x-dombot-gateway-proof',
      await signGatewayRequest(key, workspace, 'seller', request, {
        purpose: 'sales-owner',
        recipientVerified: true,
      }),
    );
    const result = await app.request(request, undefined, env);
    expect(result.status, await result.clone().text()).toBe(200);
  });
});

describe('imported Sales inventory', () => {
  it.each(['legacy', 'owner-site'])(
    'offers imported and %s private collection names without granting publication control',
    async (format) => {
      const memory = new MemoryDocStore(),
        names = [
          'imported.example',
          `${'a'.repeat(63)}.example`,
          'xn--fsqu00a.example',
        ];
      for (const name of names)
        await memory.put('imported-domains', name, {
          addedAt: Date.now(),
          updatedAt: Date.now(),
        });
      configureStore(memory);
      await hydrateStores();
      const collectionDomain = 'collection-pilot.fixture.example',
        publication = new PublicationStore(
          db,
          await aesGcmCipher(await deriveEncryptionKey(root)),
        );
      const collection =
        format === 'legacy'
          ? {
              ...emptyDraft(),
              listings: [
                {
                  domain: collectionDomain,
                  collection: 'PRIVATE_COLLECTION_SENTINEL',
                  description: 'PRIVATE_DESCRIPTION_SENTINEL',
                  visibility: 'private' as const,
                  askingPrice: null,
                  currency: 'USD',
                },
              ],
            }
          : {
              ...emptyOwnerSite(),
              domainPresentations: [
                {
                  id: 'sample',
                  domain: collectionDomain,
                  ownership: 'current' as const,
                  availability: 'not-for-sale' as const,
                  description: 'PRIVATE_DESCRIPTION_SENTINEL',
                  askingPrice: null,
                  currency: 'USD',
                },
              ],
            };
      await publication.save(collection, null);
      const key = 'imported-sales-fixture'.repeat(3),
        workspace = crypto.randomUUID(),
        env = {
          DB: db,
          DOMBOT_AUTH: 'gateway',
          DOMBOT_SECRET: btoa(String.fromCharCode(...root)),
          DOMBOT_GATEWAY_SECRET: key,
          DOMBOT_WORKSPACE_ID: workspace,
          DOMBOT_SALES_V1: 'true',
        } as Env;
      const auth = await buildAuthConfig(env, root),
        app = new Hono<{ Bindings: Env; Variables: { auth: AuthConfig } }>();
      app.use('*', async (c, next) => {
        c.set('auth', auth);
        await next();
      });
      app.route(
        '/sales',
        createSalesRoutes(async (_c, next) => {
          await next();
        }),
      );
      async function request(path: string, body?: unknown) {
        const r = new Request('https://fixture.example/sales/' + path, {
          method: body === undefined ? 'GET' : 'POST',
          headers: {
            Origin: 'https://fixture.example',
            ...(body === undefined
              ? {}
              : { 'Content-Type': 'application/json' }),
          },
          body: body === undefined ? undefined : JSON.stringify(body),
        });
        r.headers.set(
          'x-dombot-gateway-proof',
          await signGatewayRequest(key, workspace, 'seller', r, {
            purpose: 'sales-owner',
            recipientVerified: true,
          }),
        );
        return app.request(r, undefined, env);
      }
      const inventory = await request('inventory'),
        items = (await inventory.json()).items;
      expect(items.map((v: { domain: string }) => v.domain)).toEqual(
        expect.arrayContaining([...names, collectionDomain]),
      );
      expect(JSON.stringify(items)).not.toContain(
        'PRIVATE_DESCRIPTION_SENTINEL',
      );
      expect(JSON.stringify(items)).not.toContain(
        'PRIVATE_COLLECTION_SENTINEL',
      );
      expect(items.every((v: { available: boolean }) => !v.available)).toBe(
        true,
      );
      const created = await request('listings', {
        domains: [...names, collectionDomain],
      });
      expect(created.status, await created.clone().text()).toBe(200);
      const drafts = (await created.json()).items;
      expect(drafts).toHaveLength(4);
      const found = await request('listings?q=imported');
      expect((await found.json()).items).toHaveLength(1);
      const collectionSearch = await request('listings?q=collection-pilot');
      expect((await collectionSearch.json()).items).toHaveLength(1);
      expect((await publication.draft()).draft).toEqual(collection);
      expect(await publication.published()).toBeNull();
      const reviews = await request('reviews', {
        items: drafts.map((v: { draft: { id: string }; revision: string }) => ({
          id: v.draft.id,
          revision: v.revision,
        })),
      });
      expect(reviews.status).toBe(409);
      expect(
        (await db
          .prepare('SELECT count(*) AS n FROM published_sales')
          .first<{ n: number }>())!.n,
      ).toBe(0);
    },
  );
});

describe('all reviewed publication writers reserve before tenant commit', () => {
  it('fails without publishing and reconciles a lost reservation response under the same review', async () => {
    const draft = {
      ...emptySale('reservation.io', 'synthetic'),
      priceSource: null,
    };
    const revision = await store.save(draft, null),
      review = await store.prepare([{ id: draft.id, revision }], observation);
    const attempts: { domain: string; listing: string; revision: string }[] =
      [];
    const guarded = new SalesStore(
      db,
      store.cipher,
      store.root,
      async (claim) => {
        attempts.push(claim);
        if (attempts.length === 1) throw new Error('unknown reserve response');
      },
    );
    await expect(guarded.publish(review.id, observation)).rejects.toThrow(
      /unknown/,
    );
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    await guarded.publish(review.id, observation);
    expect(attempts[0]).toEqual(attempts[1]);
    expect((await readPublicSale(db, draft.domain))?.revision).toBe(
      attempts[1].revision,
    );
    await guarded.publish(review.id, observation);
    expect(attempts[2]).toEqual(attempts[1]);
  });
});

describe('market-only private page preparation', () => {
  it('copies exact selected terms and public identity destination without control or auto-publication, and rejects stale-tab saves', async () => {
    configureStore(new MemoryDocStore());
    await hydrateStores();
    const { Namespace } = await import('../core/storage/namespace');
    const { putMarketListings } = await import('../core/services/markets/sync');
    const { flushWrites } = await import('../core/storage/namespace');
    const { preparePrivatePage, prepareMarketPage, marketOffersFor } =
      await import('./market-page-preparation');
    const { createVerifiedSaleObserver } = await import('./sales-observation');
    const account = 'private-market-account';
    const seed = async (name: string, key: string, value: unknown) => {
      const namespace = new Namespace(name);
      await namespace.load();
      await namespace.set(key, value);
    };
    await seed('market-accounts', account, {
      id: account,
      market: 'sedo',
      label: 'Market only',
      enabled: true,
      createdAt: Date.now(),
    });
    await seed('market-credentials', account, {
      user: 'PRIVATE',
      password: 'PRIVATE',
    });
    await seed('market-last-sync', account, {
      at: Date.now(),
      lastError: null,
      listings: 1,
      sales: 0,
      incomplete: false,
      notes: [],
    });
    putMarketListings(account, [
      {
        market: 'sedo',
        accountId: account,
        name: 'marketonly.io',
        displayName: null,
        status: 'active',
        statusRaw: 'active',
        forSale: true,
        price: '1479.09',
        buyNow: true,
        minOffer: null,
        floor: 'SECRET',
        discount: null,
        currency: 'USD',
        leaseToOwn: null,
        tier: null,
        listedAt: null,
        updatedAt: null,
        publicObservedAt: Date.now(),
        extra: {
          market: 'sedo',
          categories: [],
          language: null,
          parkingEarnings: null,
          keywords: [],
        },
      },
    ]);
    await flushWrites();
    await hydrateStores();
    const prepared = await preparePrivatePage(store, 'marketonly.io', account),
      saved = prepared.item;
    expect(saved.draft.priceSource?.kind).toBe('market');
    expect(saved.published).toBeNull();
    const offers = await marketOffersFor('marketonly.io');
    expect(offers[0].price?.amount).toBe('1479.09');
    expect((await store.destination(saved.draft.destinationId))?.url).toBe(
      'https://sedo.com/search/details/?domain=marketonly.io',
    );
    await expect(
      store.prepare(
        [{ id: saved.draft.id, revision: saved.revision }],
        createVerifiedSaleObserver({ DB: db, DOMBOT_AUTH: 'external' } as Env),
      ),
    ).rejects.toThrow(/registrar|DNS/);
    await expect(
      prepareMarketPage(
        store,
        { ...saved, revision: crypto.randomUUID() },
        account,
        saved.revision,
      ),
    ).rejects.toThrow(/changed/);
    const existing = await preparePrivatePage(store, 'marketonly.io', account);
    expect(existing.existing).toBe(true);
    expect(existing.item.revision).toBe(saved.revision);
    const review = await store.prepare(
      [{ id: saved.draft.id, revision: saved.revision }],
      () => ({ ...observation(), marketOffer: offers[0] }),
    );
    expect(JSON.stringify(review.items[0].after)).not.toMatch(
      /SECRET|private-market-account|PRIVATE/,
    );
    expect(review.items[0].after.publicPrice?.amount).toBe('1479.09');
    expect(review.items[0].after.providerIntent).toBe('buy');
    const html = renderSalesLander(review.items[0].after, '', null);
    expect(html).toContain('Buy through Sedo');
    expect(html.indexOf('href="/d/marketonly.io/provider')).toBeGreaterThan(0);
  });
});

describe('source maintenance, transactions and honest measurements', () => {
  async function marketPublication(domain = 'lifecycle.io') {
    const draft = {
      ...emptySale(domain, 'none'),
      mode: 'buy-now' as const,
      allowQuestions: true,
    };
    const { publicMarketOffer } = await import('../shared/market-public-offer');
    const offer = await publicMarketOffer(
      {
        market: 'sedo',
        accountId: 'private-account',
        name: domain,
        displayName: null,
        status: 'active',
        statusRaw: 'active',
        forSale: true,
        price: '100.50',
        buyNow: true,
        minOffer: null,
        floor: 'PRIVATE',
        discount: null,
        currency: 'USD',
        leaseToOwn: null,
        tier: null,
        listedAt: null,
        updatedAt: null,
        publicObservedAt: Date.now(),
        extra: {
          market: 'sedo',
          categories: [],
          language: null,
          parkingEarnings: null,
          keywords: [],
        },
      },
      null,
    );
    const destination = {
      id: crypto.randomUUID(),
      revision: crypto.randomUUID(),
      provider: offer.provider,
      url: offer.url,
      check: 'manual' as const,
      checkedAt: null,
    };
    await store.saveDestination(destination, null);
    draft.priceSource = offer.source;
    draft.destinationId = destination.id;
    const revision = await store.save(draft, null),
      observe = () => ({ ...observation(), marketOffer: offer });
    const review = await store.prepare([{ id: draft.id, revision }], observe);
    await store.publish(review.id, observe);
    return { draft, offer, observe };
  }
  it('retains the approved source across later private edits, removes drifted prices, and never reopens on recovery alone', async () => {
    const { draft, offer, observe } = await marketPublication();
    let saved = await store.get(draft.id);
    await store.save(
      {
        ...saved.draft,
        priceSource: {
          kind: 'override',
          price: { amount: '999', currency: 'USD' },
          reason: 'Private pending edit',
        },
      },
      saved.revision,
    );
    await store.reconcile(
      (approved) => {
        expect(approved.priceSource?.kind).toBe('market');
        return {
          ...observation(),
          marketOffer: {
            ...offer,
            source: { ...offer.source, fingerprint: 'f'.repeat(64) },
          },
        };
      },
      [draft.domain],
    );
    saved = await store.get(draft.id);
    expect(saved.availability).toBe('source-stale');
    const live = await readPublicSale(db, draft.domain);
    expect(live?.publicPrice).toBeNull();
    expect(live?.providerIntent).toBe('view');
    expect(saved.published?.publicPrice?.amount).toBe('100.50');
    await store.reconcile(observe, [draft.domain]);
    expect((await store.get(draft.id)).availability).toBe('source-stale');
    await store.reconcile(
      () => ({
        ...observation(),
        marketOffer: {
          ...offer,
          eligible: false,
          reason: 'This marketplace listing is not active and public.',
        },
      }),
      [draft.domain],
    );
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    await store.reconcile(observe, [draft.domain]);
    expect(await readPublicSale(db, draft.domain)).toBeNull();
  });
  it('does not enable an unapproved inquiry when stale offer-only terms have no provider destination', async () => {
    const draft = {
      ...emptySale('offer-only.io', sourcePriceFingerprint(price)),
      mode: 'offer' as const,
      allowQuestions: false,
    };
    const revision = await store.save(draft, null),
      review = await store.prepare([{ id: draft.id, revision }], observation);
    await store.publish(review.id, observation);
    await store.reconcile(
      () => ({ ...observation(), price: { ...price, amount: '14800.01' } }),
      [draft.domain],
    );
    expect((await store.get(draft.id)).availability).toBe('source-stale');
    expect(await readPublicSale(db, draft.domain)).toBeNull();
  });
  it('bounds discounts/price leases at read time and suppresses pending/completed sales across public readers', async () => {
    const { draft, offer, observe } = await marketPublication('expiry.io');
    const saved = await store.get(draft.id);
    await db
      .prepare('UPDATE published_sales SET payload=? WHERE id=?')
      .bind(
        JSON.stringify({
          ...saved.published,
          sourceValidUntil: Date.now() - 1,
        }),
        draft.id,
      )
      .run();
    expect((await readPublicSale(db, draft.domain))?.publicPrice).toBeNull();
    await store.reconcile(
      () => ({ ...observe(), transactionState: 'pending' }),
      [draft.domain],
    );
    expect((await store.get(draft.id)).availability).toBe('sale-pending');
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    await store.reconcile(
      () => ({ ...observation(), marketOffer: offer }),
      [draft.domain],
    );
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    const pending = await store.get(draft.id);
    await store.availability(draft.id, pending.operationalRevision, 'paused');
    const review = await store.prepare(
      [{ id: draft.id, revision: pending.revision }],
      observe,
    );
    await store.publish(review.id, observe);
    await store.reconcile(
      () => ({ ...observe(), transactionState: 'completed' }),
      [draft.domain],
    );
    expect((await store.get(draft.id)).availability).toBe('sold');
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    await store.reconcile(observe, [draft.domain]);
    expect((await store.get(draft.id)).availability).toBe('sold');
  });
  it('counts provider opens separately, preserves aggregate backups, and never treats requests as completed sales', async () => {
    const { draft } = await marketPublication('counts.io');
    const route = new Hono<{ Bindings: Env }>().route(
      '/',
      createPublicSalesRoutes(),
    );
    const env = { DB: db, DOMBOT_AUTH: 'external' } as Env;
    expect((await route.request('/d/counts.io', {}, env)).status).toBe(200);
    const opened = await route.request('/d/counts.io/provider', {}, env);
    expect(opened.status).toBe(303);
    expect(opened.headers.get('location')).toBe(
      'https://sedo.com/search/details/?domain=counts.io',
    );
    const { recordJourney } = await import('./sales-journey');
    await recordJourney(db, draft.id, 'inquiry-verified', 'one-receipt');
    await recordJourney(db, draft.id, 'inquiry-verified', 'one-receipt');
    const counts = (
      await db
        .prepare(
          'SELECT event,count FROM sales_journey_daily WHERE listing_id=? ORDER BY event',
        )
        .bind(draft.id)
        .all()
    ).results;
    expect(counts).toEqual([
      { event: 'inquiry-verified', count: 1 },
      { event: 'page-rendered', count: 1 },
      { event: 'provider-opened', count: 1 },
    ]);
    const exported = await exportSales(store);
    expect(exported.version).toBe(4);
    expect(exported.journey).toHaveLength(3);
    await restoreSales(store, exported);
    expect(await readPublicSale(db, draft.domain)).toBeNull();
    expect((await exportSales(store)).journey).toEqual(exported.journey);
    const { listEvents } = await import('../core/services/domain-events');
    expect(listEvents()).toHaveLength(0);
  });
  it('compares decimal public shop boundaries exactly rather than truncating fractions', async () => {
    const { draft } = await marketPublication('range.io');
    const shop = {
      version: 1 as const,
      handle: 'exact',
      title: 'Exact range',
      intro: '',
      listingIds: [draft.id],
    };
    await store.saveShop(shop, null);
    await db
      .prepare("UPDATE sales_shop SET published=? WHERE id='main'")
      .bind(JSON.stringify(shop))
      .run();
    expect(
      (await publicShop(db, 'exact', { currency: 'USD', max: '100.49' })).items,
    ).toHaveLength(0);
    expect(
      (await publicShop(db, 'exact', { currency: 'USD', min: '100.51' })).items,
    ).toHaveLength(0);
    expect(
      (
        await publicShop(db, 'exact', {
          currency: 'USD',
          min: '100.50',
          max: '100.50',
        })
      ).items,
    ).toHaveLength(1);
    await expect(
      publicShop(db, 'exact', { currency: 'JPY', max: '100.50' }),
    ).rejects.toThrow(/decimal/);
  });
  it('keeps seller payment and transfer reports out of completed core Sales', async () => {
    const { draft } = await marketPublication('reported.io');
    const { reconcileSalesOutcomes } = await import('./sales-reconciliation');
    for (const state of [
      'payment-reported',
      'transfer-reported',
      'completed',
    ] as const)
      await db
        .prepare(
          "INSERT INTO sales_events(id,listing_id,kind,created_at,sealed) VALUES(?,?,'outcome',?,?)",
        )
        .bind(
          crypto.randomUUID(),
          draft.id,
          Date.now(),
          await store.seal({
            state,
            source: 'seller-entered',
            evidence: 'Seller report only',
            price: null,
            provider: 'Sedo',
          }),
        )
        .run();
    await reconcileSalesOutcomes(store);
    const { listEvents } = await import('../core/services/domain-events');
    expect(listEvents()).toHaveLength(0);
  });
  it('requires an explicit exact match and deduplicates a completed provider transaction without overwriting seller facts', async () => {
    const { newEvent, putEvents, listEvents } =
      await import('../core/services/domain-events');
    const { DomainEventType, DomainEventSource } =
      await import('../shared/domain-events');
    const { Namespace, flushWrites } =
      await import('../core/storage/namespace');
    const event = newEvent({
      domain: 'matched.io',
      type: DomainEventType.Sold,
      source: DomainEventSource.User,
      date: '2026-11-01',
      amount: '100.50',
      currency: 'USD',
      fees: '1.01',
    });
    putEvents([event]);
    await flushWrites();
    const sales = new Namespace('market-sales');
    await sales.load();
    await sales.set('account:transaction', {
      market: 'sedo',
      accountId: 'account',
      id: 'transaction',
      name: 'matched.io',
      soldOn: '2026-11-01',
      status: 'completed',
      statusRaw: 'completed',
      kind: 'buy_now',
      price: '100.50',
      commission: '1.01',
      commissionEstimated: false,
      net: '99.49',
      currency: 'USD',
      installments: null,
      paidOutOn: '2026-11-02',
      action: null,
    });
    await flushWrites();
    await hydrateStores();
    const { matchSaleEvidence, resolveSaleEvidence } =
      await import('./sales-outcome-evidence');
    const reference = {
      kind: 'match' as const,
      market: 'sedo' as const,
      accountId: 'account',
      transactionId: 'transaction',
      eventId: event.id,
    };
    expect(() => resolveSaleEvidence('other.io', reference)).toThrow(
      /this domain/,
    );
    expect(() =>
      resolveSaleEvidence('matched.io', reference, {
        amount: '100.51',
        currency: 'USD',
      }),
    ).toThrow(/differs/);
    matchSaleEvidence('matched.io', reference);
    matchSaleEvidence('matched.io', reference);
    expect(listEvents()).toHaveLength(1);
    expect(listEvents()[0]).toMatchObject({
      amount: '100.50',
      currency: 'USD',
      fees: '1.01',
      source: 'user',
      marketSale: 'account:transaction',
    });
  });
});
