// Shared, provider-agnostic types for the registrar client.

import type { RegistrarFeature } from './features';

// client-level request options
export interface RegistrarClientOptions {
  // request timeout in milliseconds
  timeout: number;
  // number of retry attempts for retryable errors
  retries: number;
  // base delay for exponential backoff, in milliseconds
  backoff: number;
  // optional AbortSignal to cancel in-flight requests
  signal?: AbortSignal;
  // fetch implementation used for every request, e.g. one that routes through a
  // proxy. Defaults to the global `fetch`. A transport that fails before the
  // request leaves (proxy refused, tunnel not established) should throw an
  // error marked with `markNotSent` so the failure is retried for any call.
  fetch?: typeof globalThis.fetch;
}

// whether a call only reads registrar state or may change it. Decides what is
// safe to re-send after a failure; see `FEATURE_CALLS` in features.ts.
export type RequestIntent = 'read' | 'write';

// per-call bookkeeping the library threads through `RequestOptions` from a
// feature method down to the HTTP layer. Set by `BaseRegistrar`; callers never
// need to supply it.
export interface FeatureCall {
  intent: RequestIntent;
  // the feature method being served, e.g. "renewDomain"
  feature?: string;
  // set by the HTTP layer when a write's outcome could not be determined, so
  // it survives providers that fold errors into an `OperationResult`
  outcomeUnknown?: Error;
}

// per-request options that can override client-level options
export interface RequestOptions extends Partial<RegistrarClientOptions> {
  // library-internal; see `FeatureCall`
  call?: FeatureCall;
}

// options for `setPrivacy`. Extends `RequestOptions` like `ListDomainsOptions`.
export interface SetPrivacyOptions extends RequestOptions {
  // acknowledgement for registrars that treat publishing contact details in
  // WHOIS as a consented action (GoDaddy, when turning privacy off). `agreedBy`
  // is the consenting user's IP address.
  consent?: RegistrationConsent;
}

// options for `listDomains`. Extends `RequestOptions` so timeout/retries/signal
// still flow through a single argument. `listDomains` always returns the full
// account, paginating internally at each provider's maximum page size.
export interface ListDomainsOptions extends RequestOptions {
  // case-insensitive substring to match against the domain name. Applied
  // server-side where the API supports it (Namecheap `SearchTerm`, Gandi
  // `fqdn`) and client-side otherwise.
  search?: string;
  // Fetch full per-domain detail after listing. Several providers' list
  // endpoints return only a summary and omit fields like `nameservers`,
  // `privacy`, or the transfer `locked` flag, which then read as their defaults
  // (`[]` / `false`). With `detailed: true`, the client follows up with a
  // `getDomain` call per domain (bounded concurrency) and merges the detail,
  // so those fields are accurate. Costs one extra request per domain, so it is
  // opt-in — leave it off for a fast summary listing. Honored by the
  // `RegistrarClient` facade (and `listPortfolio` over facade sources).
  detailed?: boolean;
}

// which API environment a provider targets. "sandbox" covers registrar test
// environments (GoDaddy calls theirs "OTE") so integration tests never touch
// real domains. Requesting "sandbox" on a provider without one throws.
export type RegistrarEnvironment = 'production' | 'sandbox';

// options passed when constructing a registrar provider
export interface RegistrarOptions extends Partial<RegistrarClientOptions> {
  environment?: RegistrarEnvironment;
}

// result of a connection/credential test
export interface ConnectionResult {
  success: boolean;
  message: string;
  // On a failure caught from a `RegistrarError`: its `status` (401 for
  // credentials the registrar rejects, 429 for a rate limit, …), so callers
  // can branch without reading the message. Absent on success, and when the
  // failure has no status (a logical error in a 200 reply, a plain Error).
  status?: number;
}

// result of a mutating operation (renew, nameserver update, lock/unlock)
export interface OperationResult {
  success: boolean;
  message: string;
  // Accepted by the registrar but still pending registry processing. Callers
  // must not optimistically display the requested state as already active.
  pending?: boolean;
  // Present only on a failed write whose request may have reached the
  // registrar (timed out, connection dropped mid-response, or a 5xx). The
  // change may or may not have been applied: re-read the domain before trying
  // again. The library never re-sends such a request itself.
  outcome?: 'unknown';
  // On a failure caught from a `RegistrarError`: its `status`, as on
  // `ConnectionResult` (504 with `outcome: 'unknown'`).
  status?: number;
}

// a configuration field a registrar needs (used to build credential UIs generically)
export interface ConfigField {
  // property name on the credentials object
  name: string;
  // human-readable label
  label: string;
  // input type
  type: 'text' | 'password' | 'select';
  // whether the field is required
  required: boolean;
  // allowed values for `select` fields
  options?: string[];
  // default value
  default?: string;
}

// normalized, cross-registrar view of a domain
export interface Domain {
  domainName: string;
  // id of the registrar that owns this record, e.g. "cloudflare"
  registrar: string;
  // registry/registrar status, always lowercased
  status: string;
  createdDate: Date | null;
  expirationDate: Date | null;
  renewalDate: Date | null;
  autoRenew: boolean;
  locked: boolean;
  privacy: boolean;
  nameservers: string[];
  // when this record was fetched
  syncedAt: Date;
  // whether the domain has been removed at the registrar
  deleted: boolean;
}

// loose input accepted by `createDomain`; providers pass raw-ish API values
export interface DomainInput {
  domainName?: string;
  registrar?: string;
  status?: string;
  createdDate?: Date | string | number | null;
  expirationDate?: Date | string | number | null;
  renewalDate?: Date | string | number | null;
  autoRenew?: boolean;
  locked?: boolean;
  privacy?: boolean;
  // accepts string[], objects with a `hosts` array, or objects with ServerName
  nameservers?: unknown;
  syncedAt?: Date;
  deleted?: boolean;
}

// A normalized registrant/admin/tech/billing contact, mapped to and from each
// registrar's own contact shape.
export interface Contact {
  firstName: string;
  lastName: string;
  organization?: string;
  email: string;
  // international phone format, e.g. "+1.4805551234"
  phone: string;
  fax?: string;
  address1: string;
  address2?: string;
  city: string;
  // state / province / region; may be empty where the country has none
  state?: string;
  postalCode: string;
  // ISO 3166-1 alpha-2 country code, e.g. "US"
  country: string;
}

// The set of contacts on a domain. `registrant` is the legal owner; most
// registrars also track admin, tech, and billing roles (often the same person).
export interface ContactSet {
  registrant?: Contact;
  admin?: Contact;
  tech?: Contact;
  billing?: Contact;
}

// A single DNS record in provider-agnostic form.
export interface DnsRecord {
  // record type, uppercased: "A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV", "CAA", …
  type: string;
  // host/subdomain relative to the zone apex; "@" denotes the apex
  name: string;
  // record data / value (target host, IP address, text, etc.)
  value: string;
  // time-to-live in seconds
  ttl?: number;
  // priority, for MX and SRV records
  priority?: number;
  // SRV-only fields
  weight?: number;
  port?: number;
}

// Result of an availability check for a single domain.
export interface DomainAvailability {
  domainName: string;
  available: boolean;
  // whether the name is a premium/aftermarket registration
  premium?: boolean;
  // registration price in major currency units (e.g. 11.99), when the API reports it
  price?: number;
  // annual renewal price in major currency units, when the API reports one for
  // this specific name (e.g. a premium name's renewal)
  renewalPrice?: number;
  // ISO 4217 currency code, e.g. "USD"
  currency?: string;
  // the registration period the price covers, in years
  period?: number;
}

// Pricing for a TLD (or a specific domain), in major currency units. Fields are
// optional because not every registrar exposes all three price points.
export interface TldPricing {
  // the TLD the prices apply to, without a leading dot, e.g. "com"
  tld: string;
  // ISO 4217 currency code, e.g. "USD"
  currency: string;
  registration?: number;
  renewal?: number;
  transfer?: number;
}

// Consent to a registrar's registration agreements, supplied per registration.
// Registering a domain forms a legal contract with the registry, so providers
// that require it reject `registerDomain` without this. The provider fetches the
// specific per-TLD agreement documents itself; the caller only affirms who is
// consenting (and optionally when).
export interface RegistrationConsent {
  // identifier of the consenting party. Registrars that record an "agreed by"
  // value expect the consenting user's IP address here (e.g. GoDaddy).
  agreedBy: string;
  // ISO 8601 timestamp of when consent was given; defaults to the current time.
  agreedAt?: string;
}

// Input for transferring a domain in. `authCode` (the EPP/auth code from the
// losing registrar) is always required; the rest mirror registration and are
// used by the registrars that need them (GoDaddy/Spaceship want contacts +
// consent, Namecheap/Dynadot rely on account defaults and just need the code).
export interface TransferDomainInput {
  // the EPP / authorization code obtained from the current registrar
  authCode: string;
  // registration length to add as part of the transfer, in years
  years?: number;
  // contacts for the transferred domain, where the registrar requires them
  contacts?: ContactSet;
  // consent to the registrar's transfer agreements, where required (e.g. GoDaddy)
  consent?: RegistrationConsent;
  // enable WHOIS privacy on transfer, where supported
  privacy?: boolean;
  // enable auto-renew on transfer
  autoRenew?: boolean;
}

// Input for registering a new domain.
export interface RegisterDomainInput {
  // registration length in years (defaults to 1)
  years?: number;
  // contacts for the registration; every registrar requires at least a registrant
  contacts: ContactSet;
  // initial nameservers; omitting them uses the registrar's defaults
  nameservers?: string[];
  // enable WHOIS privacy at registration, where supported
  privacy?: boolean;
  // enable auto-renew at registration
  autoRenew?: boolean;
  // consent to the registrar's registration agreements; required by providers
  // that gate registration behind an explicit legal agreement (e.g. GoDaddy).
  // Omitting it where required throws `ConsentRequiredError`.
  consent?: RegistrationConsent;
}

// credentials for a registrar, as a flat string map keyed by `ConfigField.name`
export type RegistrarCredentials = Record<string, string>;

// --- extended-feature payloads ---

// An alias-style email forward: mail sent to `alias`@domain is redirected to
// `forwardTo`. This is redirect-only forwarding — no real mailbox is provisioned.
export interface EmailForward {
  // the local part of the source address at the domain, e.g. "hello" for
  // hello@example.com. Where the registrar supports it, "@" or "*" denotes a
  // catch-all.
  alias: string;
  // the destination address mail is forwarded to
  forwardTo: string;
}

// The redirect style for a DomainForward:
//   - "temporary" temporary (302) redirect; the destination URL shows in the bar
//   - "permanent" permanent (301) redirect; the destination URL shows in the bar
//   - "masked"    masked/framed/"cloaked" redirect: an iframe keeps the source
//                 URL in the address bar. READ-ONLY — `getDomainForwarding` reports
//                 it for forwards a provider already has, but `setDomainForwarding`
//                 rejects it. Masking breaks HTTPS, SEO, and modern browser
//                 protections, and several registrars (e.g. Cloudflare) can't do
//                 it at all, so the library never creates one.
export type DomainForwardType = 'temporary' | 'permanent' | 'masked';

// Whether the forward's SOURCE host answers on HTTPS (the provider holds a
// certificate for it); the destination's scheme is part of `url`.
//   off  — HTTP only.
//   on   — HTTP and HTTPS.
//   only — HTTPS, with HTTP requests redirected to HTTPS.
// Only some providers let you choose; see `DomainForward.https`.
export type DomainForwardHttps = 'off' | 'on' | 'only';

// A URL/domain forwarding rule: requests to `host` at the domain are redirected
// to `url`.
export interface DomainForward {
  // the source host at the domain, relative to the apex; "@" denotes the apex,
  // "www" the www subdomain, etc.
  host: string;
  // the destination URL requests are forwarded to
  url: string;
  // the redirect style
  type: DomainForwardType;
  // source-host HTTPS mode, when the provider exposes it per rule (Gandi; on
  // Cloudflare it is always 'on'). Reads leave it unset when the provider has no
  // such setting. On write, unset keeps the rule's current mode (or the
  // provider's default for a new rule); a value the provider can't apply is
  // rejected before any write.
  https?: DomainForwardHttps;
}

// A DNSSEC delegation-signer (DS) record published at the parent zone. Fields
// mirror the DS RR (RFC 4034). Registrars that expose DNSSEC only as DNSKEY data
// may not populate every field; `digest` is the hex delegation digest.
export interface DsRecord {
  // the key tag identifying the DNSKEY this DS refers to
  keyTag: number;
  // DNSSEC algorithm number (e.g. 8 = RSA/SHA-256, 13 = ECDSA P-256)
  algorithm: number;
  // digest type (1 = SHA-1, 2 = SHA-256, 4 = SHA-384)
  digestType: number;
  // the delegation digest, hex-encoded
  digest: string;
}

// DNSSEC status for a domain. `enabled` is the headline signal (is DNSSEC turned
// on at the registrar); `dsRecords` carries the published DS records when the
// registrar exposes them (may be empty even when enabled).
export interface DnssecStatus {
  enabled: boolean;
  dsRecords: DsRecord[];
}

// Where an outbound transfer stands at the losing registrar. A transfer-out
// starts when another registrar requests the domain with its auth code:
//   pending   — waiting on the owner: approve it to release the domain now, or
//               reject it. Left alone, most registrars release it after 5 days.
//   approved  — released to the gaining registrar, not yet completed
//   rejected  — refused by the owner or the registrar
//   completed — the domain has left the account
//   cancelled — withdrawn, failed or timed out on the gaining side
//   unknown   — a status label this library doesn't recognise (see `rawStatus`)
export type TransferOutStatus =
  'pending' | 'approved' | 'rejected' | 'completed' | 'cancelled' | 'unknown';

// An outbound transfer of a domain, as the losing registrar reports it.
export interface TransferOut {
  status: TransferOutStatus;
  // the registrar's own status label, verbatim
  rawStatus: string;
  // the registrar's reference for the transfer (Dynadot: the order id)
  id?: string;
  // the registrar taking the domain, when reported
  gainingRegistrar?: string;
  requestedDate: Date | null;
  // when the transfer request lapses or is released without action
  expirationDate: Date | null;
  completedDate: Date | null;
}

// The core interface every registrar implementation fulfils. `BaseRegistrar`
// (src/registrar.ts) provides the shared plumbing and `NotImplementedError`
// defaults; concrete providers under src/registrars/ extend it.
export interface Registrar {
  // a short identifier for the provider, e.g. "cloudflare"
  readonly name: string;

  // the API environment this instance targets
  readonly environment: RegistrarEnvironment;

  // the capabilities this provider supports (core contract + its extended features)
  readonly features: readonly RegistrarFeature[];

  // Whether reading a domain's nameservers needs a getNameservers call beyond
  // getDomain. True when getNameservers hits its own endpoint that can surface
  // nameservers getDomain omits; false when it just re-reads getDomain, so
  // listing enrichment skips the redundant fetch. See BaseRegistrar for the
  // default.
  readonly requiresNameserversFetch: boolean;

  // Domain fields only `listDomains` reports truthfully: `getDomain` can't read
  // them and returns the `createDomain` default (Namecheap's auto-renew).
  // Detailed listing keeps the list's value for these. Absent means none.
  readonly listOnlyFields?: readonly (keyof Domain)[];

  // whether this provider supports a given capability
  supports(feature: RegistrarFeature): boolean;

  // verify the configured credentials work
  testConnection(opts?: RequestOptions): Promise<ConnectionResult>;

  // list domains in the account (capped and optionally filtered via `opts`)
  listDomains(opts?: ListDomainsOptions): Promise<Domain[]>;

  // fetch a single domain's details
  getDomain(domainName: string, opts?: RequestOptions): Promise<Domain>;

  // check whether one or more domains are available to register
  checkAvailability(domainNames: string[], opts?: RequestOptions): Promise<DomainAvailability[]>;

  // look up pricing for a TLD (or a specific domain)
  getPricing(tldOrDomain: string, opts?: RequestOptions): Promise<TldPricing>;

  // register a new domain
  registerDomain(
    domainName: string,
    input: RegisterDomainInput,
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // renew a domain for `years` years
  renewDomain(domainName: string, years?: number, opts?: RequestOptions): Promise<OperationResult>;

  // toggle auto-renew for a domain
  setAutoRenew(
    domainName: string,
    enabled: boolean,
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // transfer a domain into the account using its auth/EPP code (+ any contacts /
  // consent the registrar requires, via `TransferDomainInput`)
  transferIn(
    domainName: string,
    input: TransferDomainInput,
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // replace the nameservers for a domain
  updateNameservers(
    domainName: string,
    nameservers: string[],
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // read the nameservers currently set on a domain
  getNameservers(domainName: string, opts?: RequestOptions): Promise<string[]>;

  // lock a domain against transfers
  lockDomain(domainName: string, opts?: RequestOptions): Promise<OperationResult>;

  // unlock a domain
  unlockDomain(domainName: string, opts?: RequestOptions): Promise<OperationResult>;

  // toggle WHOIS privacy for a domain
  setPrivacy(
    domainName: string,
    enabled: boolean,
    opts?: SetPrivacyOptions
  ): Promise<OperationResult>;

  // read the registrant/admin/tech/billing contacts for a domain
  getContacts(domainName: string, opts?: RequestOptions): Promise<ContactSet>;

  // update the contacts for a domain
  updateContacts(
    domainName: string,
    contacts: ContactSet,
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // read the DNS records for a domain
  getDnsRecords(domainName: string, opts?: RequestOptions): Promise<DnsRecord[]>;

  // replace the DNS records for a domain
  setDnsRecords(
    domainName: string,
    records: DnsRecord[],
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // --- extended capabilities ---
  //
  // Opt-in operations beyond the core contract. A provider genuinely supports one
  // only if it declares the matching Feature (see `features`/`supports`); every
  // other provider inherits BaseRegistrar's default, which rejects with
  // NotImplementedError. Callers should gate on `supports(...)` before use.

  // read the alias-style email forwarding rules for a domain
  getEmailForwarding(domainName: string, opts?: RequestOptions): Promise<EmailForward[]>;

  // replace the alias-style email forwarding rules for a domain (full replace: any
  // rule not included is removed; an empty array clears all forwarding)
  setEmailForwarding(
    domainName: string,
    forwards: EmailForward[],
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // read the URL/domain forwarding rules for a domain
  getDomainForwarding(domainName: string, opts?: RequestOptions): Promise<DomainForward[]>;

  // replace the URL/domain forwarding rules for a domain (full replace: any rule
  // not included is removed; an empty array clears all forwarding)
  setDomainForwarding(
    domainName: string,
    forwards: DomainForward[],
    opts?: RequestOptions
  ): Promise<OperationResult>;

  // retrieve the transfer authorization (EPP/auth) code used to transfer the
  // domain away to another registrar
  getAuthCode(domainName: string, opts?: RequestOptions): Promise<string>;

  // read the domain's most recent outbound transfer (one another registrar
  // requested with the auth code); null when there is none on record
  getTransferOut(domainName: string, opts?: RequestOptions): Promise<TransferOut | null>;

  // approve a pending outbound transfer, releasing the domain to the gaining
  // registrar now instead of after the registrar's waiting period
  approveTransferOut(domainName: string, opts?: RequestOptions): Promise<OperationResult>;

  // reject (deny) a pending outbound transfer; the domain stays put
  rejectTransferOut(domainName: string, opts?: RequestOptions): Promise<OperationResult>;

  // read DNSSEC status for a domain (whether it's enabled, plus any DS records)
  getDnssec(domainName: string, opts?: RequestOptions): Promise<DnssecStatus>;

  // disable/turn off DNSSEC for a domain (removes the registrar's DS records at
  // the parent). Enabling DNSSEC is intentionally not part of this interface.
  disableDnssec(domainName: string, opts?: RequestOptions): Promise<OperationResult>;

  // put the domain back on the registrar's own default nameservers (its DNS
  // hosting). Some registrars switch modes for this rather than accepting their
  // own hostnames as a custom set (Spaceship "basic", Namecheap BasicDNS).
  resetNameservers(domainName: string, opts?: RequestOptions): Promise<OperationResult>;
}

// static side of a registrar class: the constructor plus discovery metadata
// (display name, public website, the credential fields it needs, where to get
// them, and whether it offers a sandbox/test environment).
export interface RegistrarConstructor {
  new (credentials: RegistrarCredentials, options?: RegistrarOptions): Registrar;
  readonly displayName: string;
  // the provider's public website domain, e.g. "gandi.net"
  readonly website: string;
  readonly configFields: ConfigField[];
  readonly helpText: string;
  readonly supportsSandbox: boolean;
  // extended capabilities this provider opts into, beyond the core contract
  readonly extendedFeatures: readonly RegistrarFeature[];
  // the full capability set: the core contract plus `extendedFeatures`
  readonly features: readonly RegistrarFeature[];
}
