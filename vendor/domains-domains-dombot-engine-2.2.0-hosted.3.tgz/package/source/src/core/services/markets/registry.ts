import type { MarketId, MarketInfo } from '../../../shared/markets';
import { AFTERNIC_NAMESERVERS } from '../../markets/afternic';
import { ATOM_NAMESERVERS } from '../../markets/atom';
import { DYNADOT_NAMESERVERS } from '../../markets/dynadot';
import { SEDO_NAMESERVERS } from '../../markets/sedo';
import { SPACESHIP_NAMESERVERS } from '../../markets/spaceship';
import { getListPrices } from '../list-prices';
import type {
  AfternicActions,
  AtomActions,
  MarketAdapter,
  SedoActions,
} from '../../markets/types';
import {
  AFTERNIC_CAPABILITIES,
  AFTERNIC_CONFIG_FIELDS,
  createAfternicAdapter,
} from './afternic';
import {
  ATOM_CAPABILITIES,
  ATOM_CONFIG_FIELDS,
  createAtomAdapter,
} from './atom';
import {
  DYNADOT_CAPABILITIES,
  DYNADOT_CONFIG_FIELDS,
  createDynadotAdapter,
  type DynadotAsking,
} from './dynadot';
import {
  SEDO_CAPABILITIES,
  SEDO_CONFIG_FIELDS,
  createSedoAdapter,
} from './sedo';
import {
  SPACESHIP_CAPABILITIES,
  SPACESHIP_CONFIG_FIELDS,
  createSpaceshipAdapter,
} from './spaceship';

// The markets DomBot supports (docs/markets.md): what Settings shows for
// each, and how to build its adapter from an account's stored credentials.
// Adding a market is an entry here plus its adapter.

export type Credentials = Record<string, string>;

/**
 * How an account's calls go out: for a market on a registrar's API, the
 * registrar account it uses, whose key and proxy route it shares.
 */
export interface AdapterContext {
  registrarAccountId?: string;
  /** Through the registrar account's proxy, when it has one. */
  fetch?: typeof fetch;
}

/** An adapter, plus whichever market-only actions its market has. */
export type AnyMarketAdapter = MarketAdapter &
  Partial<AfternicActions> &
  Partial<AtomActions> &
  Partial<SedoActions>;

interface MarketEntry {
  info: MarketInfo;
  create(
    accountId: string,
    credentials: Credentials,
    context: AdapterContext,
  ): AnyMarketAdapter;
}

/**
 * DomBot's asking price for a name, for Dynadot: the currency to read and
 * list it in, and the minimum offer Dynadot needs with every change to a
 * listing that takes offers.
 */
function askingFor(name: string): DynadotAsking | null {
  const price = getListPrices()[name];
  return price
    ? { currency: price.currency, minOffer: price.minOffer ?? null }
    : null;
}

const MARKETS: Partial<Record<MarketId, MarketEntry>> = {
  afternic: {
    info: {
      id: 'afternic',
      name: 'Afternic',
      website: 'afternic.com',
      keysUrl: 'https://www.afternic.com/account/profile',
      helpText:
        'Create an API key under Account Profile → Security → API Keys on Afternic.',
      configFields: AFTERNIC_CONFIG_FIELDS,
      capabilities: AFTERNIC_CAPABILITIES,
      nameservers: AFTERNIC_NAMESERVERS,
    },
    create: (accountId, credentials) =>
      createAfternicAdapter(accountId, credentials),
  },
  // Checked live, reads and writes (docs/atom-api.md).
  atom: {
    info: {
      id: 'atom',
      name: 'Atom',
      website: 'atom.com',
      keysUrl: 'https://www.atom.com/dashboard/seller/api-access',
      helpText: 'Request API access under Dashboard → API Access on atom.com.',
      configFields: ATOM_CONFIG_FIELDS,
      capabilities: ATOM_CAPABILITIES,
      nameservers: ATOM_NAMESERVERS,
    },
    create: (accountId, credentials) =>
      createAtomAdapter(accountId, credentials),
  },
  // Checked live, reads and writes (docs/dynadot-marketplace-api.md).
  dynadot: {
    info: {
      id: 'dynadot',
      name: 'Dynadot',
      website: 'dynadot.com',
      keysUrl: 'https://www.dynadot.com/help/question/open-marketplace',
      helpText:
        'Sells the names in your Dynadot account, and names you hold at other registrars once Dynadot has verified them. Uses the registrar account’s API key and proxy.',
      configFields: DYNADOT_CONFIG_FIELDS,
      capabilities: DYNADOT_CAPABILITIES,
      nameservers: DYNADOT_NAMESERVERS,
      registrar: 'dynadot',
    },
    create: (accountId, credentials, context) =>
      createDynadotAdapter(accountId, credentials, {
        fetch: context.fetch,
        limiterKey: context.registrarAccountId ?? accountId,
        askingFor,
      }),
  },
  // Checked live, reads and writes (docs/sedo-api.md).
  sedo: {
    info: {
      id: 'sedo',
      name: 'Sedo',
      website: 'sedo.com',
      keysUrl: 'https://sedo.com/',
      helpText:
        'Sedo grants API access (a partner ID and sign key) on request: ask Sedo support. Sedo’s API has no sales, so record Sedo sales by hand or import Sedo’s CSV export.',
      configFields: SEDO_CONFIG_FIELDS,
      capabilities: SEDO_CAPABILITIES,
      nameservers: SEDO_NAMESERVERS,
    },
    create: (accountId, credentials) =>
      createSedoAdapter(accountId, credentials),
  },
  // Reads checked live (docs/sellerhub-api.md).
  spaceship: {
    info: {
      id: 'spaceship',
      name: 'Spaceship',
      website: 'spaceship.com',
      keysUrl: 'https://www.spaceship.com/application/api-manager/',
      helpText:
        'Sells your names on Spaceship SellerHub. Uses the registrar account’s API key and proxy; the key needs SellerHub access (sellerhub:read, and sellerhub:write to list) in Spaceship’s API Manager.',
      configFields: SPACESHIP_CONFIG_FIELDS,
      capabilities: SPACESHIP_CAPABILITIES,
      nameservers: SPACESHIP_NAMESERVERS,
      registrar: 'spaceship',
    },
    create: (accountId, credentials, context) =>
      createSpaceshipAdapter(accountId, credentials, {
        fetch: context.fetch,
        limiterKey: context.registrarAccountId ?? accountId,
      }),
  },
};

/** Every supported market, for Settings. */
export function marketCatalog(): MarketInfo[] {
  return Object.values(MARKETS)
    .map((m) => m.info)
    .sort((a, b) => a.name.localeCompare(b.name));
}

export function isMarketId(value: unknown): value is MarketId {
  return typeof value === 'string' && Object.hasOwn(MARKETS, value);
}

export function marketInfo(market: MarketId): MarketInfo {
  const entry = MARKETS[market];
  if (!entry) throw new Error(`Domains.Domains doesn't support ${market} yet.`);
  return entry.info;
}

/** Builds adapters in place of the real ones (the demo's in-memory markets). */
export type MarketFactory = (
  market: MarketId,
  accountId: string,
  credentials: Credentials,
) => AnyMarketAdapter;

let factory: MarketFactory | null = null;

/** Swap in a market factory, or null to put the real adapters back. */
export function configureMarketFactory(next: MarketFactory | null): void {
  factory = next;
}

/** The adapter for one account; throws when a required field is missing. */
export function buildAdapter(
  market: MarketId,
  accountId: string,
  credentials: Credentials,
  context: AdapterContext = {},
): AnyMarketAdapter {
  const entry = MARKETS[market];
  if (!entry) throw new Error(`Domains.Domains doesn't support ${market} yet.`);
  for (const field of entry.info.configFields) {
    if (field.required && !credentials[field.name]?.trim()) {
      throw new Error(`${field.label} is required.`);
    }
  }
  return factory
    ? factory(market, accountId, credentials)
    : entry.create(accountId, credentials, context);
}
