import {
  withParkioProjection,
  parkioProjection,
} from '../services/parkio-projection';
import { z } from 'zod';
import type { DombotApi, DomainTarget } from '../../shared/ipc';
import { clearAll, clearRegistrarCaches } from '../services/cache';
import { applyDomainOp, getTransferOut } from '../services/domain-ops';
import { missingFeatureReason } from '../../shared/domain-ops';
import {
  advanceMarketBulk,
  cancelBulk,
  cancelMarketBulk,
  getBulkJob,
  startBulk,
  startMarketBulk,
  stepBulk,
} from '../services/bulk-jobs';
import {
  assignFolder,
  createFolder,
  deleteFolder,
  getFolders,
  updateFolder,
} from '../services/folders';
import { getManualPrices, setManualPrice } from '../services/pricing';
import {
  getPurchases,
  setNotes,
  setPurchase,
  markSold,
  setSale,
} from '../services/purchases';
import {
  deleteDomains,
  deleteUserEvent,
  setAlertsDismissed,
  setDeparturesDropped,
  setSaleTransferred,
} from '../services/domain-history';
import { listEvents } from '../services/domain-events';
import { getReleaseFeed } from '../services/releases';
import {
  getExchangeRateRows,
  refreshExchangeRates,
} from '../services/exchange-rates';
import { getListPrices, setListPrices } from '../services/list-prices';
import {
  heldNames,
  importDomains,
  planImport,
} from '../services/domain-import';
import {
  getImportedDomains,
  updateImportedDomain,
} from '../services/imported-domains';
import { lookupRegistrations } from '../services/registration-lookup';
import {
  getRenewalPricingStatus,
  stepRenewalPricing,
  getRegistrarCatalog,
  connectRegistrarAccount,
  removeRegistrarAccount,
  resolveDomainAccount,
  getCachedDetail,
  getCachedPortfolio,
  getConfiguredRegistrars,
  getDomainDetail,
  getPortfolio,
  getPortfolioPricing,
  getRegistrationQuote,
  getRegistrarClient,
  getRegistrarCredentialValues,
  getDomainFeatures,
  getRegistrarMetadata,
  testRegistrarAccount,
  saveRegistrarCredentials,
  setRegistrarEnabledCached,
  syncRegistrar,
} from '../services/registrars';
import {
  getProxySettings,
  removeProxyProfile,
  saveProxyProfile,
  testProxy,
} from '../services/proxies';
import { getSettings, updateSettings } from '../services/settings';
import { restartAutoSync } from '../services/auto-sync';
import { getRevisions, trackRevisions } from '../revision';
import { getAppIdentity } from '../app-info';
import { exportBundle, importBundle } from '../storage/bundle';
import { flushWrites } from '../storage/namespace';
import {
  listMcpClients,
  listPendingApprovals,
  resolvePending,
  revokeMcpClient,
} from '../mcp/oauth';
import * as s from './schemas';
import { createAccount, renameAccount } from '../services/accounts';
import {
  deleteMarketListings,
  pushAskingPrices,
  relistMarketListings,
  requestMarketVerification,
  sendSaleMessage,
  setMarketListingDefaults,
  setSaleAuthCode,
  writeMarketListings,
} from '../services/markets/writes';
import type {
  MarketBulkTarget,
  MarketListingChange,
} from '../../shared/markets';
import {
  activeMarketAccounts,
  connectMarketAccount,
  getMarketCredentials,
  marketAdapter,
  marketAccountViews,
  removeMarketAccount,
  renameMarketAccount,
  setMarketVerification,
  saveMarketCredentials,
  setMarketAccountEnabled,
} from '../services/markets/accounts';
import { marketCatalog } from '../services/markets/registry';
import { marketTraffic } from '../services/markets/traffic';
import {
  marketAccountStats,
  marketListings,
  marketSales,
  refreshMarketListings,
  syncMarketAccount,
  syncMarkets,
} from '../services/markets/sync';
import { broadcastPortfolioChanged } from '../events';

// The API method table: one entry per request/response method of `DombotApi`,
// each with a zod schema for its arguments and the handler. Hosts generate
// their transport from it — Electron loops it into `ipcMain.handle`, the web
// host into an HTTP route — so the contract, its validation, and its behavior
// live in exactly one place. Event subscriptions (`onX`) aren't methods; each
// host wires those itself.
//
// `coreMethods` covers everything host-agnostic. A host supplies the rest
// (`getAppInfo`, `saveTextFile`, the MCP server status…) as its own table and
// merges the two; `ApiTable` makes the compiler check the union is complete.

/** The request/response methods of DombotApi (everything but `onX`). */
export type ApiMethodName = {
  [K in keyof DombotApi]: DombotApi[K] extends (
    ...args: never[]
  ) => Promise<unknown>
    ? K
    : never;
}[keyof DombotApi];

type Args<K extends ApiMethodName> = Parameters<DombotApi[K]>;
type Result<K extends ApiMethodName> = Awaited<ReturnType<DombotApi[K]>>;

export interface ApiMethod<K extends ApiMethodName = ApiMethodName> {
  /** Tuple schema for the argument list. Trailing optional args may be omitted. */
  args: z.ZodTuple<[z.ZodTypeAny, ...z.ZodTypeAny[]]> | z.ZodTuple<[]>;
  handler: (...args: Args<K>) => Promise<Result<K>> | Result<K>;
}

export type ApiTable = { [K in ApiMethodName]: ApiMethod<K> };

/** Typed constructor: pins `handler`'s signature to the DombotApi method. */
export function method<K extends ApiMethodName>(
  args: ApiMethod<K>['args'],
  handler: ApiMethod<K>['handler'],
): ApiMethod<K> {
  return { args, handler };
}

/** Bad arguments to an API method. `issues` carries zod's detail; the message
 *  is short enough to show a user. */
export class ApiValidationError extends Error {
  constructor(
    readonly method: string,
    readonly issues: z.ZodIssue[],
  ) {
    const detail = issues
      .slice(0, 3)
      .map((i) => `${i.path.join('.') || 'args'}: ${i.message}`)
      .join('; ');
    super(`Invalid arguments to ${method} (${detail})`);
    this.name = 'ApiValidationError';
  }
}

/**
 * Validates `rawArgs` against a method's schema and runs it. Omitted trailing
 * arguments are padded with `undefined` so optional parameters behave like
 * they do in a direct call. Throws ApiValidationError on bad input.
 */
export async function invoke<K extends ApiMethodName>(
  name: K,
  entry: ApiMethod<K>,
  rawArgs: unknown[],
): Promise<Result<K>> {
  const arity = entry.args.def.items.length;
  const padded =
    rawArgs.length < arity
      ? [...rawArgs, ...new Array<undefined>(arity - rawArgs.length)]
      : rawArgs;
  // JSON preserves omitted middle arguments as null; restore only optional
  // slots whose schema rejects null, keeping meaningful/required nulls intact.
  const restored = padded.map((value, index) => {
    const schema = entry.args.def.items[index];
    return value === null &&
      schema?.isOptional() &&
      !schema.safeParse(null).success
      ? undefined
      : value;
  });
  const parsed = entry.args.safeParse(restored);
  if (!parsed.success) throw new ApiValidationError(name, parsed.error.issues);
  return entry.handler(...(parsed.data as Args<K>));
}

/** Throws a plain message when the account lacks an extended read feature. */
function requireFeature(target: DomainTarget, feature: string, what: string) {
  if (!getDomainFeatures(target).includes(feature)) {
    throw new Error(missingFeatureReason(target.registrar, feature, what));
  }
}

const none = z.tuple([]);
// Shape only; the service validates scheme, host and address ranges.
const proxyInput = z.object({
  url: z.string().max(2048),
  egressIp: z.string().max(64),
});

export type CoreMethodName = Exclude<
  ApiMethodName,
  | 'ping'
  | 'getAppInfo'
  | 'openExternal'
  | 'saveTextFile'
  | 'getMcpInfo'
  | 'getUpdaterState'
  | 'downloadUpdate'
  | 'installUpdate'
  | 'showLogFile'
>;

export const coreMethods: { [K in CoreMethodName]: ApiMethod<K> } = {
  // ── Cache ─────────────────────────────────────────────────────────────────
  // Launch hydration reads only the store — no registrar calls — so the UI can
  // paint the full portfolio the moment it opens, then refresh on demand.
  hydrateFromCache: method(none, async () => {
    // The portfolio/detail/pricing caches were all fetched under registrar
    // credentials. If none are configured now — a fresh install, or every
    // credential removed — that cached data is orphaned: it would paint stale
    // domain counts over a UI that otherwise (correctly) reports no
    // registrars. Drop it and hydrate nothing.
    if (getConfiguredRegistrars().length === 0) {
      clearRegistrarCaches();
      // Imported names aren't registrar data: their pricing stays.
      return {
        portfolio: parkioProjection().length
          ? withParkioProjection({
              domains: [],
              fetchedAt: null,
              registrars: [],
              registrarLabels: {},
              errors: [],
            })
          : null,
        detail: {},
        pricing: getPortfolioPricing(),
      };
    }
    return {
      portfolio: getCachedPortfolio()
        ? withParkioProjection(getCachedPortfolio()!)
        : parkioProjection().length
          ? withParkioProjection({
              domains: [],
              fetchedAt: null,
              registrars: [],
              registrarLabels: {},
              errors: [],
            })
          : null,
      detail: getCachedDetail(),
      pricing: getPortfolioPricing(),
    };
  }),
  clearAllCaches: method(none, async () => {
    clearAll();
  }),

  // ── Updates ───────────────────────────────────────────────────────────────
  getReleaseFeed: method(z.tuple([z.boolean()]), async (force) =>
    getReleaseFeed(force),
  ),

  // ── Data bundle (backup / move / secret rotation) ──────────────────────────
  // Plain text both ways; the client seals/opens with the passphrase
  // (src/shared/bundle-seal.ts) so the key stretching stays off the Worker.
  exportData: method(none, async () => exportBundle(getAppIdentity())),
  importData: method(z.tuple([z.string()]), async (text) => {
    const result = await importBundle(text);
    // Durable before we say so: the caller reloads on the strength of it.
    await flushWrites();
    return result;
  }),

  // ── Pricing ───────────────────────────────────────────────────────────────
  getPortfolioPricing: method(none, async () => getPortfolioPricing()),
  getExchangeRates: method(none, async () => getExchangeRateRows()),
  getManualPrices: method(none, async () => getManualPrices()),
  setManualPrice: method(
    z.tuple([s.domainName, s.renewalPriceInput.nullable()]),
    async (domain, price) => {
      setManualPrice(domain, price);
    },
  ),

  // ── Registrars ────────────────────────────────────────────────────────────
  listPortfolio: method(
    z.tuple([z.boolean().optional()]),
    async (refresh = true) => {
      if (!refresh) return getPortfolio(false);
      // Rates beside the sync, so they never hold it up.
      const [portfolio] = await Promise.all([
        getPortfolio(true),
        refreshExchangeRates(),
      ]);
      return portfolio;
    },
  ),
  syncRegistrar: method(
    z.tuple([s.registrarName, s.accountId]),
    async (name, accountId) => syncRegistrar(name, accountId),
  ),
  getDomainDetail: method(
    z.tuple([
      s.registrarName,
      s.domainName,
      z.boolean().optional(),
      s.accountId,
      z.boolean().optional(),
    ]),
    async (name, domainName, refresh = false, accountId, cacheOnly = false) =>
      getDomainDetail(name, domainName, refresh, accountId, cacheOnly),
  ),
  getRegistrarCatalog: method(none, getRegistrarCatalog),
  // Resolves, not rejects, when the registrar turns the credentials down, so
  // its HTTP status reaches the renderer (`ConnectRegistrarResult`).
  connectRegistrarAccount: method(
    z.tuple([
      s.registrarName,
      s.credentialValues,
      z.string().trim().max(100).optional(),
      z.boolean().optional(),
    ]),
    connectRegistrarAccount,
  ),
  createRegistrarAccount: method(
    z.tuple([s.registrarName, z.string().trim().min(1).max(100)]),
    createAccount,
  ),
  renameRegistrarAccount: method(
    // A blank nickname removes it; the account goes back to its number.
    z.tuple([z.string(), z.string().trim().max(100)]),
    renameAccount,
  ),
  removeRegistrarAccount: method(z.tuple([z.string()]), removeRegistrarAccount),
  testRegistrarAccount: method(
    z.tuple([s.registrarName, s.accountId, z.boolean().optional()]),
    testRegistrarAccount,
  ),
  getRegistrarMetadata: method(none, async () => getRegistrarMetadata()),
  getRegistrarCredentials: method(
    z.tuple([s.registrarName, s.accountId]),
    async (name, accountId) => getRegistrarCredentialValues(name, accountId),
  ),
  saveRegistrarCredentials: method(
    z.tuple([
      s.registrarName,
      s.credentialValues,
      s.accountId,
      z.boolean().optional(),
    ]),
    async (name, creds, accountId, useProxy) => {
      await saveRegistrarCredentials(name, creds, accountId, useProxy);
    },
  ),
  getProxySettings: method(
    z.tuple([z.boolean().optional()]),
    async (connectionOnly) => getProxySettings(connectionOnly),
  ),
  saveProxySettings: method(z.tuple([proxyInput]), async (proxy) => {
    await saveProxyProfile(proxy);
  }),
  removeProxySettings: method(none, async () => removeProxyProfile()),
  testProxySettings: method(z.tuple([proxyInput]), testProxy),
  setRegistrarEnabled: method(
    z.tuple([s.registrarName, z.boolean(), s.accountId]),
    async (name, enabled, accountId) =>
      setRegistrarEnabledCached(name, enabled, accountId),
  ),

  // ── Domain operations ─────────────────────────────────────────────────────
  // One method for every per-domain write the table can make. Never rejects
  // for a registrar-side outcome — `DomainOpResult.status` carries it.
  applyDomainOp: method(
    z.tuple([s.domainTarget, s.domainOp]),
    async (target, op) => applyDomainOp(target, op),
  ),
  // Forwarding reads back the per-row dialogs. Live — not part of the cache.
  getUrlForwarding: method(z.tuple([s.domainTarget]), async (target) => {
    requireFeature(target, 'getDomainForwarding', 'URL forwarding');
    return getRegistrarClient(
      target.registrar,
      resolveDomainAccount(
        target.registrar,
        target.domainName,
        target.accountId,
      ).id,
    ).getDomainForwarding(target.domainName);
  }),
  getEmailForwarding: method(z.tuple([s.domainTarget]), async (target) => {
    requireFeature(target, 'getEmailForwarding', 'email forwarding');
    return getRegistrarClient(
      target.registrar,
      resolveDomainAccount(
        target.registrar,
        target.domainName,
        target.accountId,
      ).id,
    ).getEmailForwarding(target.domainName);
  }),
  // The pending sale's transfer-out, behind its Approve transfer. Live too.
  getTransferOut: method(z.tuple([s.domainTarget]), async (target) =>
    getTransferOut(target),
  ),

  // ── Bulk jobs ─────────────────────────────────────────────────────────────
  startBulk: method(
    z.tuple([z.array(s.domainTarget).min(1), s.domainOp]),
    async (targets, op) => startBulk(targets, op),
  ),
  cancelBulk: method(z.tuple([z.string()]), async (jobId) => {
    cancelBulk(jobId);
  }),
  getBulkJob: method(none, async () => getBulkJob()),
  stepBulk: method(z.tuple([z.string()]), async (jobId) => stepBulk(jobId)),

  // ── Folders ───────────────────────────────────────────────────────────────
  getFolders: method(none, async () => getFolders()),
  createFolder: method(z.tuple([s.folderInput]), async (input) =>
    createFolder(input),
  ),
  updateFolder: method(
    z.tuple([z.string(), s.folderPatch]),
    async (id, patch) => {
      updateFolder(id, patch);
    },
  ),
  deleteFolder: method(z.tuple([z.string()]), async (id) => {
    deleteFolder(id);
  }),
  assignFolder: method(
    z.tuple([s.domainName, z.string().nullable()]),
    async (domainName, folderId) => {
      assignFolder(domainName, folderId);
    },
  ),

  // ── Settings ──────────────────────────────────────────────────────────────
  getSettings: method(none, async () => getSettings()),
  updateSettings: method(z.tuple([s.appSettingsPatch]), async (patch) => {
    const next = updateSettings(patch);
    // Apply live: the auto-sync interval may have changed (or been disabled).
    // No-op on a host that never started the timer.
    restartAutoSync();
    return next;
  }),

  // ── Purchase records ──────────────────────────────────────────────────────
  getPurchases: method(none, async () => getPurchases()),
  setPurchase: method(z.tuple([s.purchaseInput]), async (input) =>
    setPurchase(input),
  ),
  setSale: method(z.tuple([s.saleInput]), async (input) => setSale(input)),
  setNotes: method(
    z.tuple([s.domainName, s.noteText]),
    async (domainName, notes) => setNotes(domainName, notes),
  ),

  // ── Domain import ─────────────────────────────────────────────────────────
  previewDomainImport: method(z.tuple([s.importRows]), async (rows) =>
    planImport(rows),
  ),
  importDomains: method(
    z.tuple([s.importRows, s.importApply]),
    async (rows, options) => importDomains(rows, options),
  ),

  // ── Imported domains ────────────────────────────────────────────────────────
  getImportedDomains: method(none, async () => getImportedDomains()),
  updateImportedDomain: method(
    z.tuple([s.domainName, s.importedDomainFields]),
    async (domainName, fields) => {
      updateImportedDomain(domainName, fields);
      return getImportedDomains();
    },
  ),

  // ── Asking prices ─────────────────────────────────────────────────────────
  getListPrices: method(none, async () => getListPrices()),
  // ── Markets (docs/markets.md) ──────────────────────────────────────────────
  getMarketCatalog: method(none, async () => marketCatalog()),
  listMarketAccounts: method(none, async () => marketAccountViews()),
  connectMarketAccount: method(
    z.tuple([
      s.marketId,
      s.marketCredentials,
      s.marketLabel.optional(),
      s.accountId,
    ]),
    async (market, credentials, label, registrarAccountId) => {
      const account = await connectMarketAccount(
        market,
        credentials,
        label,
        undefined,
        registrarAccountId,
      );
      await syncMarketAccount(account.id);
      return marketAccountViews();
    },
  ),
  renameMarketAccount: method(
    z.tuple([s.marketAccountId, s.marketLabel]),
    async (id, label) => {
      await renameMarketAccount(id, label);
      return marketAccountViews();
    },
  ),
  setMarketVerification: method(
    z.tuple([s.marketAccountId, s.verificationValue]),
    async (id, pasted) => {
      await setMarketVerification(id, pasted);
      return marketAccountViews();
    },
  ),
  setMarketAccountEnabled: method(
    z.tuple([s.marketAccountId, z.boolean()]),
    async (id, enabled) => {
      await setMarketAccountEnabled(id, enabled);
      if (enabled) await syncMarketAccount(id);
      else broadcastPortfolioChanged();
      return marketAccountViews();
    },
  ),
  getMarketCredentials: method(z.tuple([s.marketAccountId]), async (id) =>
    getMarketCredentials(id),
  ),
  saveMarketCredentials: method(
    z.tuple([s.marketAccountId, s.marketCredentials]),
    async (id, credentials) => {
      await saveMarketCredentials(id, credentials);
      await syncMarketAccount(id);
      return marketAccountViews();
    },
  ),
  removeMarketAccount: method(z.tuple([s.marketAccountId]), async (id) => {
    await removeMarketAccount(id);
    broadcastPortfolioChanged();
    return marketAccountViews();
  }),
  syncMarketAccount: method(
    z.tuple([s.marketAccountId.optional()]),
    async (id) => {
      if (id) await syncMarketAccount(id);
      else await syncMarkets();
      return marketAccountViews();
    },
  ),
  getMarketListings: method(none, async () => marketListings()),
  getMarketSales: method(none, async () => marketSales()),
  getMarketTraffic: method(none, async () => {
    const accounts = activeMarketAccounts();
    return marketTraffic(
      new Map(accounts.map((a) => [a.id, a.market])),
      accounts.flatMap((a) => marketAccountStats(a.id)),
    );
  }),
  writeMarketListings: method(
    z.tuple([s.marketAccountId, s.marketListingChanges]),
    async (id, changes) =>
      writeMarketListings(id, changes as MarketListingChange[]),
  ),
  pushMarketPrices: method(
    z.tuple([s.marketAccountId, s.marketNames]),
    async (id, names) => pushAskingPrices(id, names),
  ),
  deleteMarketListings: method(
    z.tuple([s.marketAccountId, s.marketNames]),
    async (id, names) => deleteMarketListings(id, names),
  ),
  startMarketBulk: method(
    z.tuple([s.marketBulkTargets, s.marketBulkOp]),
    async (targets, op) => startMarketBulk(targets as MarketBulkTarget[], op),
  ),
  // The web host's Worker can't drive a job between requests, so each poll
  // runs it a little (a few names on Atom); the desktop drives it itself.
  advanceMarketBulk: method(none, async () => advanceMarketBulk(10_000)),
  cancelMarketBulk: method(z.tuple([z.string()]), async (jobId) => {
    cancelMarketBulk(jobId);
  }),
  relistMarketListings: method(
    z.tuple([s.marketAccountId, s.marketNames, s.relistMode.optional()]),
    async (id, names, mode) => relistMarketListings(id, names, mode),
  ),
  refreshMarketListings: method(z.tuple([s.marketNames]), async (names) =>
    refreshMarketListings(names),
  ),
  requestMarketVerification: method(
    z.tuple([s.marketAccountId, s.marketNames]),
    async (id, names) => requestMarketVerification(id, names),
  ),
  setMarketSaleAuthCode: method(
    z.tuple([
      s.marketAccountId,
      z.string().min(1).max(100),
      z.string().max(200).optional(),
    ]),
    async (id, saleId, authCode) => setSaleAuthCode(id, saleId, authCode),
  ),
  sendMarketSaleMessage: method(
    z.tuple([
      s.marketAccountId,
      z.string().min(1).max(100),
      z.string().min(1).max(1000),
    ]),
    async (id, saleId, message) => sendSaleMessage(id, saleId, message),
  ),
  getMarketListingDefaults: method(z.tuple([s.marketAccountId]), async (id) => {
    const adapter = marketAdapter(id);
    if (!adapter.getListingDefaults) {
      throw new Error(
        `Listing defaults are not supported for ${adapter.market}.`,
      );
    }
    return { ...(await adapter.getListingDefaults()) };
  }),
  setMarketListingDefaults: method(
    z.tuple([s.marketAccountId, s.marketListingDefaults]),
    async (id, settings) => setMarketListingDefaults(id, settings),
  ),

  setListPrices: method(z.tuple([s.listPriceInputs]), async (inputs) => {
    setListPrices(inputs);
    return getListPrices();
  }),

  lookupRegistrations: method(z.tuple([s.domainNameList]), async (names) =>
    lookupRegistrations(names),
  ),
  getRegistrationQuote: method(
    z.tuple([s.registrarName, s.domainName, s.accountId]),
    async (registrar, domainName, accountId) =>
      getRegistrationQuote(registrar, domainName, accountId),
  ),

  // ── Domain history (events) ───────────────────────────────────────────────
  // Every change returns the whole log, so the caller refreshes in one call.
  getDomainEvents: method(none, async () => listEvents()),
  markSold: method(
    z.tuple([s.ownershipItems, s.optionalDay]),
    async (items, date) => {
      markSold(items, date);
      return listEvents();
    },
  ),
  setAlertsDismissed: method(
    z.tuple([z.array(s.eventId).min(1).max(5000), z.boolean()]),
    async (ids, dismissed) => {
      setAlertsDismissed(ids, dismissed);
      return listEvents();
    },
  ),
  setDeparturesDropped: method(
    z.tuple([z.array(s.eventId).min(1).max(5000), z.boolean()]),
    async (ids, dropped) => {
      setDeparturesDropped(ids, dropped);
      return listEvents();
    },
  ),
  setSaleTransferred: method(
    z.tuple([s.eventId, z.boolean()]),
    async (id, transferred) => {
      setSaleTransferred(id, transferred);
      return listEvents();
    },
  ),
  deleteUserEvent: method(z.tuple([s.eventId]), async (id) => {
    deleteUserEvent(id);
    return listEvents();
  }),
  deleteDomains: method(
    z.tuple([s.domainNameList.min(1)]),
    async (domainNames) => {
      deleteDomains(domainNames, new Set(heldNames().keys()));
      return listEvents();
    },
  ),

  // ── Events (polling) ──────────────────────────────────────────────────────
  getRevisions: method(none, async () => ({
    ...getRevisions(),
    ...(getRenewalPricingStatus().remaining > 0
      ? { renewalPricingPending: true }
      : {}),
  })),
  stepRenewalPricing: method(none, async () => stepRenewalPricing()),

  // ── MCP pairing ───────────────────────────────────────────────────────────
  // The OAuth state is in the store, so the approval UI works on both hosts;
  // only the server's status (`getMcpInfo`) is host-specific.
  listPendingApprovals: method(none, async () => listPendingApprovals()),
  resolveApproval: method(
    z.tuple([z.string(), z.boolean()]),
    async (id, approve) => {
      resolvePending(id, approve);
    },
  ),
  listMcpClients: method(none, async () => listMcpClients()),
  revokeMcpClient: method(z.tuple([z.string()]), async (clientId) => {
    await revokeMcpClient(clientId);
  }),
};

trackRevisions();
