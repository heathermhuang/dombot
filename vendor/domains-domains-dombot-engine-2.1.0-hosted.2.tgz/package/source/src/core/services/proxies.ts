import {
  DEFAULT_PROXY_ID,
  PROXIES_NAMESPACE,
  isPublicIpv4,
  parseProxy,
  parseProxyUrl,
  type ProxyProfile,
  type ProxyRoute,
} from '../../shared/proxy';
import { parseNamecheapProxy } from '../../shared/namecheap-proxy';
import type {
  ProxySettings,
  ProxyTestResult,
  RegistrarAccount,
} from '../../shared/ipc';
import { proxySecrets } from '../../shared/proxy';
import { proxyRequestTimeout, sendThroughProxy } from './proxy-transport';
import { redactSecrets } from '@aoxborrow/registrar-client';

import { Namespace } from '../storage/namespace';
import { isSavedAccount, listAccounts, setAccountProxy } from './accounts';
import { getStoredCredentials, setStoredCredentials } from './credentials';
import { managedProxyFor, managedProxyInfo } from './managed-proxy';

// The fixed IP proxy, configured once and switched on per account. Stored like
// credentials (the URL carries a password): sealed at rest, included in data
// exports, kept out of diagnostics. The store holds a list so a second egress
// IP never needs a migration, but the app manages exactly one: `default`.

const store = new Namespace<ProxyProfile>(PROXIES_NAMESPACE);

export function getProxyProfile(id = DEFAULT_PROXY_ID): ProxyProfile | null {
  return store.get(id) ?? null;
}

export function listProxyProfiles(): ProxyProfile[] {
  return Object.values(store.all());
}

/** Each proxy URL and the username and password inside it, for scrubbing
 *  diagnostics (see stored-secrets.ts). Empty until storage is hydrated. */
export function proxySecretValues(): string[] {
  if (!store.loaded) return [];
  return listProxyProfiles().flatMap((profile) => proxySecrets(profile.url));
}

/** The route for an account, or null for a direct connection. An account that
 * points at a missing profile fails loudly: it must never quietly go direct
 * from an address the registrar hasn't whitelisted. */
export function accountProxyRoute(
  account: RegistrarAccount,
): ProxyRoute | null {
  if (!account.proxyId) return managedProxyFor(account.registrar);
  const profile = getProxyProfile(account.proxyId);
  if (!profile)
    throw new Error(
      'This account uses the fixed IP proxy, but no proxy is configured. Add one in Settings → Proxy.',
    );
  return { url: profile.url, ip: profile.egressIp };
}

/** Saved accounts routed through a profile. */
export function proxyUsers(id = DEFAULT_PROXY_ID): RegistrarAccount[] {
  return listAccounts().filter((a) => a.proxyId === id && isSavedAccount(a.id));
}

/** Validates and stores the proxy. Registrar clients notice the change through
 * their fingerprint and rebuild on next use. */
export async function saveProxyProfile(
  input: { url: string; egressIp: string },
  id = DEFAULT_PROXY_ID,
): Promise<ProxyProfile> {
  const route = parseProxy(input);
  if (!route)
    throw new Error('Enter both the proxy URL and its outgoing IPv4 address.');
  const profile: ProxyProfile = {
    id,
    label: getProxyProfile(id)?.label ?? 'Fixed IP proxy',
    url: route.url,
    egressIp: route.ip,
  };
  await store.set(id, profile);
  return profile;
}

/** Removes the proxy, first switching it off for any account that used it.
 * Accounts return to their host-managed route when available, otherwise direct. */
export async function removeProxyProfile(id = DEFAULT_PROXY_ID): Promise<void> {
  for (const user of proxyUsers(id)) await setAccountProxy(user.id, null);
  await store.delete(id);
}

/**
 * Lifts the proxy a Namecheap account used to keep in its own credentials
 * (`proxyUrl` / `proxyIp`) into a profile, points the account at it, and
 * removes the fields. Idempotent: it only acts on credentials that still carry
 * them, so it is safe after every hydrate and every import.
 *
 * The first proxy found becomes `default`. An account with a different proxy
 * gets its own profile and keeps working; the UI just can't edit that one.
 */
export async function migrateLegacyProxies(): Promise<number> {
  let migrated = 0;
  for (const account of listAccounts()) {
    const { proxyUrl, proxyIp, ...rest } = getStoredCredentials(account.id);
    if (proxyUrl === undefined && proxyIp === undefined) continue;
    let route: ProxyRoute | null = null;
    try {
      route = parseNamecheapProxy({ proxyUrl, proxyIp });
    } catch {
      // A malformed legacy proxy already left the account unusable; drop it.
      console.warn(
        `[proxy] dropped an invalid stored proxy from account ${account.id}`,
      );
    }
    if (route) {
      const match = listProxyProfiles().find(
        (p) => p.url === route.url && p.egressIp === route.ip,
      );
      const id =
        match?.id ??
        (getProxyProfile() ? crypto.randomUUID() : DEFAULT_PROXY_ID);
      if (!match) {
        await store.set(id, {
          id,
          label:
            id === DEFAULT_PROXY_ID
              ? 'Fixed IP proxy'
              : `${account.label} proxy`,
          url: route.url,
          egressIp: route.ip,
        });
        if (id !== DEFAULT_PROXY_ID)
          console.warn(
            `[proxy] account ${account.id} used a second proxy; kept as profile ${id}`,
          );
      }
      await setAccountProxy(account.id, id);
      // A proxy-only account had the proxy's address written in as its Client
      // IP. That was never a direct IP, so don't keep it as one.
      if (rest.clientIp === route.ip) delete rest.clientIp;
    }
    await setStoredCredentials(account.id, rest);
    migrated++;
  }
  return migrated;
}

/** What the Proxy settings page shows: the one managed proxy and who uses it. */
export function getProxySettings(connectionOnly = false): ProxySettings {
  const profile = getProxyProfile();
  return {
    managed: managedProxyInfo(),
    proxy: profile
      ? { url: connectionOnly ? '' : profile.url, egressIp: profile.egressIp }
      : null,
    users: proxyUsers().map((a) => ({
      accountId: a.id,
      registrar: a.registrar,
      label: a.label,
      hasSiblings: listAccounts().some(
        (b) =>
          b.registrar === a.registrar && b.id !== a.id && isSavedAccount(b.id),
      ),
    })),
  };
}

// Plain-text services that echo the caller's address. Cloudflare first; a
// second provider so one outage doesn't read as a broken proxy.
const IP_PROBES: { url: string; read: (body: string) => string | undefined }[] =
  [
    {
      url: 'https://www.cloudflare.com/cdn-cgi/trace',
      read: (body) => /^ip=(.+)$/m.exec(body)?.[1],
    },
    {
      url: 'https://ipinfo.io/json',
      read: (body) => (JSON.parse(body) as { ip?: string }).ip,
    },
  ];
const PROBE_TIMEOUT_MS = 15_000;

/**
 * Makes one request through the proxy and reports the address the internet saw,
 * so a wrong outgoing IP shows up here rather than as a registrar rejection.
 * Tests the values given, saved or not.
 */
export async function testProxy(input: {
  url: string;
  egressIp: string;
}): Promise<ProxyTestResult> {
  // A test needs only the URL: the outgoing address is what it discovers. When
  // an address is supplied, validate it too and report whether the two match.
  const url = parseProxyUrl(input.url);
  const expected =
    typeof input.egressIp === 'string' ? input.egressIp.trim() : '';
  if (expected && !isPublicIpv4(expected))
    throw new Error('The outgoing IP must be a public IPv4 address.');
  const route: ProxyRoute = { url, ip: expected };
  const timeout = proxyRequestTimeout(route, PROBE_TIMEOUT_MS);
  let failure = 'no response';
  for (const probe of IP_PROBES) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await sendThroughProxy(route, probe.url, {
        method: 'GET',
        headers: { Accept: '*/*', 'Accept-Encoding': 'identity' },
        redirect: 'manual',
        signal: controller.signal,
      });
      if (!response.ok)
        throw new Error(
          `${new URL(probe.url).hostname} answered ${response.status}`,
        );
      const ip = probe.read(await response.text())?.trim();
      if (!ip) throw new Error('the address check returned no address');
      // With no address to check against, the connection alone is the pass.
      return { ip, expected, matches: expected ? ip === expected : true };
    } catch (error) {
      failure = controller.signal.aborted
        ? `timed out after ${timeout / 1000}s`
        : error instanceof Error
          ? error.message
          : String(error);
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error(
    `Could not connect through the proxy: ${redactSecrets(failure, proxySecrets(route.url))}`,
  );
}
