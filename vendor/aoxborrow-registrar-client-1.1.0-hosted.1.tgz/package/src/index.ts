// Public API surface.

export { RegistrarClient } from './client';
export { listPortfolio } from './portfolio';
export type { DomainSource, PortfolioError, PortfolioResult } from './portfolio';
export { HttpClient, REST_SAFE_METHODS } from './http';
export type { HttpClientConfig, RequestConfig } from './http';

// core registrar abstraction (the `Registrar` interface itself is exported via
// `export * from './types'` below)
export { BaseRegistrar, selectBaseUrl } from './registrar';

// built-in providers lookup + factory
export { registrars, createRegistrar } from './registrars/index';
export type { RegistrarName } from './registrars/index';

// capability model: feature constants, the core contract, and helpers
export {
  Feature,
  CORE_FEATURES,
  EXTENDED_FEATURES,
  ALL_FEATURES,
  FEATURE_CALLS,
  isCoreFeature,
} from './features';
export type { RegistrarFeature } from './features';

// DNS record syntax and canonical form
export * from './dns-records';

// bundled providers
export { CloudflareRegistrar } from './registrars/cloudflare';
export { Domain101Registrar } from './registrars/domain101';
export { DynadotRegistrar } from './registrars/dynadot';
export { GandiRegistrar } from './registrars/gandi';
export { GoDaddyRegistrar } from './registrars/godaddy';
export { NameBrightRegistrar } from './registrars/namebright';
export { NamecheapRegistrar } from './registrars/namecheap';
export { NamecomRegistrar } from './registrars/namecom';
export { NameSiloRegistrar } from './registrars/namesilo';
export { PorkbunRegistrar } from './registrars/porkbun';
export { SpaceshipRegistrar } from './registrars/spaceship';
export { UnstoppableRegistrar } from './registrars/unstoppable';

// XML parsing helpers for XML-based registrar APIs
export { parseXml, ensureArray } from './xml';

// credential redaction for messages, as applied to everything a provider throws or returns
export { redactSecrets } from './redact';
export type { SecretValues } from './redact';

// shared types, constants, utils, and errors
export * from './types';
export * from './constants';
export * from './utils';
export * from './errors';
