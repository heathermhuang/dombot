import { beforeEach, describe, expect, it } from 'vitest';
import { MemoryDocStore } from '../storage/doc-store';
import {
  configureStore,
  flushWrites,
  hydrateStores,
} from '../storage/namespace';
import { ownershipByDomain } from '../../shared/ownership';
import { listAccounts, trackedAccountIds } from './accounts';
import { listEvents, nameNote } from './domain-events';
import {
  deleteDomains,
  deleteUserEvent,
  recordRenewals,
  recordSync,
  setAlertsDismissed,
  setDeparturesDropped,
} from './domain-history';
import { assignFolder, createFolder, getFolders } from './folders';
import { clearAll } from './cache';
import { getPurchases, markSold, setPurchase, setSale } from './purchases';

let store: MemoryDocStore;
beforeEach(async () => {
  await flushWrites().catch(() => {});
  store = new MemoryDocStore();
  configureStore(store);
  await hydrateStores();
});

const acct = () => listAccounts()[0].id;
const holding = (names: string[], known = true) => [
  { accountId: acct(), names, synced: true, known },
];

describe('domain history', () => {
  it('starts tracking on the first sync, then records what changes', async () => {
    expect(recordSync(holding(['a.com']))).toEqual([]);
    expect(trackedAccountIds().has(acct())).toBe(true);
    const events = recordSync(holding(['b.com']));
    expect(events.map((e) => [e.type, e.domain])).toEqual([
      ['removed', 'a.com'],
      ['added', 'b.com'],
    ]);
    await flushWrites();
    expect(Object.keys(await store.list('domain-events'))).toHaveLength(2);
  });

  it('still sees a change made while the cache was cleared', async () => {
    recordSync(holding(['a.com', 'b.com']));
    clearAll();
    const events = recordSync(holding(['b.com']));
    expect(events.map((e) => [e.type, e.domain])).toEqual([
      ['removed', 'a.com'],
    ]);
    await flushWrites();
    expect(await store.get('registrar-last-sync', acct())).toMatchObject({
      names: ['b.com'],
    });
  });

  it('a sale replaces your earlier sale and keeps answering the alert', () => {
    recordSync(holding(['a.com']));
    const [left] = recordSync(holding([]));
    markSold([{ domainName: 'a.com', resolves: left.id }]);
    setSale({
      domainName: 'a.com',
      saleDate: '2026-09-01',
      amount: '900',
      currency: 'USD',
      notes: '',
      mark: true,
    });
    const answers = () => listEvents().filter((e) => e.source === 'user');
    expect(answers().map((e) => [e.type, e.amount, e.resolves])).toEqual([
      ['sold', '900.00', left.id],
    ]);
    // Marking it Sold again changes nothing.
    markSold([{ domainName: 'a.com' }]);
    expect(answers()).toHaveLength(1);
  });

  it('marks a name Sold with no details, dated today, closing its alert', () => {
    recordSync(holding(['a.com']));
    const [left] = recordSync(holding([]));
    setSale({
      domainName: 'a.com',
      saleDate: null,
      amount: null,
      currency: null,
      notes: '',
      mark: true,
      resolves: left.id,
    });
    const sold = listEvents().find((e) => e.type === 'sold')!;
    expect(sold).toMatchObject({ resolves: left.id, source: 'user' });
    expect(sold.date).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    // Undoing the sale brings the alert back.
    deleteUserEvent(sold.id);
    expect(ownershipByDomain(listEvents()).get('a.com')).toMatchObject({
      sale: null,
      removal: left,
    });
  });

  it('records a second sale when a sold name comes back and is sold again', () => {
    const sell = (mark: boolean) =>
      setSale({
        domainName: 'a.com',
        saleDate: mark ? null : '2022-01-01',
        amount: mark ? null : '50',
        currency: mark ? null : 'USD',
        notes: '',
        ...(mark ? { mark } : {}),
      });
    recordSync(holding(['a.com']));
    sell(false);
    recordSync(holding([]));
    recordSync(holding(['a.com']));
    expect(ownershipByDomain(listEvents()).get('a.com')?.sale).toBeNull();
    sell(true);
    const sales = listEvents().filter((e) => e.type === 'sold');
    expect(sales.map((e) => e.amount)).toEqual(['50.00', null]);
  });

  it('records an arrival as a new purchase instead of editing the old one', () => {
    setPurchase({
      domainName: 'a.com',
      purchaseDate: '2020-01-01',
      amount: '10',
      currency: 'USD',
      notes: '',
    });
    setSale({
      domainName: 'a.com',
      saleDate: '2022-01-01',
      amount: '50',
      currency: 'USD',
      notes: '',
    });
    recordSync(holding([]));
    const [arrived] = recordSync(holding(['a.com']));
    setPurchase({
      domainName: 'a.com',
      purchaseDate: '2025-01-01',
      amount: '80',
      currency: 'USD',
      notes: '',
      resolves: arrived.id,
    });
    const purchases = listEvents().filter((e) => e.type === 'purchased');
    expect(purchases.map((e) => e.amount)).toEqual(['10.00', '80.00']);
    expect(getPurchases()['a.com']).toMatchObject({
      amount: '80.00',
      saleAmount: null,
    });
  });

  it("answering an old arrival leaves a later holding's purchase alone", () => {
    recordSync(holding([]));
    const [first] = recordSync(holding(['a.com']));
    recordSync(holding([]));
    const [again] = recordSync(holding(['a.com']));
    setPurchase({
      domainName: 'a.com',
      purchaseDate: '2025-01-01',
      amount: '80',
      currency: 'USD',
      notes: '',
      resolves: again.id,
    });
    // The first arrival's holding ended when the name left: a new record.
    setPurchase({
      domainName: 'a.com',
      kind: 'registered',
      purchaseDate: '2020-01-01',
      amount: '9',
      currency: 'USD',
      notes: '',
      resolves: first.id,
    });
    const paid = listEvents().filter(
      (e) => e.type === 'purchased' || e.type === 'registered',
    );
    expect(paid.map((e) => [e.type, e.amount, e.resolves])).toEqual([
      ['purchased', '80.00', again.id],
      ['registered', '9.00', first.id],
    ]);
  });

  it('dismisses an alert and brings it back', () => {
    recordSync(holding([]));
    const [added] = recordSync(holding(['a.com']));
    setAlertsDismissed([added.id], true);
    expect(listEvents()[0].dismissed).toBe(true);
    setAlertsDismissed([added.id], false);
    expect(listEvents()[0].dismissed).toBe(false);
  });

  it('marks a departure dropped and back, leaving dismissed alone', () => {
    recordSync(holding(['a.com', 'b.com']));
    const [removed] = recordSync(holding(['b.com']));
    const [added] = recordSync(holding(['a.com', 'b.com', 'c.com']));
    setDeparturesDropped([removed.id, added.id], true);
    const byId = (id: string) => listEvents().find((e) => e.id === id)!;
    expect(byId(removed.id)).toMatchObject({ dropped: true });
    expect(byId(removed.id).dismissed).toBeUndefined();
    // Only departures are dropped.
    expect(byId(added.id).dropped).toBeUndefined();
    setDeparturesDropped([removed.id], false);
    expect(byId(removed.id).dropped).toBe(false);
    expect(() => setDeparturesDropped([added.id], true)).toThrow();
  });

  it('Delete forgets everything about a name', async () => {
    setPurchase({
      domainName: 'a.com',
      purchaseDate: '2020-01-01',
      amount: '10',
      currency: 'USD',
      notes: 'mine',
    });
    assignFolder(
      'a.com',
      createFolder({ name: 'Keep', description: '', color: 'gray' }).id,
    );
    expect(deleteDomains(['A.com'], new Set())).toBe(1);
    expect(listEvents()).toEqual([]);
    expect(nameNote('a.com')).toBeUndefined();
    expect(getFolders().assignments['a.com']).toBeUndefined();
    await flushWrites();
    expect(await store.list('domain-notes')).toEqual({});
  });

  it('Delete skips names an account holds', () => {
    markSold([{ domainName: 'a.com' }, { domainName: 'b.com' }]);
    expect(deleteDomains(['a.com', 'b.com'], new Set(['a.com']))).toBe(1);
    expect(listEvents().map((e) => e.domain)).toEqual(['a.com']);
    expect(() => deleteDomains(['a.com'], new Set(['a.com']))).toThrow(
      /auto-renew/,
    );
  });

  it('marks many names Sold with no price, dated today by default', () => {
    markSold([{ domainName: 'a.com' }, { domainName: 'b.com' }]);
    const sold = listEvents().filter((e) => e.type === 'sold');
    expect(sold).toHaveLength(2);
    expect(
      sold.every((e) => !e.amount && /^\d{4}-\d{2}-\d{2}$/.test(e.date!)),
    ).toBe(true);
    expect(getPurchases()['a.com']).toMatchObject({ saleAmount: null });
  });

  describe('renewals', () => {
    const at = (expirations: Record<string, string>) => [
      {
        accountId: acct(),
        names: Object.keys(expirations),
        synced: true,
        known: true,
        expirations,
      },
    ];

    it('fills in expiries on the first sync after upgrading, recording nothing', async () => {
      recordSync(holding(['a.com']));
      await flushWrites();
      expect(
        (await store.get('registrar-last-sync', acct())) as object,
      ).toMatchObject({ expirations: {} });
      // A record from an older build: no expirations.
      await store.put('registrar-last-sync', acct(), {
        names: ['a.com'],
        syncedAt: 1,
      });
      await hydrateStores();
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toEqual([]);
      await flushWrites();
      expect(await store.get('registrar-last-sync', acct())).toMatchObject({
        expirations: { 'a.com': '2027-10-01' },
      });
      // Now a renewal is seen.
      const events = recordSync(at({ 'a.com': '2028-10-01' }));
      expect(events.map((e) => [e.type, e.domain, e.years])).toEqual([
        ['renewed', 'a.com', 1],
      ]);
    });

    it('records a DomBot renewal once, and the next sync adds nothing', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      const [event] = recordRenewals([
        {
          domainName: 'a.com',
          accountId: acct(),
          years: 1,
          charge: { amount: '10.99', currency: 'USD' },
        },
      ]);
      expect(event).toMatchObject({
        type: 'renewed',
        source: 'user',
        accountId: acct(),
        years: 1,
        amount: '10.99',
        currency: 'USD',
      });
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toEqual([]);
      expect(listEvents().filter((e) => e.type === 'renewed')).toHaveLength(1);
    });

    it('a DomBot renewal without the new expiry is still counted once', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      const [event] = recordRenewals([
        { domainName: 'a.com', accountId: acct(), years: 1 },
      ]);
      expect(event.amount).toBeUndefined();
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toEqual([]);
      expect(listEvents().filter((e) => e.type === 'renewed')).toHaveLength(1);
    });

    it('counts a DomBot renewal once when the registrar shows it late', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      recordRenewals([{ domainName: 'a.com', accountId: acct(), years: 1 }]);
      // Syncs that still see the old expiry keep waiting for it.
      expect(recordSync(at({ 'a.com': '2026-10-01' }))).toEqual([]);
      expect(recordSync(at({ 'a.com': '2026-10-01' }))).toEqual([]);
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toEqual([]);
      expect(listEvents().filter((e) => e.type === 'renewed')).toHaveLength(1);
      // Landed: next year's auto-renewal is a new one.
      expect(
        recordSync(at({ 'a.com': '2028-10-01' })).map((e) => e.type),
      ).toEqual(['renewed']);
    });

    it('adds up two DomBot renewals one jump shows', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      recordRenewals([{ domainName: 'a.com', accountId: acct(), years: 1 }]);
      recordRenewals([{ domainName: 'a.com', accountId: acct(), years: 1 }]);
      expect(recordSync(at({ 'a.com': '2028-10-01' }))).toEqual([]);
      // One more year than DomBot renewed: an auto-renewal on top.
      recordRenewals([{ domainName: 'a.com', accountId: acct(), years: 1 }]);
      expect(
        recordSync(at({ 'a.com': '2030-10-01' })).map((e) => e.years),
      ).toEqual([1]);
    });

    it('records each yearly auto-renewal sync sees', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toHaveLength(1);
      expect(recordSync(at({ 'a.com': '2028-10-01' }))).toHaveLength(1);
      expect(listEvents().filter((e) => e.type === 'renewed')).toHaveLength(2);
    });

    it('deletes a sync renewal whose expiry moves back', () => {
      recordSync(at({ 'a.com': '2026-10-01' }));
      expect(recordSync(at({ 'a.com': '2027-10-01' }))).toHaveLength(1);
      recordSync(at({ 'a.com': '2026-10-01' }));
      expect(listEvents().filter((e) => e.type === 'renewed')).toEqual([]);
    });
  });
});
