import { registrars, type RegistrarName } from '@aoxborrow/registrar-client';
import { createAccount } from '../services/accounts';
import { setStoredCredentials } from '../services/credentials';
import { assignFolder, createFolder, getFolders } from '../services/folders';
import { setManualPrice } from '../services/pricing';
import {
  configureRegistrarFactory,
  resetRegistrarClients,
} from '../services/registrars';
import { flushWrites } from '../storage/namespace';
import { setListPrices } from '../services/list-prices';
import {
  connectMarketAccount,
  marketAccountViews,
} from '../services/markets/accounts';
import { configureMarketFactory } from '../services/markets/registry';
import {
  DEMO_MARKET_ACCOUNTS,
  DemoMarketWorld,
  demoMarketFactory,
  seedDemoMarkets,
} from './markets';
import { DemoRegistrar, DemoWorld } from './registrar';
import {
  DEFAULT_DEMO_SEED,
  DEFAULT_DEMO_SIZE,
  generateDemoSeed,
  type DemoSeed,
} from './seed';

export { DemoRegistrar, DemoWorld, type DemoDomainRecord } from './registrar';
export {
  generateDemoSeed,
  DEFAULT_DEMO_SEED,
  DEFAULT_DEMO_SIZE,
  type DemoAccount,
  type DemoFolder,
  type DemoSeed,
} from './seed';

// Wires the demo into a core that's already been given a store (a
// MemoryDocStore, typically) and hydrated. After this, every registrar call
// the app makes lands in the in-memory world, the configured accounts carry
// fake credentials so they show as connected, and the folders and manual
// prices are in place. The host then runs a sync to fill the portfolio cache
// exactly as a real instance would on first launch.
//
// This is host-neutral: the demo web build, the desktop's "try with sample
// data" mode, and tests all call it.

export interface InstallDemoOptions {
  seed?: number;
  size?: number;
  /** Simulated per-call latency for the fake registrar (ms). */
  latencyMs?: number;
  /** Fixed "now" for the generated dates (tests). */
  now?: Date;
}

export interface DemoInstallation {
  seed: DemoSeed;
  world: DemoWorld;
  /** The demo's Afternic, Sedo and Atom accounts. */
  markets: DemoMarketWorld;
  /** Changes the fake registrar's per-call latency from now on. */
  setLatency(ms: number): void;
}

/** Installs the demo registrar factory and seeds the store. */
export async function installDemo(
  options: InstallDemoOptions = {},
): Promise<DemoInstallation> {
  const seed = generateDemoSeed(
    options.seed ?? DEFAULT_DEMO_SEED,
    options.size ?? DEFAULT_DEMO_SIZE,
    options.now,
  );
  const world = new DemoWorld(seed.records);
  let latencyMs = options.latencyMs ?? 0;

  configureRegistrarFactory((name: RegistrarName, _credentials, accountId) => {
    return new DemoRegistrar(name, accountId, world, {
      latencyMs: () => latencyMs,
    });
  });
  resetRegistrarClients();

  for (const account of seed.accounts) {
    // An account name needs an account record; an unnamed default account is
    // just its credentials, like an account from before multi-account support.
    if (account.label === 'Default')
      await setStoredCredentials(account.id, account.credentials);
    else
      await createAccount(
        account.registrar,
        account.label,
        account.credentials,
        undefined,
        account.id,
      );
  }

  const existing = new Map(getFolders().folders.map((f) => [f.name, f.id]));
  for (const folder of seed.folders) {
    const id =
      existing.get(folder.name) ??
      createFolder({
        name: folder.name,
        color: folder.color,
        description: folder.description,
      }).id;
    for (const domainName of folder.domains) {
      const record = world.get(domainName);
      if (record) assignFolder(domainName, id);
    }
  }

  for (const [key, price] of Object.entries(seed.manualPrices)) {
    const domainName = key.slice(key.indexOf(':') + 1);
    if (world.get(domainName))
      setManualPrice(domainName, {
        amount: price.toFixed(2),
        currency: 'USD',
      });
  }

  // Markets: an Afternic, a Sedo and an Atom account listing some of the
  // portfolio, connected the way a user would (the host syncs them).
  const markets = new DemoMarketWorld(options.now?.getTime());
  setListPrices(
    Object.entries(seed.askingPrices).map(([domainName, p]) => ({
      domainName,
      ...p,
      currency: 'USD',
    })),
  );
  const authCodeNames = new Set(
    seed.records
      .filter((r) => registrars[r.registrar].features.includes('getAuthCode'))
      .map((r) => r.domainName),
  );
  const approvesTransfer = (name: string) => {
    const record = world.get(name);
    return (
      !!record &&
      registrars[record.registrar].features.includes('approveTransferOut')
    );
  };
  seedDemoMarkets(
    markets,
    seed.records.map((r) => r.domainName),
    seed.askingPrices,
    (name) => authCodeNames.has(name),
    approvesTransfer,
  );
  // The sale at its transfer step: the buyer's registrar has asked for the
  // name, and its registrar holds it for you to answer (Approve transfer).
  // A transfer only gets this far on an unlocked name.
  const transferring = markets.sales
    .get('demo-afternic')
    ?.find((s) => s.action === 'transfer');
  const record = transferring && world.get(transferring.name);
  if (record && approvesTransfer(record.domainName)) {
    const day = 24 * 60 * 60 * 1000;
    record.locked = false;
    record.transferOut = {
      status: 'pending',
      // As Dynadot reports a pending one: "None", and no expiry date.
      rawStatus: 'None',
      id: `demo-${record.domainName}`,
      requestedDate: new Date(markets.now - 2 * day),
      expirationDate: null,
      completedDate: null,
    };
  }
  configureMarketFactory(demoMarketFactory(markets));
  const connected = new Set(marketAccountViews().map((a) => a.id));
  for (const a of DEMO_MARKET_ACCOUNTS) {
    if (!connected.has(a.id))
      await connectMarketAccount(a.market, { ...a.credentials }, a.label, a.id);
  }

  await flushWrites();
  return {
    seed,
    world,
    markets,
    setLatency: (ms) => {
      latencyMs = ms;
    },
  };
}

/** Puts the real provider factory back (tests; leaving demo mode). */
export function uninstallDemo(): void {
  configureRegistrarFactory(null);
  configureMarketFactory(null);
  resetRegistrarClients();
}
