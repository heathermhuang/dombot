import type { CurrencyCode } from './currencies';

// The domain event log (docs/storage-model.md, "Domain events"). One record
// per thing that happened to a name: something you did (bought it, sold it)
// or something sync saw (it appeared in an account, it left one). Stored in
// `domain-events`, keyed by `id`, so a new event is one small write and the
// history is never rewritten.
//
// The stored values are the lowercase strings. They never change once
// written: renaming a constant is free, renaming a value needs a migration.

export const DomainEventType = {
  // Something you did.
  Registered: 'registered', // hand-registered as a new name
  Purchased: 'purchased', // bought from someone (aftermarket, private)
  Sold: 'sold',
  Renewed: 'renewed',
  // Something sync saw.
  Added: 'added', // the name appeared in an account
  Removed: 'removed', // the name is gone from an account
  Moved: 'moved', // gone from one of your accounts, appeared in another
  // A setting changed (auto-renew, privacy, nameservers…): never an alert.
  Changed: 'changed',
} as const;
export type DomainEventType =
  (typeof DomainEventType)[keyof typeof DomainEventType];

export const DomainEventSource = {
  User: 'user',
  Sync: 'sync',
  Import: 'import',
  Lookup: 'lookup', // the registration check (none written today)
  Agent: 'agent', // an MCP client, on your behalf
  Bulk: 'bulk', // a bulk job you started
} as const;
export type DomainEventSource =
  (typeof DomainEventSource)[keyof typeof DomainEventSource];

/** Who records a change you asked for: you in the app, or an MCP client. */
export type UserSource =
  typeof DomainEventSource.User | typeof DomainEventSource.Agent;

const EVENT_TYPES = new Set<string>(Object.values(DomainEventType));
const EVENT_SOURCES = new Set<string>(Object.values(DomainEventSource));

export function isDomainEventType(value: unknown): value is DomainEventType {
  return typeof value === 'string' && EVENT_TYPES.has(value);
}

export function isDomainEventSource(
  value: unknown,
): value is DomainEventSource {
  return typeof value === 'string' && EVENT_SOURCES.has(value);
}

/**
 * What a `changed` event changed. The values match the `DomainOp` kinds that
 * write them; DNS and contacts are MCP-only writes.
 */
export const DomainSetting = {
  AutoRenew: 'autoRenew',
  Privacy: 'privacy',
  Lock: 'lock',
  Nameservers: 'nameservers',
  UrlForwarding: 'urlForwarding',
  EmailForwarding: 'emailForwarding',
  Dns: 'dns',
  Contacts: 'contacts',
} as const;
export type DomainSetting = (typeof DomainSetting)[keyof typeof DomainSetting];

const SETTINGS = new Set<string>(Object.values(DomainSetting));

export function isDomainSetting(value: unknown): value is DomainSetting {
  return typeof value === 'string' && SETTINGS.has(value);
}

/**
 * A setting's value in a `changed` event: on or off, or a list (nameservers,
 * forwarding rules, DNS records, contact roles) as short readable lines.
 */
export type SettingValue = boolean | string[];

/** Types that start a holding: what you paid shows against these. */
export const ACQUISITION_TYPES: ReadonlySet<DomainEventType> = new Set([
  DomainEventType.Registered,
  DomainEventType.Purchased,
]);

export interface DomainEvent {
  /** Time-sortable id (see `newEventId`), also the storage key. */
  id: string;
  /** `toAscii(name)`. */
  domain: string;
  type: DomainEventType;
  source: DomainEventSource;
  /**
   * `YYYY-MM-DD`, the day it happened; user-editable. Null only for a
   * purchase or sale you recorded without knowing the day.
   */
  date: string | null;
  /** ms epoch, when DomBot recorded it. */
  createdAt: number;
  /** ms epoch, the last edit; null until edited. */
  updatedAt: number | null;
  accountId?: string | null;
  fromAccountId?: string | null; // moved
  toAccountId?: string | null; // moved
  /** Canonical decimal ("19.99", "1500"); set together with `currency`. */
  amount?: string | null;
  currency?: CurrencyCode | null;
  /**
   * sold: what the sale cost you (commission, escrow, broker), in
   * `currency`. Absent or null is unknown; "0" means none.
   */
  fees?: string | null;
  /** registered, purchased, renewed: the term in years. */
  years?: number | null;
  /**
   * removed: the expiry sync last saw, when it had passed by the day the name
   * left. That removal is a lapse (Archive's Expired), not one to review.
   */
  expires?: string;
  /** The id of the sync event this user event resolves. */
  resolves?: string;
  /** A sync alert acknowledged with no action. */
  dismissed?: boolean;
  /**
   * removed: you marked it dropped: it left and no money came back (let go
   * early, or moved somewhere DomBot doesn't sync). Counts as dismissed.
   */
  dropped?: boolean;
  /** sold: you marked the name handed over, though an account of yours
   * still shows it (the buyer took it at the same registrar, say). */
  transferred?: boolean;
  /** The import that wrote it, if one did (docs/domain-import-export.md). */
  importId?: string;
  /**
   * The market sale it records, as its `market-sales` key (docs/markets.md):
   * set on a `sold` event a market sync wrote or linked, so a later sync
   * never records the same sale twice.
   */
  marketSale?: string;
  /** changed: which setting. */
  setting?: DomainSetting;
  /** changed: the value before, when DomBot knew it. */
  before?: SettingValue;
  /** changed: the value after. */
  after?: SettingValue;
}

/** A note on a name, or on one of its events. Stored in `domain-notes`. */
export interface DomainNote {
  id: string;
  /** `toAscii(name)`. */
  domain: string;
  /** Null: about the name. Set: about that event. */
  eventId: string | null;
  text: string;
  createdAt: number;
  updatedAt: number | null;
}

/**
 * `YYYY-MM-DD` for a moment, in this machine's local time: the day you'd
 * say it happened. (A Worker has no local zone, so there it's the UTC day.)
 */
export function localDay(ms: number = Date.now()): string {
  const d = new Date(ms);
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${month}-${day}`;
}

// Crockford base32, as ULID uses: sortable as plain strings.
const BASE32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

/**
 * A monotonic ULID: 10 characters of millisecond timestamp, then 16 of
 * randomness. Ids sort by when they were made, and two instances never
 * collide, so a later remote sync can union events by id. Within one
 * millisecond (a sync writes several events at once) each id increments the
 * last one instead of drawing new randomness, so order is kept exactly.
 */
let lastTime = -1;
let lastRandom: number[] = [];

export function newEventId(now: number = Date.now()): string {
  const t0 = Math.max(now, lastTime);
  let random: number[];
  if (t0 === lastTime) {
    random = [...lastRandom];
    // Base-32 increment from the right (16 digits never overflow in practice).
    for (let i = random.length - 1; i >= 0; i--) {
      if (random[i] < 31) {
        random[i]++;
        break;
      }
      random[i] = 0;
    }
  } else {
    random = Array.from(
      crypto.getRandomValues(new Uint8Array(16)),
      (b) => b % 32,
    );
  }
  lastTime = t0;
  lastRandom = random;
  let time = '';
  let t = t0;
  for (let i = 0; i < 10; i++) {
    time = BASE32[t % 32] + time;
    t = Math.floor(t / 32);
  }
  return time + random.map((d) => BASE32[d]).join('');
}
