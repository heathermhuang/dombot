import { describe, it, expect } from 'vitest';

import { AFTERNIC_NAMESERVERS } from '../../core/markets/afternic/nameservers';
import { ATOM_NAMESERVERS } from '../../core/markets/atom/nameservers';
import { SEDO_NAMESERVERS } from '../../core/markets/sedo/nameservers';
import { nameserverGroup } from './nameservers';

/** The market catalog's nameservers, as the Domains page passes them. */
const markets = [
  { id: 'afternic' as const, nameservers: AFTERNIC_NAMESERVERS },
  { id: 'atom' as const, nameservers: ATOM_NAMESERVERS },
  { id: 'sedo' as const, nameservers: SEDO_NAMESERVERS },
];

describe('nameserverGroup', () => {
  it('groups a hostname by its registrable base domain', () => {
    expect(nameserverGroup('ns-220-a.gandi.net')).toEqual({
      key: 'gandi.net',
      label: 'gandi.net',
    });
  });

  it('resolves multi-part public suffixes', () => {
    expect(nameserverGroup('n.a.b.3.host.co.uk')).toEqual({
      key: 'host.co.uk',
      label: 'host.co.uk',
    });
  });

  it('trims and lowercases the input', () => {
    expect(nameserverGroup('  NS1.EXAMPLE.COM  ')).toEqual({
      key: 'example.com',
      label: 'example.com',
    });
  });

  it('splits Afternic nameservers into consecutive pairs', () => {
    expect(nameserverGroup('ns1.afternic.com')).toEqual({
      key: 'afternic.com#1',
      label: 'Afternic (ns1/ns2)',
    });
    expect(nameserverGroup('ns2.afternic.com')).toEqual({
      key: 'afternic.com#1',
      label: 'Afternic (ns1/ns2)',
    });
    expect(nameserverGroup('ns4.afternic.com')).toEqual({
      key: 'afternic.com#2',
      label: 'Afternic (ns3/ns4)',
    });
  });

  it('names each market’s own nameservers', () => {
    expect(nameserverGroup('NS5.Afternic.com.', markets)).toEqual({
      key: 'afternic.com#3',
      label: 'Afternic (ns5/ns6)',
    });
    expect(nameserverGroup('ns1.atom.com', markets)).toEqual({
      key: 'atom.com',
      label: 'Atom',
    });
    expect(nameserverGroup('ns2.atomregistrar.com', markets)).toEqual({
      key: 'atomregistrar.com',
      label: 'AtomRegistrar',
    });
    expect(nameserverGroup('ns1.squadhelp.com', markets)).toEqual({
      key: 'squadhelp.com',
      label: 'Atom (Squadhelp)',
    });
    expect(nameserverGroup('ns2.sedoparking.com', markets)).toEqual({
      key: 'sedoparking.com',
      label: 'Sedo',
    });
  });

  it('pairs multi-digit Afternic nsN labels', () => {
    expect(nameserverGroup('ns10.afternic.com')).toEqual({
      key: 'afternic.com#5',
      label: 'Afternic (ns9/ns10)',
    });
  });

  it('does not treat a non-boundary "ns" (e.g. dns1) as a pair label', () => {
    expect(nameserverGroup('dns1.afternic.com')).toEqual({
      key: 'afternic.com',
      label: 'afternic.com',
    });
  });

  it('falls back to the base domain when Afternic host lacks an nsN label', () => {
    expect(nameserverGroup('mail.afternic.com')).toEqual({
      key: 'afternic.com',
      label: 'afternic.com',
    });
  });

  it('falls back to the base domain for a bare Afternic host with no subdomain', () => {
    expect(nameserverGroup('afternic.com')).toEqual({
      key: 'afternic.com',
      label: 'afternic.com',
    });
  });

  it('returns null for empty or unparseable values', () => {
    expect(nameserverGroup('')).toBeNull();
    expect(nameserverGroup('   ')).toBeNull();
    expect(nameserverGroup('192.168.1.1')).toBeNull();
  });
});
