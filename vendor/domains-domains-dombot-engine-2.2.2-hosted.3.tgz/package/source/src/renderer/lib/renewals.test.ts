import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ExchangeRates } from '../../shared/exchange-rates';
import type { Domain, RenewalPricing } from '../../shared/ipc';
import {
  compactMoney,
  dueWithin,
  groupBy,
  leavesOut,
  pastRenewalDates,
  summarize,
  tldOf,
  upcomingByMonth,
} from './renewals';

const NOW = new Date('2026-06-15T12:00:00Z');

function domain(partial: Partial<Domain> & { domainName: string }): Domain {
  return {
    registrar: 'dynadot',
    status: 'active',
    createdDate: null,
    expirationDate: null,
    renewalDate: null,
    autoRenew: false,
    locked: false,
    privacy: false,
    nameservers: [],
    syncedAt: new Date(0),
    deleted: false,
    source: 'registrar',
    ...partial,
  };
}

function price(
  d: Domain,
  renewal: number | null,
  source: RenewalPricing['source'] = 'base',
): [string, RenewalPricing] {
  return [
    `${d.registrar}:${d.domainName}`,
    {
      domain: d.domainName,
      registrar: d.registrar,
      renewal,
      currency: 'USD',
      source,
    },
  ];
}

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(NOW);
});
afterEach(() => vi.useRealTimers());

describe('compactMoney', () => {
  it('is whole under a thousand, then in thousands', () => {
    expect(compactMoney(820.4, 'USD', 'USD', 'us')).toBe('$820');
    expect(compactMoney(4210, 'USD', 'USD', 'us')).toBe('$4.2k');
    expect(compactMoney(120_000, 'EUR', 'USD', 'us')).toBe('€120k');
  });

  it('follows the number format and shows a shared symbol’s code', () => {
    expect(compactMoney(4210, 'EUR', 'EUR', 'eu-dot')).toBe('€4,2k');
    expect(compactMoney(4210, 'CAD', 'USD', 'us')).toBe('$4.2k CAD');
    expect(compactMoney(42_000, 'JPY', 'USD', 'us')).toBe('¥42k JPY');
  });
});

describe('tldOf', () => {
  it('takes everything after the first dot, lowercased', () => {
    expect(tldOf('Example.CO.UK')).toBe('co.uk');
    expect(tldOf('example.com')).toBe('com');
  });
  it('is empty when there is no dot', () =>
    expect(tldOf('localhost')).toBe(''));
});

describe('summarize', () => {
  it('counts priced/unpriced, sources, and sums', () => {
    const a = domain({ domainName: 'a.com', autoRenew: true });
    const b = domain({ domainName: 'b.com' });
    const c = domain({ domainName: 'c.com' }); // unpriced
    const pricing = Object.fromEntries([
      price(a, 10, 'base'),
      price(b, 20, 'manual'),
    ]);
    const s = summarize([a, b, c], pricing);

    expect(s.total).toBe(3);
    expect(s.priced).toBe(2);
    expect(s.unpriced).toBe(1);
    expect(s.base).toBe(1);
    expect(s.tld).toBe(0);
    expect(s.manual).toBe(1);
    expect(s.yearly).toBe(30);
    expect(s.yearlyAutoRenew).toBe(10); // only a has autoRenew
    expect(s.avgPerDomain).toBe(15);
  });

  it('treats a null renewal as unpriced', () => {
    const a = domain({ domainName: 'a.com' });
    const s = summarize([a], Object.fromEntries([price(a, null)]));
    expect(s.priced).toBe(0);
    expect(s.unpriced).toBe(1);
  });

  it('handles empty input with a zero average', () => {
    const s = summarize([], {});
    expect(s).toMatchObject({
      total: 0,
      priced: 0,
      yearly: 0,
      avgPerDomain: 0,
    });
  });
});

describe('groupBy', () => {
  it('groups, sums known renewals, and sorts by spend desc then count', () => {
    const a = domain({ domainName: 'a.com', registrar: 'dynadot' });
    const b = domain({ domainName: 'b.com', registrar: 'dynadot' });
    const c = domain({ domainName: 'c.net', registrar: 'porkbun' });
    const pricing = Object.fromEntries([
      price(a, 5),
      price(b, 5),
      price(c, 50),
    ]);

    const groups = groupBy(
      [a, b, c],
      pricing,
      (d) => d.registrar,
      (k) => k.toUpperCase(),
    );
    expect(groups.map((g) => g.key)).toEqual(['porkbun', 'dynadot']); // 50 > 10
    expect(groups[0]).toMatchObject({
      label: 'PORKBUN',
      count: 1,
      priced: 1,
      yearly: 50,
    });
    expect(groups[1]).toMatchObject({ count: 2, priced: 2, yearly: 10 });
  });

  it('breaks a spend tie by count desc', () => {
    const a = domain({ domainName: 'a.com', registrar: 'dynadot' });
    const b = domain({ domainName: 'b.net', registrar: 'porkbun' });
    const c = domain({ domainName: 'c.net', registrar: 'porkbun' });
    // Both groups sum to 0 (unpriced) → tie broken by count.
    const groups = groupBy(
      [a, b, c],
      {},
      (d) => d.registrar,
      (k) => k,
    );
    expect(groups[0].key).toBe('porkbun');
    expect(groups[0].count).toBe(2);
  });
});

describe('upcomingByMonth', () => {
  it('returns a continuous strip of `months` buckets including empty ones', () => {
    const buckets = upcomingByMonth([], {}, 3);
    expect(buckets.map((b) => b.key)).toEqual([
      '2026-06',
      '2026-07',
      '2026-08',
    ]);
    expect(buckets.map((b) => b.label)).toEqual([
      'Jun 2026',
      'Jul 2026',
      'Aug 2026',
    ]);
    expect(buckets.every((b) => b.count === 0)).toBe(true);
  });

  it('crosses a year boundary', () => {
    const buckets = upcomingByMonth([], {}, 8); // Jun..Jan
    expect(buckets[buckets.length - 1].key).toBe('2027-01');
  });

  it('separates past planning dates from future renewal months', () => {
    const past = domain({
      domainName: 'past.com',
      renewalDate: new Date('2026-01-01'),
    });
    const soon = domain({
      domainName: 'soon.com',
      renewalDate: new Date('2026-07-10'),
    });
    const pricing = Object.fromEntries([price(past, 10), price(soon, 20)]);
    const buckets = upcomingByMonth([past, soon], pricing, 3);

    const jun = buckets.find((b) => b.key === '2026-06')!;
    const jul = buckets.find((b) => b.key === '2026-07')!;
    expect(jun).toMatchObject({ count: 0, priced: 0, yearly: 0 });
    expect(jul).toMatchObject({ count: 1, priced: 1, yearly: 20 });
    expect(pastRenewalDates([past, soon])).toEqual([past]);
  });

  it('skips renewals beyond the window and invalid/missing dates', () => {
    const far = domain({
      domainName: 'far.com',
      renewalDate: new Date('2027-12-01'),
    });
    const none = domain({
      domainName: 'none.com',
      renewalDate: null,
      expirationDate: null,
    });
    const buckets = upcomingByMonth([far, none], {}, 3);
    expect(buckets.every((b) => b.count === 0)).toBe(true);
  });

  it('falls back to expirationDate when renewalDate is missing', () => {
    const d = domain({
      domainName: 'x.com',
      expirationDate: new Date('2026-07-05'),
    });
    const buckets = upcomingByMonth([d], {}, 3);
    expect(buckets.find((b) => b.key === '2026-07')!.count).toBe(1);
  });
});

describe('dueWithin', () => {
  it('ignores Gandi update dates and keeps other registrars’ real early deadlines', () => {
    const gandi = domain({
      domainName: 'future.example',
      registrar: 'gandi',
      renewalDate: new Date('2025-08-22'),
      expirationDate: new Date('2029-11-24'),
    });
    const early = domain({
      domainName: 'early.example',
      registrar: 'porkbun',
      renewalDate: new Date('2026-06-20'),
      expirationDate: new Date('2027-11-24'),
    });
    const past = domain({
      domainName: 'past.example',
      renewalDate: new Date('2025-01-01'),
    });
    expect(dueWithin([gandi, early, past], {}, 30).count).toBe(1);
    expect(pastRenewalDates([gandi, early, past])).toEqual([past]);
  });
  it('counts domains due within the cutoff and sums only priced ones', () => {
    const soon = domain({
      domainName: 'soon.com',
      renewalDate: new Date('2026-06-20'),
    });
    const unpriced = domain({
      domainName: 'u.com',
      renewalDate: new Date('2026-06-18'),
    });
    const later = domain({
      domainName: 'later.com',
      renewalDate: new Date('2026-08-01'),
    });
    const pricing = Object.fromEntries([price(soon, 12)]);

    const r = dueWithin([soon, unpriced, later], pricing, 30);
    expect(r.count).toBe(2); // soon + unpriced, both within 30 days
    expect(r.yearly).toBe(12); // only soon is priced
  });

  it('includes a renewal exactly at the cutoff boundary', () => {
    const at = domain({
      domainName: 'at.com',
      renewalDate: new Date(NOW.getTime() + 10 * 86_400_000),
    });
    expect(dueWithin([at], {}, 10).count).toBe(1);
  });

  it('converts renewals in other currencies, and lists the ones it can’t', () => {
    const usd = domain({
      domainName: 'usd.com',
      renewalDate: new Date('2026-06-20'),
    });
    const eur = domain({
      domainName: 'eur.de',
      renewalDate: new Date('2026-06-21'),
    });
    const [eurKey, eurPrice] = price(eur, 45);
    const pricing = {
      ...Object.fromEntries([price(usd, 12)]),
      [eurKey]: { ...eurPrice, currency: 'EUR' },
    };

    expect(dueWithin([usd, eur], pricing, 30, 'USD', fx)).toEqual({
      count: 2,
      yearly: 68.25,
      leftOut: [],
    });
    expect(upcomingByMonth([usd, eur], pricing, 1, 'USD', fx)[0]).toMatchObject(
      { count: 2, priced: 2, yearly: 68.25, leftOut: [] },
    );

    // Without rates, or in a currency outside the 30, it's left out.
    expect(dueWithin([usd, eur], pricing, 30)).toEqual({
      count: 2,
      yearly: 12,
      leftOut: [{ currency: 'EUR', count: 1, yearly: 45 }],
    });
    const twd = { ...pricing, [eurKey]: { ...eurPrice, currency: 'TWD' } };
    expect(upcomingByMonth([usd, eur], twd, 1, 'USD', fx)[0]).toMatchObject({
      yearly: 12,
      leftOut: [{ currency: 'TWD', count: 1, yearly: 45 }],
    });
  });
});

// One rate: 1 EUR = 1.25 USD. Renewals are ahead, so they take the newest.
const fx = new ExchangeRates(
  {},
  new Map([
    ['2026-04', { USD: 1.1 }],
    ['2026-05', { USD: 1.25 }],
  ]),
);

describe('currencies', () => {
  const a = domain({ domainName: 'a.com', autoRenew: true });
  const b = domain({ domainName: 'b.com' });
  const c = domain({ domainName: 'c.de' });
  const inEur = (d: Domain, renewal: number): [string, RenewalPricing] => {
    const [key, p] = price(d, renewal, 'manual');
    return [key, { ...p, currency: 'EUR' }];
  };

  it('totals in your currency, converting the others at the newest rate', () => {
    const pricing = Object.fromEntries([
      price(a, 10),
      price(b, 20),
      inEur(c, 7),
    ]);
    const s = summarize([a, b, c], pricing, 'USD', fx);
    expect(s).toMatchObject({
      currency: 'USD',
      priced: 3,
      yearly: 38.75,
      yearlyAutoRenew: 10,
      avgPerDomain: 38.75 / 3,
      converted: 1,
      convertedFrom: ['EUR'],
      leftOut: [],
    });
    expect(
      groupBy(
        [a, b, c],
        pricing,
        (d) => tldOf(d.domainName),
        (t) => t,
        'USD',
        fx,
      ).map((g) => [g.key, g.yearly]),
    ).toEqual([
      ['com', 30],
      ['de', 8.75],
    ]);
  });

  it('totals in euros when they’re your currency', () => {
    const pricing = Object.fromEntries([inEur(a, 5), inEur(b, 6), price(c, 9)]);
    expect(summarize([a, b, c], pricing, 'EUR', fx)).toMatchObject({
      currency: 'EUR',
      yearly: 18.2,
      converted: 1,
      convertedFrom: ['USD'],
    });
  });

  it('leaves out what it can’t convert, and says so', () => {
    const [key, p] = price(c, 300);
    const pricing = Object.fromEntries([
      price(a, 10),
      [key, { ...p, currency: 'TWD' }],
    ]);
    const s = summarize([a, b, c], pricing, 'USD', fx);
    expect(s).toMatchObject({
      priced: 2,
      yearly: 10,
      avgPerDomain: 10,
      converted: 0,
      leftOut: [{ currency: 'TWD', count: 1, yearly: 300 }],
    });
    expect(leavesOut(s.leftOut)).toBe('Leaves out 1 renewal in TWD');
    expect(
      leavesOut([
        { currency: 'TWD', count: 2, yearly: 1 },
        { currency: 'KES', count: 1, yearly: 1 },
      ]),
    ).toBe('Leaves out 3 renewals in KES, TWD');
    expect(leavesOut([])).toBeNull();
  });
});

it('counts portal snapshots separately from base, TLD and manual prices', () => {
  const d = domain({ domainName: 'portal.test' });
  const result = summarize(
    [d],
    Object.fromEntries([price(d, 45, 'portal')]),
    'USD',
  );
  expect(result).toMatchObject({
    priced: 1,
    portal: 1,
    base: 0,
    tld: 0,
    manual: 0,
    yearly: 45,
  });
});
