import { describe, expect, it } from 'vitest';
import type { DomainEvent } from '../../shared/domain-events';
import { ExchangeRates } from '../../shared/exchange-rates';
import { importedRows } from '../../shared/imported-domains';
import {
  alertDomain,
  eventAccounts,
  eventConversion,
  eventDay,
  eventDetails,
  withinDays,
} from './activity';

const event = (patch: Partial<DomainEvent>): DomainEvent => ({
  id: 'E1',
  domain: 'a.com',
  type: 'removed',
  source: 'sync',
  date: '2026-09-25',
  createdAt: 1,
  updatedAt: null,
  ...patch,
});

describe('event helpers', () => {
  it('dates an event by its day, or the day it was recorded', () => {
    expect(eventDay(event({ date: '2026-01-02' }))).toBe('2026-01-02');
    expect(
      eventDay(event({ date: null, createdAt: Date.UTC(2026, 0, 5, 12) })),
    ).toBe('2026-01-05');
  });

  it('keeps events inside the window', () => {
    const now = Date.UTC(2026, 8, 26, 12);
    expect(withinDays(event({ date: '2026-09-20' }), 7, now)).toBe(true);
    expect(withinDays(event({ date: '2026-09-01' }), 7, now)).toBe(false);
  });

  it('names every account and the details', () => {
    expect(
      eventAccounts(
        event({
          type: 'moved',
          accountId: null,
          fromAccountId: 'a',
          toAccountId: 'b',
        }),
      ),
    ).toEqual(['a', 'b']);
    expect(
      eventDetails(
        event({ type: 'renewed', amount: '10.00', currency: 'USD', years: 2 }),
        'us',
        'USD',
      ),
    ).toBe('$10.00 · 2 yr');
    expect(eventDetails(event({}), 'us', 'USD')).toBeNull();
    // A departure that needs no answer says why.
    expect(eventDetails(event({ expires: '2026-09-20' }), 'us', 'USD')).toBe(
      'Expired 2026-09-20',
    );
    expect(eventDetails(event({ dropped: true }), 'us', 'USD')).toBe('Dropped');
  });

  it('shows an amount in another currency in yours on hover', () => {
    // 1 EUR = 1.2 USD in March 2024; October 2026 has only a day's rate.
    const fx = new ExchangeRates(
      { '2026-10-28': { rates: { USD: 1.1 } } },
      new Map([['2024-03', { USD: 1.2 }]]),
    );
    const bought = event({
      type: 'purchased',
      date: '2024-03-15',
      amount: '1200.00',
      currency: 'EUR',
    });
    expect(eventConversion(bought, 'us', 'USD', fx)).toBe(
      '€1,200.00 ≈ $1,440.00 at the March 2024 average (ECB)',
    );
    expect(
      eventConversion(
        { ...bought, type: 'renewed', date: '2026-10-29', years: 2 },
        'us',
        'USD',
        fx,
      ),
    ).toBe(
      '€1,200.00 ≈ $1,320.00 at the 28 Oct 2026 rate, until the October average is out (ECB) · 2 yr',
    );
    // In your currency, or with no amount: nothing to add.
    expect(eventConversion(bought, 'us', 'EUR', fx)).toBeNull();
    expect(eventConversion(event({}), 'us', 'USD', fx)).toBeNull();
    expect(
      eventConversion({ ...bought, currency: 'TWD' }, 'us', 'USD', fx),
    ).toMatch(/\(Domains\.Domains can’t convert TWD\)$/);
  });
});

describe('alertDomain', () => {
  it("opens on an imported name's own row, and builds one for a departed name", () => {
    const imported = importedRows(
      {
        'hand.com': {
          registrar: 'gandi',
          createdDate: null,
          expirationDate: null,
          autoRenew: null,
          addedAt: 1,
          updatedAt: null,
        },
      },
      [],
    );
    const arrival = event({
      domain: 'hand.com',
      type: 'added',
      source: 'user',
      accountId: null,
    });
    expect(alertDomain(arrival, imported, null)).toMatchObject({
      domainName: 'hand.com',
      registrar: 'gandi',
      source: 'imported',
    });
    expect(
      alertDomain(event({ domain: 'gone.com' }), imported, null),
    ).toMatchObject({ source: 'registrar', departed: true });
  });
});
