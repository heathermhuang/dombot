// Pure capability logic for domain operations, shared by main (the dispatcher's
// up-front check, the MCP tools) and the renderer (disabling controls, bucketing
// a bulk selection). No Electron, no network.

import { Feature } from '@aoxborrow/registrar-client';
import type { DomainOp, DomainOpKind, RegistrarName } from './ipc';
import { OPTIONAL_SETTINGS_FEATURES } from './registrar-fields';

/** Extended features an op needs; ops absent here are core on every provider. */
const REQUIRED_FEATURE: Partial<Record<DomainOpKind, string>> = {
  authCode: Feature.GetAuthCode,
  urlForwarding: Feature.SetDomainForwarding,
  emailForwarding: Feature.SetEmailForwarding,
  approveTransfer: Feature.ApproveTransferOut,
};

/**
 * Known gaps in the *core* contract. The library lists every core feature on
 * every provider even where the method throws `NotImplementedError` (core is a
 * promise, not a capability probe), so these have to live here. Each returns a
 * human reason, or null when the op is fine. A `NotImplementedError` we didn't
 * predict is still classified `unsupported` at run time — this map is the UX
 * nicety that stops the click from happening in the first place.
 */
const KNOWN_GAPS: Partial<
  Record<RegistrarName, (op: DomainOp) => string | null>
> = {
  '101domain': (op) =>
    op.kind === 'autoRenew' ||
    op.kind === 'lock' ||
    op.kind === 'privacy' ||
    op.kind === 'renew'
      ? '101domain’s API does not offer this change yet — use your 101domain account.'
      : op.kind === 'urlForwarding' &&
          (op.forwards.length > 1 ||
            op.forwards.some((f) => f.host !== '@' || f.type !== 'permanent'))
        ? '101domain supports one permanent URL forwarding rule for the domain root.'
        : null,
  cloudflare: (op) =>
    op.kind === 'autoRenew' ||
    op.kind === 'lock' ||
    op.kind === 'nameservers' ||
    op.kind === 'renew'
      ? 'Cloudflare’s API has no post-registration update for this — change it in the Cloudflare dashboard.'
      : null,
  namefi: (op) =>
    op.kind === 'lock' ||
    op.kind === 'privacy' ||
    op.kind === 'nameservers' ||
    op.kind === 'renew'
      ? 'Namefi’s public API does not offer this change; use your Namefi account.'
      : null,
  porkbun: (op) =>
    op.kind === 'lock' || op.kind === 'privacy'
      ? 'Porkbun’s API can’t change this after registration.'
      : null,
  unstoppable: (op) =>
    op.kind === 'renew'
      ? 'Unstoppable renews through its checkout — renew in your Unstoppable account.'
      : null,
};

// Registrars whose API doesn't report WHOIS privacy, so the library's `false`
// is a default rather than a reading.
const PRIVACY_UNREPORTED = new Set<string>(['101domain', 'namefi']);

/** Whether `registrar` reports a domain's WHOIS privacy at all. */
export function reportsPrivacy(registrar: string): boolean {
  return !PRIVACY_UNREPORTED.has(registrar);
}

// Likewise for the transfer lock.
const LOCK_UNREPORTED = new Set<string>(['namefi']);

/** Whether `registrar` reports a domain's transfer lock at all. */
export function reportsLock(registrar: string): boolean {
  return !LOCK_UNREPORTED.has(registrar);
}

// Registrars that record the user's agreement, with their IP address, when
// WHOIS privacy is turned off and the contact details go public.
const PRIVACY_OFF_CONSENT = new Set<string>(['godaddy']);

/** Whether turning privacy off at `registrar` records the user's agreement
 *  and IP address (the app sends both). */
export function recordsPrivacyConsent(registrar: string): boolean {
  return PRIVACY_OFF_CONSENT.has(registrar);
}

/** Short human label per op kind, for reasons and menu items. */
export const OP_LABEL: Record<DomainOpKind, string> = {
  autoRenew: 'auto-renew',
  privacy: 'WHOIS privacy',
  lock: 'transfer lock',
  nameservers: 'nameservers',
  urlForwarding: 'URL forwarding',
  emailForwarding: 'email forwarding',
  authCode: 'auth code',
  renew: 'renewal',
  approveTransfer: 'transfer approval',
  txtRecords: 'TXT records',
};

/**
 * Why `registrar` can't perform `op`, or null when it can. `features` is the
 * provider's capability list (RegistrarMeta.features). Extended-feature ops
 * are gated on the list; core ops on the known-gaps map.
 */
export function unsupportedReason(
  registrar: RegistrarName,
  features: readonly string[],
  op: DomainOp,
): string | null {
  const required = REQUIRED_FEATURE[op.kind];
  if (required && !features.includes(required)) {
    return missingFeatureReason(registrar, required, OP_LABEL[op.kind]);
  }
  return KNOWN_GAPS[registrar]?.(op) ?? null;
}

/** Why an account lacks an extended feature, `what` naming it ("URL
 *  forwarding"): Optional settings it hasn't filled in, or an API without it. */
export function missingFeatureReason(
  registrar: RegistrarName,
  feature: string,
  what: string,
): string {
  return OPTIONAL_SETTINGS_FEATURES[registrar]?.includes(feature)
    ? `Add this account’s Optional settings in Settings › Registrars to use ${what}.`
    : `This registrar doesn’t offer ${what} through its API.`;
}

/** Past-tense summary of a successful op, for toasts and result messages. */
export function opSummary(op: DomainOp): string {
  switch (op.kind) {
    case 'autoRenew':
      return `Auto-renew ${op.enabled ? 'enabled' : 'disabled'}`;
    case 'privacy':
      return `WHOIS privacy ${op.enabled ? 'enabled' : 'disabled'}`;
    case 'lock':
      return op.locked ? 'Locked' : 'Unlocked';
    case 'nameservers':
      return 'Nameservers updated';
    case 'urlForwarding':
      return op.forwards.length === 0
        ? 'URL forwarding cleared'
        : 'URL forwarding updated';
    case 'emailForwarding':
      return op.forwards.length === 0
        ? 'Email forwarding cleared'
        : 'Email forwarding updated';
    case 'authCode':
      return 'Auth code retrieved';
    case 'renew':
      return `Renewed for ${op.years} year${op.years === 1 ? '' : 's'}`;
    case 'approveTransfer':
      return 'Transfer approved';
    case 'txtRecords':
      return op.values.length === 1 ? 'TXT record added' : 'TXT records added';
  }
}

/**
 * The human sentence inside a registrar error. The library wraps HTTP failures
 * as "Request to '<url>' failed with 400 Bad Request: <body>", and the body is
 * usually JSON with the real explanation buried a level or two down. Returns
 * that explanation when it can find one, the raw body otherwise, and the
 * message unchanged when it isn't in that shape.
 */
export function friendlyError(message: string): string {
  const m = /failed with \d{3}[^:]*:\s*([\s\S]+)$/.exec(message);
  if (!m) return message;
  const body = m[1].trim();
  try {
    const parsed: unknown = JSON.parse(body);
    const found = findDescription(parsed);
    if (found) return found;
  } catch {
    // not JSON — the body is the message
  }
  return body;
}

// Depth-first search for the first descriptive string in a registrar error
// body, preferring the keys registrars use for the human explanation.
const DESCRIPTION_KEYS = ['description', 'detail', 'message', 'error'];
function findDescription(value: unknown, depth = 0): string | null {
  if (typeof value === 'string') return value.trim() || null;
  if (!value || typeof value !== 'object' || depth > 3) return null;
  const obj = value as Record<string, unknown>;
  // Nested objects first (e.g. { message: "Bad Request", error: { description } })
  // so a generic top-level status text doesn't win over the real reason.
  for (const key of DESCRIPTION_KEYS) {
    if (obj[key] && typeof obj[key] === 'object') {
      const nested = findDescription(obj[key], depth + 1);
      if (nested) return nested;
    }
  }
  for (const key of DESCRIPTION_KEYS) {
    if (typeof obj[key] === 'string' && (obj[key] as string).trim())
      return (obj[key] as string).trim();
  }
  return null;
}

/** True when a registrar says the operation (or TLD) isn't offered via its
 *  API — the user has to do it in the registrar's own dashboard. */
export function isApiUnsupportedMessage(message: string): boolean {
  return /not (?:yet )?(?:supported|available) (?:via|through|in) (?:the |this )?api|isn['’]t supported via the api/i.test(
    message,
  );
}

/**
 * Replaces every `{domain}` (any case) in `text` with `domainName`. Bulk
 * forwarding ops carry one rule set for many targets; main expands the
 * template per target right before the write.
 */
export function expandTemplate(text: string, domainName: string): string {
  return text.replace(/\{domain\}/gi, domainName);
}
