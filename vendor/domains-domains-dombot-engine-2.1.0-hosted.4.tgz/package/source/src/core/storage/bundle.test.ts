import { beforeEach, describe, expect, it, vi } from 'vitest';
import { MemoryDocStore } from './doc-store';
import { configureStore, flushWrites, hydrateStores } from './namespace';
import {
  BUNDLE_FORMAT,
  BundleError,
  buildBundle,
  exportBundle,
  importBundle,
  parseBundle,
} from './bundle';
import {
  getSettings,
  onSettingsChanged,
  updateSettings,
} from '../services/settings';
import { createFolder, getFolders } from '../services/folders';
import {
  getStoredCredentials,
  setStoredCredentials,
} from '../services/credentials';
import {
  getRegistrarClient,
  getRegistrarMetadata,
} from '../services/registrars';
import { listAccounts } from '../services/accounts';
import { EncryptedDocStore, aesGcmCipher } from './encrypted';
import { sealBundle } from '../../shared/bundle-seal';
import { bumpRevision, getRevisions } from '../revision';
import { onCoreEvent } from '../events';

const APP = { version: '9.9.9', platform: 'test' };

let store: MemoryDocStore;
beforeEach(async () => {
  store = new MemoryDocStore();
  configureStore(store);
  await hydrateStores();
});

async function seed() {
  await setStoredCredentials('godaddy', { apiToken: 'k' });
  createFolder({ name: 'Keepers', color: 'green', description: '' });
  updateSettings({ mcpEnabled: true, autoSyncIntervalMinutes: 60 });
  bumpRevision('portfolio');
  await flushWrites();
}

describe('buildBundle', () => {
  it('captures every namespace except local ones (meta)', async () => {
    await seed();
    const b = buildBundle(APP);
    expect(b.format).toBe(BUNDLE_FORMAT);
    expect(b.app).toEqual(APP);
    expect(Object.keys(b.namespaces).sort()).toEqual(
      expect.arrayContaining(['registrar-credentials', 'folders', 'settings']),
    );
    expect(b.namespaces.meta).toBeUndefined();
    expect(b.namespaces.auth).toBeUndefined();
    expect(b.version).toBe(12);
    expect(b.namespaces['registrar-credentials'].godaddy).toEqual({
      apiToken: 'k',
    });
  });
});

describe('export → import', () => {
  it('imports a desktop Name.com account into encrypted web storage without losing its identity or credentials', async () => {
    const accountId = '11111111-2222-4333-8444-555555555555';
    const account = { id: accountId, registrar: 'namecom', label: 'Personal' };
    const credentials = { username: 'test-user', apiToken: 'test-token' };
    const desktopBundle = {
      format: BUNDLE_FORMAT,
      version: 2,
      exportedAt: '2026-09-09T00:00:00.000Z',
      app: { version: '1.2.0-namecom.1', platform: 'darwin' },
      namespaces: {
        'registrar-accounts': { [accountId]: account },
        credentials: { [accountId]: credentials },
      },
    };
    const disk = new MemoryDocStore();
    configureStore(
      new EncryptedDocStore(
        disk,
        await aesGcmCipher(crypto.getRandomValues(new Uint8Array(32))),
      ),
    );
    await hydrateStores();

    await importBundle(JSON.stringify(desktopBundle));
    await flushWrites();
    await hydrateStores();

    expect(listAccounts()).toContainEqual(account);
    expect(getStoredCredentials(accountId)).toEqual(credentials);
    expect(getRegistrarMetadata()).toContainEqual(
      expect.objectContaining({
        name: 'namecom',
        accountId,
        configured: true,
      }),
    );
    expect(await disk.get('registrar-credentials', accountId)).toMatchObject({
      __sealed: 1,
    });
    expect(
      JSON.stringify(await disk.list('registrar-credentials')),
    ).not.toContain('test-token');
    expect(
      buildBundle({ ...APP, platform: 'web' }).namespaces['registrar-accounts'][
        accountId
      ],
    ).toEqual(account);
  });

  it('round-trips in the clear and replaces the store', async () => {
    await seed();
    const text = exportBundle(APP);
    expect(text).toContain('"apiToken": "k"');

    // A fresh store with different content.
    configureStore(new MemoryDocStore());
    await hydrateStores();
    createFolder({ name: 'Old', color: 'red', description: '' });
    updateSettings({ mcpEnabled: false });
    await setStoredCredentials('godaddy', { apiToken: 'old' });
    const staleClient = getRegistrarClient('godaddy');
    const settingsChanged = vi.fn();
    onSettingsChanged(settingsChanged);
    const portfolioChanged = vi.fn();
    onCoreEvent('portfolioChanged', portfolioChanged);

    const result = await importBundle(text);
    expect(result.namespaces).toBeGreaterThanOrEqual(3);
    expect(result.entries).toBeGreaterThanOrEqual(3);
    expect(getFolders().folders.map((f) => f.name)).toEqual(['Keepers']);
    expect(getSettings()).toMatchObject({
      mcpEnabled: true,
      autoSyncIntervalMinutes: 60,
    });
    expect(settingsChanged).toHaveBeenCalledWith(
      expect.objectContaining({ mcpEnabled: true }),
      expect.objectContaining({ mcpEnabled: false }),
    );
    expect(portfolioChanged).toHaveBeenCalled();
    // The registrar client built from the old keys is gone.
    expect(getRegistrarClient('godaddy')).not.toBe(staleClient);
    // Revision counters (meta) were not touched by the import.
    expect(getRevisions().portfolio).toBe(0);

    // And it's durable, not just in memory.
    await flushWrites();
    await hydrateStores();
    expect(getFolders().folders.map((f) => f.name)).toEqual(['Keepers']);
  });

  it('refuses a sealed file until the client opens it', async () => {
    await seed();
    const sealed = await sealBundle(exportBundle(APP), 'hunter2');
    expect(() => parseBundle(sealed)).toThrow(/sealed with a passphrase/);
  });

  it('rejects things that are not bundles', () => {
    expect(() => parseBundle('not json')).toThrow(BundleError);
    expect(() => parseBundle('{"format":"x"}')).toThrow(
      /Not a Domains\.Domains data file/,
    );
    expect(() =>
      parseBundle(JSON.stringify({ format: BUNDLE_FORMAT, version: 99 })),
    ).toThrow(/newer Domains\.Domains/);
    expect(() =>
      parseBundle(JSON.stringify({ format: BUNDLE_FORMAT, version: 1 })),
    ).toThrow(/no content/);
    expect(() =>
      parseBundle(
        JSON.stringify({
          format: BUNDLE_FORMAT,
          version: 1,
          namespaces: { folders: [1] },
        }),
      ),
    ).toThrow(/Malformed/);
  });

  it('empties namespaces the file leaves out (nothing survives but meta)', async () => {
    await seed();
    const text = JSON.stringify({
      format: BUNDLE_FORMAT,
      version: 1,
      exportedAt: 'x',
      app: APP,
      namespaces: { settings: { mcpEnabled: true } },
    });
    await importBundle(text);
    await flushWrites();
    expect(getFolders().folders).toEqual([]);
    expect(await store.list('registrar-credentials')).toEqual({});
    expect(await store.list('folders')).toEqual({});
    expect(getSettings().mcpEnabled).toBe(true);
    // Revision counters (meta) are still there.
    expect(getRevisions().portfolio).toBe(1);
  });

  it('ignores namespaces this build does not know', async () => {
    const text = JSON.stringify({
      format: BUNDLE_FORMAT,
      version: 1,
      exportedAt: 'x',
      app: APP,
      namespaces: { 'future-thing': { a: 1 }, settings: { mcpEnabled: true } },
    });
    const result = await importBundle(text);
    expect(result).toEqual({ namespaces: 1, entries: 1 });
    await flushWrites();
    expect(await store.list('future-thing')).toEqual({});
    expect(getSettings().mcpEnabled).toBe(true);
  });

  it('upgrades a v3 file: old names, account-scoped folders and prices', async () => {
    const text = JSON.stringify({
      format: BUNDLE_FORMAT,
      version: 3,
      exportedAt: 'x',
      app: APP,
      namespaces: {
        credentials: { godaddy: { apiToken: 'k' } },
        'cache-portfolio': { godaddy: { fetchedAt: 1, data: { domains: [] } } },
        'tld-rates': { 'godaddy:com': 8.99 },
        'pricing-overrides': {
          'godaddy:Münich.de': 40,
          'acct-2:xn--mnich-kva.de': 99,
        },
        folders: {
          folders: [{ id: 'f1', name: 'Keep', description: '', color: 'red' }],
          assignments: { 'godaddy:a.com': 'f1', 'godaddy:b.com': '__hidden__' },
        },
      },
    });
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    await importBundle(text);
    warn.mockRestore();
    await flushWrites();
    expect(await store.list('registrar-credentials')).toEqual({
      godaddy: { apiToken: 'k' },
    });
    expect(Object.keys(await store.list('registrar-domains'))).toEqual([
      'godaddy',
    ]);
    expect(await store.list('registrar-tld-rates')).toEqual({
      'godaddy:com': 8.99,
    });
    // Keyed by name; the second account's entry for the same name is dropped.
    expect(await store.list('domain-prices')).toEqual({
      'xn--mnich-kva.de': { amount: '40.00', currency: 'USD' },
    });
    expect(getFolders()).toEqual({
      folders: [{ id: 'f1', name: 'Keep', description: '', color: 'red' }],
      // The built-in Hidden folder is gone: b.com has no folder.
      assignments: { 'a.com': 'f1' },
    });
    for (const old of ['credentials', 'cache-portfolio', 'pricing-overrides'])
      expect(await store.list(old)).toEqual({});
  });

  it('imports a v4 file (no history yet) and refuses one newer than v12', async () => {
    await seed();
    const v4 = { ...buildBundle(APP), version: 4 };
    await importBundle(JSON.stringify(v4));
    expect(getFolders().folders.map((f) => f.name)).toEqual(['Keepers']);
    expect(buildBundle(APP).version).toBe(12);
    expect(() => parseBundle(JSON.stringify({ ...v4, version: 13 }))).toThrow(
      /newer Domains\.Domains/,
    );
  });

  it('keeps valid BIN prices from a file and drops the rest', async () => {
    const bundle = {
      ...buildBundle(APP),
      namespaces: {
        ...buildBundle(APP).namespaces,
        'domain-list-prices': {
          'a.com': { amount: '2500', currency: 'usd', updatedAt: 1 },
          'b.com': { amount: '-5', currency: 'USD', updatedAt: 1 },
          'Not A Name': { amount: '10', currency: 'USD', updatedAt: 1 },
          'c.com': {
            amount: '100.00',
            minOffer: '500.00',
            currency: 'USD',
            updatedAt: 1,
          },
        },
      },
    };
    await importBundle(JSON.stringify(bundle));
    await flushWrites();
    expect(await store.list('domain-list-prices')).toEqual({
      'a.com': { amount: '2500', currency: 'USD', updatedAt: 1 },
    });
  });

  it('drops the built-in folders and the dropped and archived events', async () => {
    const event = (id: string, type: string) => ({
      id,
      domain: 'a.com',
      type,
      source: 'user',
      date: '2026-09-01',
      createdAt: 1,
      updatedAt: null,
    });
    const v8 = {
      ...buildBundle(APP),
      version: 8,
      namespaces: {
        ...buildBundle(APP).namespaces,
        'domain-folders': {
          'a.com': '__archive__',
          'b.com': 'f1',
          'c.com': '__hidden__',
        },
        'domain-events': {
          E1: event('E1', 'removed'),
          E2: event('E2', 'dropped'),
          E3: event('E3', 'archived'),
        },
      },
    };
    await importBundle(JSON.stringify(v8));
    await flushWrites();
    expect(await store.list('domain-folders')).toEqual({ 'b.com': 'f1' });
    expect(Object.keys(await store.list('domain-events'))).toEqual(['E1']);
  });

  it('reads a v8 file from before the rename: manual-domains', async () => {
    const entry = {
      registrar: null,
      registrarLabel: 'Epik',
      createdDate: null,
      expirationDate: null,
      autoRenew: null,
      addedAt: 1,
      updatedAt: null,
    };
    const v8 = {
      ...buildBundle(APP),
      namespaces: {
        ...buildBundle(APP).namespaces,
        'manual-domains': { 'a.com': entry },
      },
    };
    await importBundle(JSON.stringify(v8));
    await flushWrites();
    expect(await store.list('imported-domains')).toEqual({ 'a.com': entry });
    expect(await store.list('manual-domains')).toEqual({});
  });
});
