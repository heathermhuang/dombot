This private hosted fork is based on @aoxborrow/registrar-client 0.9.2 (MIT).
The upstream release remains 0.9.2; this is not an upstream-published version.

Dynadot .ai price-only renewal quotes use the mandatory two-year term and divide
the returned term fee by two to preserve TldPricing's annual estimate. Classic
quote rate-limit/transient errors retain their retry class instead of falling
through to another request. No paid renew/register implementation is changed.

The upstream source and unchanged public declarations are included. Rebuild JS:
esbuild src/index.ts --bundle --packages=external --platform=neutral --target=es2022 --format=esm --outfile=dist/index.js
esbuild src/index.ts --bundle --packages=external --platform=neutral --target=es2022 --format=cjs --outfile=dist/index.cjs
