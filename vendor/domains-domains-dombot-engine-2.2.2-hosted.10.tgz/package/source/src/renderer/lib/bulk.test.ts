import { describe, it, expect } from 'vitest';

import {
  bucketSelection,
  bulkKindReason,
  bulkOpTitle,
  defaultBulkOp,
  defaultFlagOp,
  registrarRuleConflicts,
  resultsToCsv,
} from './bulk';
import { validateUrlForwards } from './forwarding-input';
import type { BulkJob, Domain, RegistrarMeta } from '../../shared/ipc';

function domain(partial: Partial<Domain> & { domainName: string }): Domain {
  return {
    registrar: 'dynadot',
    status: 'active',
    createdDate: null,
    expirationDate: null,
    renewalDate: null,
    autoRenew: false,
    locked: false,
    privacy: false,
    nameservers: [],
    syncedAt: new Date(0),
    deleted: false,
    source: 'registrar',
    ...partial,
  };
}

const meta = (name: RegistrarMeta['name'], features: string[] = []) =>
  ({
    name,
    displayName: name,
    supportsSandbox: false,
    configured: true,
    enabled: true,
    sync: {
      lastSyncedAt: null,
      lastError: null,
      lastErrorAt: null,
      domainCount: 0,
      trackedSince: null,
    },
    configFields: [],
    features,
  }) satisfies RegistrarMeta;

const registrars = [meta('dynadot', ['getAuthCode']), meta('cloudflare')];

describe('bucketSelection', () => {
  const a = domain({ domainName: 'a.com', autoRenew: true });
  const b = domain({ domainName: 'b.com', autoRenew: false });
  const c = domain({ domainName: 'c.com', registrar: 'cloudflare' });

  it('splits eligible, already-in-state, and unsupported', () => {
    const r = bucketSelection(
      [a, b, c],
      { kind: 'autoRenew', enabled: true },
      registrars,
      () => true,
    );
    expect(r.eligible.map((d) => d.domainName)).toEqual(['b.com']);
    expect(r.skipped.map((s) => s.domain.domainName)).toEqual(['a.com']);
    expect(r.unsupported[0].domain.domainName).toBe('c.com');
    expect(r.unsupported[0].reason).toMatch(/Cloudflare/);
  });

  it('only trusts privacy/lock from enriched rows', () => {
    const locked = domain({ domainName: 'l.com', locked: true });
    const enriched = bucketSelection(
      [locked],
      { kind: 'lock', locked: true },
      registrars,
      () => true,
    );
    expect(enriched.skipped).toHaveLength(1);
    const summaryOnly = bucketSelection(
      [locked],
      { kind: 'lock', locked: true },
      registrars,
      () => false,
    );
    expect(summaryOnly.eligible).toHaveLength(1);
  });

  it('judges each row by its own account, not the first at its registrar', () => {
    // Two GoDaddy accounts: only the second has the Optional settings that
    // unlock forwarding.
    const accounts = [
      { ...meta('godaddy'), accountId: 'plain' },
      { ...meta('godaddy', ['setDomainForwarding']), accountId: 'full' },
    ];
    const at = (domainName: string, accountId: string) =>
      domain({ domainName, registrar: 'godaddy', accountId });
    const r = bucketSelection(
      [at('plain.com', 'plain'), at('full.com', 'full')],
      { kind: 'urlForwarding', forwards: [] },
      accounts,
      () => true,
    );
    expect(r.eligible.map((d) => d.domainName)).toEqual(['full.com']);
    expect(r.unsupported.map((u) => u.domain.domainName)).toEqual([
      'plain.com',
    ]);
    expect(r.unsupported[0].reason).toMatch(/Optional settings/);
  });

  it('treats everything as eligible until registrar metadata loads', () => {
    const r = bucketSelection([c], { kind: 'authCode' }, null, () => true);
    expect(r.eligible).toHaveLength(1);
  });
});

describe('bulkKindReason', () => {
  it('needs a name at a connected account', () => {
    expect(bulkKindReason([], 'lock', registrars)).toMatch(/connected account/);
  });

  it('is null when any selected registrar can do it', () => {
    const held = [
      domain({ domainName: 'a.com', registrar: 'cloudflare' }),
      domain({ domainName: 'b.com', registrar: 'dynadot' }),
    ];
    expect(bulkKindReason(held, 'nameservers', registrars)).toBeNull();
  });

  it('gives the registrar’s reason when none can', () => {
    const held = [domain({ domainName: 'a.com', registrar: 'cloudflare' })];
    expect(bulkKindReason(held, 'nameservers', registrars)).toMatch(
      /Cloudflare/,
    );
  });

  it('counts a kind supported in one direction as supported', () => {
    const godaddy = [meta('godaddy')];
    const held = [domain({ domainName: 'a.com', registrar: 'godaddy' })];
    expect(bulkKindReason(held, 'privacy', godaddy)).toBeNull();
  });

  it('goes by each name’s account, whose features can differ', () => {
    // GoDaddy's Optional settings give one account auth codes.
    const godaddy = [
      { ...meta('godaddy'), accountId: 'plain' },
      { ...meta('godaddy', ['getAuthCode']), accountId: 'v2' },
    ];
    const at = (accountId: string) => [
      domain({ domainName: 'a.com', registrar: 'godaddy', accountId }),
    ];
    expect(bulkKindReason(at('v2'), 'authCode', godaddy)).toBeNull();
    expect(bulkKindReason(at('plain'), 'authCode', godaddy)).not.toBeNull();
  });
});

describe('bulkOpTitle', () => {
  it('names the op imperatively', () => {
    expect(bulkOpTitle({ kind: 'autoRenew', enabled: false })).toBe(
      'Disable auto-renew',
    );
    expect(bulkOpTitle({ kind: 'lock', locked: false })).toBe('Unlock');
    expect(bulkOpTitle({ kind: 'renew', years: 2 })).toBe('Renew for 2 years');
  });
});

describe('resultsToCsv', () => {
  it('writes one quoted row per result', () => {
    const job: BulkJob = {
      id: 'j',
      op: { kind: 'lock', locked: true },
      status: 'done',
      total: 2,
      results: [
        {
          target: { registrar: 'dynadot', domainName: 'a.com' },
          status: 'ok',
          message: 'Locked',
        },
        {
          target: { registrar: 'gandi', domainName: 'b.com' },
          status: 'failed',
          message: 'Bad, "quoted", reason',
        },
      ],
      counts: {
        ok: 1,
        failed: 1,
        unsupported: 0,
        skipped: 0,
        'rate-limited': 0,
        cancelled: 0,
        unknown: 0,
      },
      startedAt: 0,
      finishedAt: 1,
    };
    expect(resultsToCsv(job)).toBe(
      [
        'Domain,Registrar,Account ID,Status,Message',
        'a.com,dynadot,dynadot,Done,Locked',
        'b.com,gandi,gandi,Failed,"Bad, ""quoted"", reason"',
      ].join('\r\n'),
    );
  });
});

describe('defaultFlagOp', () => {
  const on = domain({ domainName: 'on.com', autoRenew: true });
  const off = domain({ domainName: 'off.com', autoRenew: false });

  it('preselects the value that flips the majority', () => {
    expect(defaultFlagOp('autoRenew', [on, on, off])).toEqual({
      kind: 'autoRenew',
      enabled: false,
    });
    expect(defaultFlagOp('autoRenew', [on, off, off])).toEqual({
      kind: 'autoRenew',
      enabled: true,
    });
  });

  it('turns on for a tie and uses the lock field for locks', () => {
    expect(defaultFlagOp('autoRenew', [on, off])).toEqual({
      kind: 'autoRenew',
      enabled: true,
    });
    expect(
      defaultFlagOp('lock', [domain({ domainName: 'l.com', locked: true })]),
    ).toEqual({
      kind: 'lock',
      locked: false,
    });
  });
});

describe('defaultBulkOp', () => {
  it('gives each kind a sensible starting op', () => {
    expect(defaultBulkOp('nameservers', [])).toEqual({
      kind: 'nameservers',
      nameservers: [],
    });
    expect(defaultBulkOp('urlForwarding', [])).toEqual({
      kind: 'urlForwarding',
      forwards: [],
      skipIfExisting: true,
    });
    expect(defaultBulkOp('renew', [])).toEqual({ kind: 'renew', years: 1 });
    expect(defaultBulkOp('authCode', [])).toEqual({ kind: 'authCode' });
  });
});

describe('registrarRuleConflicts', () => {
  it('isolates registrar-specific rule errors from generic ones', () => {
    const rows = [
      { host: '@', url: 'https://a.com', type: 'permanent' as const },
      { host: 'www', url: 'not a url', type: 'permanent' as const },
    ];
    const generic = validateUrlForwards(rows).errors;
    const conflicts = registrarRuleConflicts(
      [
        domain({ domainName: 'g.com', registrar: 'gandi' }),
        domain({ domainName: 'd.com', registrar: 'dynadot' }),
      ],
      (r) => validateUrlForwards(rows, r),
      generic,
    );
    expect([...conflicts.keys()]).toEqual(['gandi']);
    expect(conflicts.get('gandi')![0]).toMatch(/Gandi/);
  });
});
