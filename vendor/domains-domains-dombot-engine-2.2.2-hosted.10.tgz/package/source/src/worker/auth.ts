import { createRemoteJWKSet, jwtVerify } from 'jose';
import { verifyGatewayRequest } from '../shared/gateway-proof';
import {
  deriveSessionKey,
  fromBase64Url,
  sha256,
  timingSafeEqualStrings,
  toBase64Url,
} from './keys';

// Authentication for the web host. Three modes, chosen by DOMBOT_AUTH
// (docs/web-deployment.md → Auth modes):
//
//   password           built-in login against the DOMBOT_PASSWORD secret; a
//                      signed, HttpOnly cookie carries the session
//   cloudflare-access  Cloudflare Access fronts the Worker; every request's
//                      Cf-Access-Jwt-Assertion is verified against the team's
//                      JWKS and the app's audience tag
//   external           a platform gate the function can't verify (Vercel
//                      Password Protection, a reverse proxy) — explicit opt-in,
//                      the app runs with no login of its own
//
// Password-mode logout revocations and login-attempt backoff live in D1.

export type AuthMode =
  'password' | 'cloudflare-access' | 'external' | 'gateway';

export interface AuthConfig {
  gatewaySecret?: string;
  workspaceId?: string;
  mode: AuthMode;
  /** password mode */
  password?: string;
  sessionKey?: CryptoKey;
  /** cloudflare-access mode */
  accessTeamDomain?: string;
  accessAud?: string;
}

export function parseAuthMode(value: string | undefined): AuthMode {
  if (value === undefined || value === '' || value === 'password')
    return 'password';
  if (
    value === 'cloudflare-access' ||
    value === 'external' ||
    value === 'gateway'
  )
    return value;
  throw new Error(
    `DOMBOT_AUTH must be "password", "cloudflare-access", or "external" (got "${value}")`,
  );
}

/** Builds the auth config from the Worker's env. Fails loudly on a mode
 *  whose prerequisites are missing — better than an unlocked instance. */
export async function buildAuthConfig(
  env: {
    DOMBOT_GATEWAY_SECRET?: string;
    DOMBOT_WORKSPACE_ID?: string;
    DOMBOT_AUTH?: string;
    DOMBOT_PASSWORD?: string;
    CF_ACCESS_TEAM_DOMAIN?: string;
    CF_ACCESS_AUD?: string;
  },
  root: Uint8Array,
): Promise<AuthConfig> {
  const mode = parseAuthMode(env.DOMBOT_AUTH);
  if (mode === 'gateway') {
    if (
      !env.DOMBOT_GATEWAY_SECRET ||
      env.DOMBOT_GATEWAY_SECRET.length < 32 ||
      !env.DOMBOT_WORKSPACE_ID
    )
      throw new Error('Gateway workspace identity and key are required.');
    return {
      mode,
      gatewaySecret: env.DOMBOT_GATEWAY_SECRET,
      workspaceId: env.DOMBOT_WORKSPACE_ID,
    };
  }
  if (mode === 'password') {
    if (!env.DOMBOT_PASSWORD) {
      throw new Error(
        'DOMBOT_PASSWORD is not set. Run `npm run web:secrets` (see docs/self-hosting.md).',
      );
    }
    return {
      mode,
      password: env.DOMBOT_PASSWORD,
      sessionKey: await deriveSessionKey(root, env.DOMBOT_PASSWORD),
    };
  }
  if (mode === 'cloudflare-access') {
    if (!env.CF_ACCESS_TEAM_DOMAIN || !env.CF_ACCESS_AUD) {
      throw new Error(
        'DOMBOT_AUTH=cloudflare-access needs CF_ACCESS_TEAM_DOMAIN and CF_ACCESS_AUD.',
      );
    }
    return {
      mode,
      accessTeamDomain: env.CF_ACCESS_TEAM_DOMAIN.replace(/\/$/, ''),
      accessAud: env.CF_ACCESS_AUD,
    };
  }
  return { mode };
}

// ── password mode: sessions ─────────────────────────────────────────────────

export const SESSION_COOKIE = 'dombot_session';
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

interface SessionClaims {
  iat: number;
  exp: number;
  jti?: string;
}

const enc = new TextEncoder();
const dec = new TextDecoder();

// Identity follows the signed claims, not the textual signature encoding:
// base64 padding/aliases must not provide a second spelling of a revoked cookie.
const sessionFingerprint = async (token: string) =>
  toBase64Url(await sha256(token.slice(0, token.indexOf('.'))));

/** Mints a signed session token: base64url(claims).base64url(hmac). */
export async function createSession(
  key: CryptoKey,
  now = Date.now(),
): Promise<string> {
  const claims: SessionClaims = {
    iat: now,
    exp: now + SESSION_TTL_MS,
    jti: crypto.randomUUID(),
  };
  const body = toBase64Url(enc.encode(JSON.stringify(claims)));
  const sig = new Uint8Array(
    await crypto.subtle.sign('HMAC', key, enc.encode(body)),
  );
  return `${body}.${toBase64Url(sig)}`;
}

/** Verifies a session token's signature and expiry. */
export async function verifySession(
  key: CryptoKey,
  token: string | undefined,
  now = Date.now(),
): Promise<boolean> {
  if (!token) return false;
  const dot = token.indexOf('.');
  if (dot <= 0) return false;
  const body = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  let ok: boolean;
  try {
    ok = await crypto.subtle.verify(
      'HMAC',
      key,
      fromBase64Url(sig),
      enc.encode(body),
    );
  } catch {
    return false;
  }
  if (!ok) return false;
  try {
    const claims = JSON.parse(dec.decode(fromBase64Url(body))) as SessionClaims;
    return (
      typeof claims.exp === 'number' &&
      Number.isFinite(claims.exp) &&
      claims.exp > now
    );
  } catch {
    return false;
  }
}

/** Persist before acknowledging logout. Also accepts previously issued cookies. */
export async function revokeSession(
  db: D1Database,
  key: CryptoKey,
  token: string | undefined,
  now = Date.now(),
): Promise<void> {
  if (!token || !(await verifySession(key, token, now))) return;
  const claims = JSON.parse(
    dec.decode(fromBase64Url(token.split('.')[0])),
  ) as SessionClaims;
  await db
    .prepare('DELETE FROM session_revocations WHERE expires_at <= ?1')
    .bind(now)
    .run();
  await db
    .prepare(
      'INSERT INTO session_revocations (token_hash, expires_at) VALUES (?1, ?2) ON CONFLICT(token_hash) DO NOTHING',
    )
    .bind(await sessionFingerprint(token), claims.exp)
    .run();
}

export function sessionCookie(token: string, secure: boolean): string {
  return (
    `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; ` +
    `Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}` +
    (secure ? '; Secure' : '')
  );
}

export function clearSessionCookie(secure: boolean): string {
  return (
    `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0` +
    (secure ? '; Secure' : '')
  );
}

export function readCookie(
  header: string | undefined,
  name: string,
): string | undefined {
  if (!header) return undefined;
  for (const part of header.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return v.join('=');
  }
  return undefined;
}

/** Checks a submitted password against the configured one, constant-time. */
export function checkPassword(
  config: AuthConfig,
  submitted: string,
): Promise<boolean> {
  if (!config.password) return Promise.resolve(false);
  return timingSafeEqualStrings(config.password, submitted);
}

// ── cloudflare-access mode ──────────────────────────────────────────────────

const jwksCache = new Map<string, ReturnType<typeof createRemoteJWKSet>>();

/** Verifies the Access JWT on a request. Never trusts the header's presence. */
export async function verifyAccessJwt(
  config: AuthConfig,
  token: string | undefined,
): Promise<boolean> {
  if (!token || !config.accessTeamDomain || !config.accessAud) return false;
  let jwks = jwksCache.get(config.accessTeamDomain);
  if (!jwks) {
    jwks = createRemoteJWKSet(
      new URL(`${config.accessTeamDomain}/cdn-cgi/access/certs`),
    );
    jwksCache.set(config.accessTeamDomain, jwks);
  }
  try {
    await jwtVerify(token, jwks, {
      issuer: config.accessTeamDomain,
      audience: config.accessAud,
    });
    return true;
  } catch {
    return false;
  }
}

// ── the gate ────────────────────────────────────────────────────────────────

/** Whether a request is authenticated under the configured mode. */
export async function isAuthenticated(
  config: AuthConfig,
  request: Request,
  db?: D1Database,
): Promise<boolean> {
  switch (config.mode) {
    case 'gateway':
      return Boolean(
        (
          await verifyGatewayRequest(
            config.gatewaySecret!,
            config.workspaceId!,
            request,
          )
        )?.owner,
      );
    case 'password': {
      const token = readCookie(
        request.headers.get('cookie') ?? undefined,
        SESSION_COOKIE,
      );
      if (!db || !token || !(await verifySession(config.sessionKey!, token)))
        return false;
      // Never cache this result: a different runtime can revoke the cookie.
      const revoked = await db
        .prepare(
          'SELECT token_hash FROM session_revocations WHERE token_hash = ?1 AND expires_at > ?2',
        )
        .bind(await sessionFingerprint(token), Date.now())
        .first();
      return !revoked;
    }
    case 'cloudflare-access':
      return verifyAccessJwt(
        config,
        request.headers.get('cf-access-jwt-assertion') ?? undefined,
      );
    case 'external':
      return true;
  }
}

/** Belt-and-braces CSRF check for state-changing requests: the Origin (or,
 *  failing that, Referer) must match the request's own host. */
export function sameOrigin(request: Request): boolean {
  const origin =
    request.headers.get('origin') ?? request.headers.get('referer');
  if (!origin) return false;
  try {
    return new URL(origin).origin === new URL(request.url).origin;
  } catch {
    return false;
  }
}
