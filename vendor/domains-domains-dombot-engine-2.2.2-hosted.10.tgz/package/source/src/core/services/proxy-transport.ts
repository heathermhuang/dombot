import {
  markNotSent,
  registrars,
  type Registrar,
  type RegistrarCredentials,
  type RegistrarName,
  type RegistrarOptions,
} from '@aoxborrow/registrar-client';
import { parseProxy, type ProxyRoute } from '../../shared/proxy';
import { API_TIMEOUT_MS } from '../api-timeout';
import { createRegistrationAwareRegistrar } from './namecom-registration';

// Routing a registrar account through the fixed IP proxy.
//
// registrar-client takes a `fetch`, so every provider uses the same path: the
// library builds the request exactly as it would for a direct connection, and
// this module hands it to the host's tunnel instead of the network. Retries,
// timeouts, error types and redaction are therefore identical either way.

export const MAX_PROXY_RESPONSE_BYTES = 2 * 1024 * 1024;

/** A host's way of making one HTTPS request through a CONNECT proxy. Desktop
 * uses https-proxy-agent; the Worker uses tunnelfetch over cloudflare:sockets.
 * A failure before the tunnel carries the request should reject with a
 * `ProxyStageError` (or any error whose `code` starts with `PROXY_`). */
export type ProxyFetch = (
  proxy: ProxyRoute,
  url: string,
  init: RequestInit,
) => Promise<Response>;

// A host supplies a transport, never a shared open socket.
let transport: ProxyFetch | undefined;
let requestPolicy:
  | ((
      proxy: ProxyRoute,
      registrar?: RegistrarName,
    ) => Pick<RegistrarOptions, 'timeout' | 'retries'>)
  | undefined;
export function configureProxyTransport(
  next?: ProxyFetch,
  policy?: typeof requestPolicy,
): void {
  transport = next;
  requestPolicy = policy;
}
export function getProxyTransport(): ProxyFetch | undefined {
  return transport;
}

export function proxyRequestTimeout(
  proxy: ProxyRoute,
  fallback: number,
): number {
  return requestPolicy?.(proxy).timeout ?? fallback;
}

/** The tunnel was never established, so the registrar never saw the request. */
export class ProxyStageError extends Error {
  constructor(
    public readonly code:
      | 'PROXY_UNREACHABLE'
      | 'PROXY_AUTH_FAILED'
      | 'PROXY_CONNECT_REFUSED'
      | 'PROXY_PROTOCOL',
    detail?: string,
  ) {
    super(detail ?? code);
    this.name = 'ProxyStageError';
  }
}

// Failure codes (ours and tunnelfetch's) that can only occur before the request
// is written: reaching or authenticating to the proxy, and verifying the
// registrar's certificate inside the tunnel. Anything mid-stream is left out;
// for those the library assumes the request may have arrived.
const BEFORE_SEND =
  /^(PROXY_|CERT_|OCSP_|CONFIG_|TLS_HANDSHAKE$|TLS_(VERSION|CIPHER|GROUP|SIGALG|EXTENSION)_UNSUPPORTED$)/;

function codeOf(error: unknown): string {
  return error && typeof error === 'object' && 'code' in error
    ? String(error.code)
    : '';
}

// Keep only known diagnostic codes across registrar-client's Error-to-message
// boundary. Never retain the proxy's response, URL, or arbitrary error detail.
const PROXY_FAILURES: Record<string, string> = {
  PROXY_CONNECT_REFUSED: 'The fixed-IP proxy refused the connection',
  PROXY_AUTH_FAILED: 'The fixed-IP proxy rejected authentication',
  PROXY_AUTH_REQUIRED: 'The fixed-IP proxy requires authentication',
  PROXY_UNREACHABLE: 'The fixed-IP proxy could not be reached',
  PROXY_PROTOCOL: 'The fixed-IP proxy returned an invalid CONNECT reply',
  PROXY_QUEUE_BUSY:
    'The shared registrar connection is busy. Try syncing again shortly',
  PROXY_QUEUE_TIMEOUT:
    'The shared registrar connection is busy. Try syncing again shortly',
  PROXY_QUEUE_CANCELLED: 'The queued registrar request was cancelled',
  PROXY_QUEUE_UNAVAILABLE:
    'The shared registrar connection scheduler is unavailable',
  TIMEOUT_CONNECT: 'Connecting to the fixed-IP proxy timed out',
  TIMEOUT_HANDSHAKE: 'The TLS handshake through the fixed-IP proxy timed out',
  TIMEOUT_HEADERS:
    'Waiting for response headers through the fixed-IP proxy timed out',
  TIMEOUT_IDLE: 'The response through the fixed-IP proxy stalled',
  TIMEOUT_TOTAL:
    'The request through the fixed-IP proxy exceeded its time limit',
};

function proxyFailureTag(error: unknown): string {
  const code = codeOf(error);
  if (!Object.hasOwn(PROXY_FAILURES, code)) return '';
  const detail =
    error && typeof error === 'object' && 'detail' in error
      ? error.detail
      : undefined;
  const status =
    detail && typeof detail === 'object' && 'status' in detail
      ? detail.status
      : undefined;
  const http =
    code.startsWith('PROXY_') &&
    typeof status === 'number' &&
    Number.isInteger(status) &&
    status >= 100 &&
    status <= 599
      ? `:${status}`
      : '';
  return ` [proxy:${code}${http}]`;
}

export function proxyFailureMessage(message: string): string | null {
  const match = message.match(/\[proxy:([A-Z_]+)(?::([1-5]\d\d))?\]$/);
  if (!match || !Object.hasOwn(PROXY_FAILURES, match[1])) return null;
  const summary =
    PROXY_FAILURES[match[1]] + (match[2] ? ` (HTTP ${match[2]})` : '');
  return (
    summary +
    (match[1].startsWith('PROXY_') ? '. The registrar was not contacted.' : '.')
  );
}

/** A proxy-stage failure in words the user can act on. Never includes the
 * proxy URL or the transport's own message, either of which may hold secrets. */
function proxyStageMessage(code: string): string {
  if (code.startsWith('PROXY_AUTH'))
    return 'The proxy rejected the username or password. Check Settings → Proxy.';
  if (code === 'PROXY_CONNECT_REFUSED')
    return 'The proxy refused to open a connection to the registrar.';
  if (code === 'PROXY_UNREACHABLE')
    return 'Could not reach the proxy. Check its address and port in Settings → Proxy.';
  if (code === 'PROXY_PROTOCOL')
    return 'The proxy gave an invalid reply. It may not be an HTTP CONNECT proxy.';
  if (code.startsWith('CERT_') || code.startsWith('OCSP_'))
    return 'A certificate could not be verified through the proxy.';
  return 'The proxy connection could not be set up.';
}

/**
 * One request through the proxy. Proxy-stage failures come back as a clear
 * message marked "not sent", which the library retries for any call, reads and
 * writes alike, since the registrar cannot have acted on them. Other failures
 * pass through untouched for the library to classify.
 */
export async function sendThroughProxy(
  proxy: ProxyRoute,
  url: string,
  init: RequestInit,
): Promise<Response> {
  const send = transport;
  // Never fall back to a direct request from an address nobody whitelisted.
  if (!send)
    throw markNotSent(new Error('The fixed IP proxy is not available here.'));
  try {
    return await send(proxy, url, init);
  } catch (error) {
    // The caller's own cancellation or timeout: let the library see it as such.
    if (error instanceof Error && error.name === 'AbortError') throw error;
    const code = codeOf(error);
    const diagnostic = proxyFailureTag(error);
    if (BEFORE_SEND.test(code))
      throw markNotSent(
        Object.assign(new Error(proxyStageMessage(code) + diagnostic), {
          code,
        }),
      );
    // Anything else keeps only its code. A transport's message can quote the
    // proxy URL, and this must be safe even where no redaction wraps it. The
    // code still lets the library spot a failure that preceded sending.
    throw Object.assign(
      new Error(`The connection through the proxy failed.${diagnostic}`),
      code ? { code } : {},
    );
  }
}

/**
 * A fetch whose every request goes through `proxy`, pinned to one API origin:
 * the client only ever calls that host, so anything else is a bug or an attack
 * and is refused rather than tunnelled. `origin` is read per request because
 * a registrar's is known only once its client is built.
 */
export function pinnedProxyFetch(
  proxy: ProxyRoute,
  origin: () => string,
  displayName: string,
): typeof globalThis.fetch {
  return (input, init) => {
    const target = new URL(
      typeof input === 'string'
        ? input
        : input instanceof URL
          ? input.href
          : input.url,
    );
    if (
      !origin() ||
      target.origin !== origin() ||
      target.protocol !== 'https:' ||
      target.username ||
      target.password
    )
      return Promise.reject(
        new Error(`Proxy requests are restricted to the ${displayName} API.`),
      );
    const headers = new Headers(init?.headers);
    // The desktop tunnel doesn't decompress.
    headers.set('Accept-Encoding', 'identity');
    return sendThroughProxy(proxy, target.href, {
      ...init,
      headers,
      redirect: 'manual',
    });
  };
}

/**
 * A provider whose every request goes through `route`, pinned to its own API
 * origin.
 */
export function createProxiedRegistrar(
  name: RegistrarName,
  credentials: RegistrarCredentials,
  route: ProxyRoute,
  /** Wraps the proxied fetch: a Dynadot key's shared pacing. */
  pace?: ((fetch: typeof globalThis.fetch) => typeof globalThis.fetch) | null,
): Registrar {
  const proxy = parseProxy({ url: route.url, egressIp: route.ip });
  if (!proxy) throw new Error('Configure the proxy URL and outgoing IP.');
  if (!transport) throw new Error('The fixed IP proxy is not available here.');
  const displayName = registrars[name].displayName;
  let apiOrigin = '';

  const fetch = pinnedProxyFetch(proxy, () => apiOrigin, displayName);

  const provider = createRegistrationAwareRegistrar(
    name,
    // Through the proxy, its outgoing address is the Client IP Namecheap sees.
    name === 'namecheap' ? { ...credentials, clientIp: proxy.ip } : credentials,
    {
      timeout: API_TIMEOUT_MS,
      ...requestPolicy?.(proxy, name),
      fetch: pace ? pace(fetch) : fetch,
    } satisfies RegistrarOptions,
  );
  const baseUrl = (
    provider as unknown as { http?: { config?: { baseUrl?: string } } }
  ).http?.config?.baseUrl;
  if (!baseUrl)
    throw new Error(`Cannot determine the ${displayName} API address.`);
  apiOrigin = new URL(baseUrl).origin;
  return provider;
}
