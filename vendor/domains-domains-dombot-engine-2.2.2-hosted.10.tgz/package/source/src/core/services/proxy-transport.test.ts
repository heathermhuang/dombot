import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  OutcomeUnknownError,
  registrars,
  type HttpClient,
  type RegistrarName,
} from '@aoxborrow/registrar-client';
import {
  configureProxyTransport,
  sendThroughProxy,
  createProxiedRegistrar,
  pinnedProxyFetch,
  ProxyStageError,
  type ProxyFetch,
} from './proxy-transport';
import {
  configureStore,
  flushWrites,
  hydrateStores,
} from '../storage/namespace';
import { MemoryDocStore } from '../storage/doc-store';
import { aesGcmCipher, EncryptedDocStore } from '../storage/encrypted';
import { exportBundle, importBundle } from '../storage/bundle';
import { getStoredCredentials, setStoredCredentials } from './credentials';
import { listAccounts } from './accounts';
import { configureManagedProxy } from './managed-proxy';
import {
  getProxyProfile,
  getProxySettings,
  listProxyProfiles,
  migrateLegacyProxies,
  removeProxyProfile,
  saveProxyProfile,
  testProxy,
} from './proxies';
import {
  connectRegistrarAccount,
  getRegistrarClient,
  getRegistrarMetadata,
  getMergedPortfolio,
  resetRegistrarClients,
  saveRegistrarCredentials,
  syncRegistrar,
  testRegistrarAccount,
} from './registrars';

const credentials = {
  username: 'test-user',
  apiKey: 'api-secret',
  clientIp: '9.9.9.9',
};
const proxy = {
  url: 'https://proxy-user:proxy-secret@8.8.8.8:8080/',
  ip: '8.8.4.4',
};
const configured = { ...credentials, proxyUrl: proxy.url, proxyIp: proxy.ip };
const xml =
  '<ApiResponse Status="OK"><CommandResponse><DomainGetListResult><Domain ID="1" Name="example.test" Created="01/01/2020" Expires="01/01/2030" /></DomainGetListResult><Paging><TotalItems>1</TotalItems><CurrentPage>1</CurrentPage><PageSize>100</PageSize></Paging></CommandResponse></ApiResponse>';
const transport = vi.fn<ProxyFetch>();
beforeEach(async () => {
  configureManagedProxy();
  configureStore(new MemoryDocStore());
  await hydrateStores();
  resetRegistrarClients();
  transport.mockReset();
  configureProxyTransport(transport);
});
afterEach(() => {
  configureManagedProxy();
  configureProxyTransport();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

it('returns only proxy connection metadata for registrar setup', async () => {
  await saveProxyProfile({ url: proxy.url, egressIp: proxy.ip });
  expect(getProxySettings(true).proxy).toEqual({ url: '', egressIp: proxy.ip });
  expect(JSON.stringify(getProxySettings(true))).not.toContain('proxy-secret');
  expect(getProxySettings().proxy?.url).toBe(proxy.url);
});

const porkbunCreds = { apiKey: 'pk-secret', secretApiKey: 'sk-secret' };
const ok = () => Promise.resolve(new Response(xml));

/** Connects and returns the new account, failing the test if the registrar
 *  turned the credentials down. */
async function connectAccount(
  ...args: Parameters<typeof connectRegistrarAccount>
) {
  const result = await connectRegistrarAccount(...args);
  if (!result.success) throw new Error(result.message);
  return result.account;
}

describe('proxied registrar transport', () => {
  it('preserves the hosted queue budget over the upstream 90-second default', async () => {
    vi.useFakeTimers();
    configureProxyTransport(transport, () => ({ timeout: 155000, retries: 0 }));
    transport.mockImplementation(
      (_route, _url, init) =>
        new Promise((resolve, reject) => {
          const timer = setTimeout(() => resolve(new Response(xml)), 95000);
          init.signal?.addEventListener(
            'abort',
            () => {
              clearTimeout(timer);
              reject(new DOMException('Aborted', 'AbortError'));
            },
            { once: true },
          );
        }),
    );
    const pending = createProxiedRegistrar(
      'namecheap',
      credentials,
      proxy,
    ).listDomains();
    await vi.advanceTimersByTimeAsync(95001);
    await expect(pending).resolves.toMatchObject([
      { domainName: 'example.test' },
    ]);
    expect(transport).toHaveBeenCalledOnce();
  });

  it('allows a queued proxy connection test to wait beyond its ordinary probe deadline', async () => {
    vi.useFakeTimers();
    configureProxyTransport(transport, () => ({ timeout: 155000, retries: 0 }));
    transport.mockImplementation(
      (_route, _url, init) =>
        new Promise((resolve, reject) => {
          const timer = setTimeout(
            () => resolve(new Response('ip=' + proxy.ip + '\n')),
            16000,
          );
          init.signal?.addEventListener(
            'abort',
            () => {
              clearTimeout(timer);
              reject(new DOMException('Aborted', 'AbortError'));
            },
            { once: true },
          );
        }),
    );
    const pending = testProxy({ url: proxy.url, egressIp: proxy.ip });
    await vi.advanceTimersByTimeAsync(16001);
    await expect(pending).resolves.toMatchObject({
      matches: true,
      ip: proxy.ip,
    });
  });
  it('budgets queue waiting separately and never replays a scheduled write after an unknown outcome', async () => {
    configureProxyTransport(transport, () => ({ timeout: 155000, retries: 0 }));
    transport.mockRejectedValue(new Error('connection dropped after sending'));
    const error = await createProxiedRegistrar('namecheap', credentials, proxy)
      .renewDomain('example.test', 1)
      .catch((e: Error) => e);
    expect(error).toBeInstanceOf(OutcomeUnknownError);
    expect(transport).toHaveBeenCalledOnce();
  });
  it('identifies a cancelled queue wait as never sent, without exposing private details', async () => {
    configureProxyTransport(transport, () => ({ timeout: 155000, retries: 0 }));
    transport.mockRejectedValue(
      Object.assign(new Error(proxy.url), { code: 'PROXY_QUEUE_CANCELLED' }),
    );
    const error = await createProxiedRegistrar('namecheap', credentials, proxy)
      .renewDomain('example.test', 1)
      .catch((e: Error) => e);
    expect(error).not.toBeInstanceOf(OutcomeUnknownError);
    expect((error as Error).message).toContain('[proxy:PROXY_QUEUE_CANCELLED]');
    expect((error as Error).message).not.toContain('proxy-secret');
    expect(transport).toHaveBeenCalledOnce();
  });
  it('preserves the proxy refusal status without exposing its response or credentials', async () => {
    transport.mockRejectedValue(
      Object.assign(new Error(`Forbidden ${proxy.url}`), {
        code: 'PROXY_CONNECT_REFUSED',
        detail: { status: 403, reason: 'private response', proxy: proxy.url },
      }),
    );
    const error = await sendThroughProxy(
      proxy,
      'https://api.dynadot.com/restful/v2/domains',
      {},
    ).catch((e: Error) => e);
    expect(error).toBeInstanceOf(Error);
    expect((error as Error).message).toContain(
      '[proxy:PROXY_CONNECT_REFUSED:403]',
    );
    expect((error as Error).message).not.toMatch(
      /proxy-secret|private response/,
    );
  });

  it('retains a typed timeout but never arbitrary transport detail', async () => {
    transport.mockRejectedValue(
      Object.assign(new Error(proxy.url), {
        code: 'TIMEOUT_TOTAL',
        detail: { status: 'secret-status' },
      }),
    );
    await expect(
      sendThroughProxy(proxy, 'https://api.dynadot.com/', {}),
    ).rejects.toThrow('[proxy:TIMEOUT_TOTAL]');
  });
  it('rejects a private proxy endpoint and never tunnels an off-origin request', async () => {
    expect(() =>
      createProxiedRegistrar('namecheap', credentials, {
        ...proxy,
        url: 'http://127.0.0.1:8080',
      }),
    ).toThrow(/public/);
    const provider = createProxiedRegistrar('namecheap', credentials, proxy);
    const http = (provider as unknown as { http: HttpClient }).http;
    await expect(
      http.requestText({
        path: 'https://elsewhere.example/xml.response',
        query: { ApiKey: 'api-secret' },
        retries: 0,
      }),
    ).rejects.toThrow(/restricted to the Namecheap API/);
    expect(transport).not.toHaveBeenCalled();
  });

  it('pins every registrar to its own API origin', () => {
    for (const name of Object.keys(registrars) as RegistrarName[]) {
      const fields = Object.fromEntries(
        registrars[name].configFields.map((f) => [f.name, 'x']),
      );
      expect(() => createProxiedRegistrar(name, fields, proxy)).not.toThrow();
    }
  });

  it('routes Namecheap through the proxy with the proxy address as ClientIp, leaving the credentials alone', async () => {
    transport.mockImplementation(ok);
    vi.stubGlobal(
      'fetch',
      vi.fn(() => {
        throw new Error('direct fetch used');
      }),
    );
    const domains = await createProxiedRegistrar(
      'namecheap',
      credentials,
      proxy,
    ).listDomains();
    expect(domains.map((d) => d.domainName)).toEqual(['example.test']);
    const [selected, url, init] = transport.mock.calls[0];
    expect(selected).toEqual(proxy);
    const request = new URL(url);
    expect(request.origin + request.pathname).toBe(
      'https://api.namecheap.com/xml.response',
    );
    expect(request.searchParams.get('ClientIp')).toBe(proxy.ip);
    expect(init.redirect).toBe('manual');
    expect(new Headers(init.headers).get('accept-encoding')).toBe('identity');
    expect(credentials.clientIp).toBe('9.9.9.9');
  });

  it('routes any other registrar the same way, as the registrar  own request', async () => {
    transport.mockImplementation(() =>
      Promise.resolve(Response.json({ status: 'SUCCESS', yourIp: proxy.ip })),
    );
    const native = vi.fn<typeof fetch>();
    vi.stubGlobal('fetch', native);
    const result = await createProxiedRegistrar(
      'porkbun',
      porkbunCreds,
      proxy,
    ).testConnection();
    expect(result.success).toBe(true);
    expect(native).not.toHaveBeenCalled();
    const [selected, url, init] = transport.mock.calls[0];
    expect(selected).toEqual(proxy);
    expect(new URL(url).origin).toBe('https://api.porkbun.com');
    expect(init.method).toBe('POST');
    expect(String(init.body)).toContain('pk-secret');
  });

  it('retries a transient read', async () => {
    transport
      .mockResolvedValueOnce(new Response('private response', { status: 503 }))
      .mockResolvedValueOnce(new Response('', { status: 503 }))
      .mockImplementationOnce(ok);
    await expect(
      createProxiedRegistrar('namecheap', credentials, proxy).listDomains({
        backoff: 0,
        retries: 2,
      }),
    ).resolves.toHaveLength(1);
    expect(transport).toHaveBeenCalledTimes(3);
  });

  it.each(['http', 'network'])(
    'sends a renewal once and reports an unknown outcome after a %s failure, even though Namecheap uses GET',
    async (kind) => {
      if (kind === 'http')
        transport.mockImplementation(() =>
          Promise.resolve(new Response('upstream', { status: 500 })),
        );
      else transport.mockRejectedValue(new Error(`reset by ${proxy.url}`));
      const error = await createProxiedRegistrar(
        'namecheap',
        credentials,
        proxy,
      )
        .renewDomain('example.test', 1, { retries: 5, backoff: 0 })
        .catch((e: unknown) => e);
      expect(error).toBeInstanceOf(OutcomeUnknownError);
      expect((error as Error).message).not.toContain('proxy-secret');
      expect(transport).toHaveBeenCalledTimes(1);
      expect(transport.mock.calls[0][2].method).toBe('GET');
    },
  );

  it.each([
    ['PROXY_AUTH_FAILED', /rejected the username or password/],
    ['PROXY_UNREACHABLE', /Could not reach the proxy/],
    ['PROXY_CONNECT_REFUSED', /refused to open a connection/],
    ['CERT_NAME_MISMATCH', /certificate could not be verified/],
  ])(
    'treats %s as never sent: retried even for a write, reported in plain words without the transport message',
    async (code, message) => {
      transport.mockRejectedValue(
        Object.assign(new Error(`failed for ${proxy.url}`), { code }),
      );
      const error = await createProxiedRegistrar(
        'namecheap',
        credentials,
        proxy,
      )
        .renewDomain('example.test', 1, { retries: 2, backoff: 0 })
        .catch((e: unknown) => e);
      expect(transport).toHaveBeenCalledTimes(3);
      expect(error).not.toBeInstanceOf(OutcomeUnknownError);
      expect((error as Error).message).toMatch(message);
      expect((error as Error).message).not.toMatch(/proxy-secret|proxy-user/);
    },
  );

  it('recognizes a desktop tunnel that never opened', async () => {
    transport.mockRejectedValue(
      new ProxyStageError(
        'PROXY_AUTH_FAILED',
        'proxy answered CONNECT with 407',
      ),
    );
    const result = await createProxiedRegistrar(
      'porkbun',
      porkbunCreds,
      proxy,
    ).testConnection({ retries: 0 });
    expect(result).toMatchObject({ success: false });
    expect(result.message).toMatch(/rejected the username or password/);
  });

  it.each([302, 401, 403])(
    'fails closed for HTTP %s without following redirects',
    async (status) => {
      transport.mockImplementation(() =>
        Promise.resolve(
          new Response('upstream body', {
            status,
            headers: { location: 'https://other.example' },
          }),
        ),
      );
      const result = await createProxiedRegistrar(
        'namecheap',
        credentials,
        proxy,
      ).testConnection({ retries: 0 });
      expect(result.success).toBe(false);
      expect(transport).toHaveBeenCalledTimes(1);
      expect(transport.mock.calls[0][2].redirect).toBe('manual');
    },
  );

  it('does not send an already-cancelled request', async () => {
    const controller = new AbortController();
    controller.abort();
    await expect(
      createProxiedRegistrar('namecheap', credentials, proxy).listDomains({
        signal: controller.signal,
      }),
    ).rejects.toThrow(/aborted/);
    expect(transport).not.toHaveBeenCalled();
  });

  it('aborts a timed-out transport and reports a timeout, not the transport exception', async () => {
    vi.useFakeTimers();
    transport.mockImplementation(
      (_proxy, _url, init) =>
        new Promise((_resolve, reject) => {
          init.signal?.addEventListener(
            'abort',
            () =>
              reject(
                Object.assign(new Error('proxy-secret'), {
                  name: 'AbortError',
                }),
              ),
            { once: true },
          );
        }),
    );
    const pending = createProxiedRegistrar(
      'namecheap',
      credentials,
      proxy,
    ).listDomains({ timeout: 10, retries: 0 });
    const assertion = expect(pending).rejects.toThrow(/timed out/);
    await vi.advanceTimersByTimeAsync(20);
    await assertion;
    expect(transport.mock.calls[0][2].signal?.aborted).toBe(true);
    expect(transport).toHaveBeenCalledOnce();
  });

  it('never falls back to direct networking when the host transport is missing', () => {
    configureProxyTransport();
    expect(() =>
      createProxiedRegistrar('namecheap', credentials, proxy),
    ).toThrow(/not available/);
  });
});

const profile = { url: proxy.url, egressIp: proxy.ip };
// An account with no address of its own: only the proxy makes it usable.
const proxyOnly = {
  username: credentials.username,
  apiKey: credentials.apiKey,
};
const namecheapMeta = () =>
  getRegistrarMetadata().find((r) => r.name === 'namecheap')!;

describe('host-managed registrar defaults', () => {
  beforeEach(() => {
    configureManagedProxy(proxy.url, proxy.ip);
    transport.mockImplementation(ok);
  });

  it('connects without a client IP or customer proxy and keeps host credentials out of exports', async () => {
    const connection = await connectRegistrarAccount('namecheap', {
      username: credentials.username,
      apiKey: credentials.apiKey,
    });
    expect(connection.success).toBe(true);
    if (!connection.success) throw new Error(connection.message);
    const account = connection.account;
    expect(account.proxyId).toBeUndefined();
    expect(transport).toHaveBeenCalled();
    expect(transport.mock.calls[0][0]).toEqual(proxy);
    expect(
      new URL(String(transport.mock.calls[0][1])).searchParams.get('ClientIp'),
    ).toBe(proxy.ip);
    const meta = getRegistrarMetadata().find(
      (r) => r.accountId === account.id,
    )!;
    expect(meta).toMatchObject({
      configured: true,
      proxy: true,
      proxyManaged: true,
      proxyEgressIp: proxy.ip,
    });
    expect(getProxySettings()).toMatchObject({
      proxy: null,
      managed: { egressIp: proxy.ip },
      users: [],
    });
    const publicData = JSON.stringify([
      getProxySettings(),
      getRegistrarMetadata(),
      getStoredCredentials(account.id),
    ]);
    const backup = exportBundle({ version: 'test', platform: 'web' });
    for (const data of [publicData, backup])
      expect(data).not.toMatch(/proxy-secret|proxy-user/);
    expect(backup).not.toContain(proxy.url);
  });

  it('uses a customer override, and returns to the managed default when it is removed', async () => {
    const custom = {
      url: 'https://own:password@1.1.1.1:8080/',
      egressIp: '1.0.0.1',
    };
    await saveProxyProfile(custom);
    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    await getRegistrarClient('namecheap').listDomains();
    expect(transport.mock.calls.at(-1)?.[0].ip).toBe(custom.egressIp);
    expect(namecheapMeta().proxyManaged).toBe(false);
    await removeProxyProfile();
    await getRegistrarClient('namecheap').listDomains();
    expect(transport.mock.calls.at(-1)?.[0].ip).toBe(proxy.ip);
    expect(namecheapMeta().proxyManaged).toBe(true);
  });

  it('keeps Dynadot on the managed route after removing an override, without exporting host secrets', async () => {
    transport.mockImplementation(() =>
      Promise.resolve(Response.json({ code: 200, data: {} })),
    );
    await saveProxyProfile({
      url: 'https://own:password@1.1.1.1:8080/',
      egressIp: '1.0.0.1',
    });
    await saveRegistrarCredentials(
      'dynadot',
      { apiKey: 'dynadot-key', apiSecret: 'dynadot-secret' },
      undefined,
      true,
    );
    await getRegistrarClient('dynadot').testConnection();
    expect(transport.mock.calls.at(-1)?.[0].ip).toBe('1.0.0.1');
    await removeProxyProfile();
    expect(await getRegistrarClient('dynadot').testConnection()).toMatchObject({
      success: true,
    });
    expect(transport.mock.calls.at(-1)?.[0]).toEqual(proxy);
    expect(
      getRegistrarMetadata().find((r) => r.name === 'dynadot'),
    ).toMatchObject({
      proxyManaged: true,
      proxyEgressIp: proxy.ip,
    });
    expect(exportBundle({ version: 'test', platform: 'web' })).not.toContain(
      proxy.url,
    );
  });

  it.each(['namecheap', 'dynadot'] as const)(
    'tests the managed %s route without changing the working override or saved credentials',
    async (name) => {
      const creds =
        name === 'namecheap'
          ? credentials
          : { apiKey: 'dynadot-key', apiSecret: 'dynadot-secret' };
      const direct = vi.fn();
      vi.stubGlobal('fetch', direct);
      await saveProxyProfile({
        url: 'https://own:password@1.1.1.1:8080/',
        egressIp: '1.0.0.1',
      });
      await saveRegistrarCredentials(name, creds, undefined, true);
      const client = getRegistrarClient(name);
      const saved = JSON.stringify([
        listAccounts(),
        getProxySettings(),
        getStoredCredentials(name),
      ]);
      transport.mockImplementation(() =>
        Promise.resolve(
          name === 'namecheap'
            ? new Response(xml)
            : Response.json({ code: 200, data: {} }),
        ),
      );
      expect(await testRegistrarAccount(name, name, true)).toMatchObject({
        success: true,
      });
      expect(transport.mock.calls.at(-1)?.[0]).toEqual(proxy);
      if (name === 'namecheap')
        expect(
          new URL(String(transport.mock.calls.at(-1)?.[1])).searchParams.get(
            'ClientIp',
          ),
        ).toBe(proxy.ip);
      transport.mockRejectedValue(
        new ProxyStageError('PROXY_AUTH_FAILED', proxy.url),
      );
      const failed = await testRegistrarAccount(name, name, true);
      expect(failed.success).toBe(false);
      expect(JSON.stringify(failed)).not.toMatch(/proxy-secret|proxy-user/);
      expect(direct).not.toHaveBeenCalled();
      expect(
        JSON.stringify([
          listAccounts(),
          getProxySettings(),
          getStoredCredentials(name),
        ]),
      ).toBe(saved);
      expect(getRegistrarClient(name)).toBe(client);
    },
  );

  it('rejects a managed test when the route is unavailable, without falling back to the override', async () => {
    await saveRegistrarCredentials('namecheap', credentials);
    configureManagedProxy();
    await expect(
      testRegistrarAccount('namecheap', undefined, true),
    ).rejects.toThrow(/No managed connection/);
    expect(transport).not.toHaveBeenCalled();
  });

  it('does not route other providers or create an empty customer proxy reference', async () => {
    expect(
      getRegistrarMetadata().find((r) => r.name === 'porkbun')?.proxy,
    ).toBe(false);
    await expect(
      saveRegistrarCredentials('namecheap', credentials, undefined, true),
    ).rejects.toThrow(/Settings → Proxy/);
    expect(listProxyProfiles()).toEqual([]);
  });

  it('redacts managed credentials and never falls back to direct traffic after a proxy failure', async () => {
    const direct = vi.fn();
    vi.stubGlobal('fetch', direct);
    transport.mockRejectedValue(
      new ProxyStageError('PROXY_AUTH_FAILED', proxy.url),
    );
    await saveRegistrarCredentials('namecheap', credentials);
    const result = await getRegistrarClient('namecheap').testConnection({
      retries: 0,
    });
    expect(result.success).toBe(false);
    expect(JSON.stringify(result)).not.toMatch(/proxy-secret|proxy-user/);
    expect(direct).not.toHaveBeenCalled();
  });

  it('rebuilds cached clients after host rotation and leaves self-hosted routing unchanged when disabled', async () => {
    await saveRegistrarCredentials('namecheap', credentials);
    const client = getRegistrarClient('namecheap');
    configureManagedProxy(proxy.url, '1.0.0.1');
    expect(getRegistrarClient('namecheap')).not.toBe(client);
    await getRegistrarClient('namecheap').listDomains();
    expect(transport.mock.calls.at(-1)?.[0].ip).toBe('1.0.0.1');
    configureManagedProxy();
    expect(namecheapMeta()).toMatchObject({
      proxy: false,
      proxyManaged: false,
    });
    expect(getProxySettings().managed).toBeNull();
  });

  it('fails with a safe error for partial or invalid host configuration', () => {
    for (const [url, ip] of [
      [proxy.url, ''],
      ['', proxy.ip],
      ['https://private:secret@127.0.0.1:80', proxy.ip],
    ]) {
      expect(() => configureManagedProxy(url, ip)).toThrow(
        'The managed registrar connection is not configured correctly.',
      );
    }
  });
});

describe('pinned proxy fetch', () => {
  const route = { url: 'https://u:p@8.8.8.8:8080', ip: '8.8.4.4' };
  const pinned = () =>
    pinnedProxyFetch(route, () => 'https://api.sedo.com', 'Sedo');

  it('refuses any other host and never reaches the tunnel', async () => {
    await expect(pinned()('https://evil.example/x')).rejects.toThrow(
      /restricted to the Sedo API/,
    );
    await expect(pinned()('http://api.sedo.com/x')).rejects.toThrow(
      /restricted/,
    );
  });

  it('asks for an uncompressed answer and follows no redirects', async () => {
    const send = vi.fn<ProxyFetch>(async () => new Response('ok'));
    configureProxyTransport(send);
    await pinned()('https://api.sedo.com/api/v1/x', { method: 'POST' });
    configureProxyTransport();
    const [proxy, url, init] = send.mock.calls[0];
    expect(proxy).toBe(route);
    expect(url).toBe('https://api.sedo.com/api/v1/x');
    expect(init.redirect).toBe('manual');
    expect(new Headers(init.headers).get('accept-encoding')).toBe('identity');
  });
});

describe('central proxy settings', () => {
  it('validates before saving and switches the proxy off for its accounts on removal', async () => {
    await expect(
      saveProxyProfile({ ...profile, egressIp: '127.0.0.1' }),
    ).rejects.toThrow(/public/);
    expect(getProxyProfile()).toBeNull();
    await saveProxyProfile(profile);
    expect(getProxySettings()).toEqual({
      proxy: profile,
      managed: null,
      users: [],
      marketUsers: [],
    });

    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    expect(getProxySettings().users).toEqual([
      {
        accountId: 'namecheap',
        registrar: 'namecheap',
        label: 'Default',
        hasSiblings: false,
      },
    ]);
    // Removing the proxy while an account still uses it clears it from that
    // account rather than refusing.
    await removeProxyProfile();
    expect(getProxyProfile()).toBeNull();
    expect(getProxySettings().users).toEqual([]);
  });

  it('cannot be switched on for an account before a proxy exists, and changes nothing when refused', async () => {
    await saveRegistrarCredentials('namecheap', credentials);
    await expect(
      saveRegistrarCredentials(
        'namecheap',
        { ...credentials, apiKey: 'changed' },
        undefined,
        true,
      ),
    ).rejects.toThrow(/Settings → Proxy/);
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
    expect(namecheapMeta().proxy).toBe(false);
  });

  it('never puts the proxy back into the credentials of an account', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', configured, undefined, true);
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
  });

  it('can be switched on for any registrar, and that account then never connects directly', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('porkbun', porkbunCreds, undefined, true);
    const native = vi.fn<typeof fetch>();
    vi.stubGlobal('fetch', native);
    transport.mockImplementation(() =>
      Promise.resolve(Response.json({ status: 'SUCCESS' })),
    );
    expect((await getRegistrarClient('porkbun').testConnection()).success).toBe(
      true,
    );
    expect(transport).toHaveBeenCalledOnce();
    expect(native).not.toHaveBeenCalled();
    expect(getProxySettings().users.map((u) => u.registrar)).toEqual([
      'porkbun',
    ]);
  });

  it('reports the address seen through the proxy, falling back to a second service', async () => {
    transport.mockResolvedValueOnce(new Response('fl=1\nip=8.8.4.4\nts=1\n'));
    expect(await testProxy(profile)).toEqual({
      ip: '8.8.4.4',
      expected: '8.8.4.4',
      matches: true,
    });
    expect(transport.mock.calls[0][0]).toEqual(proxy);
    expect(new URL(transport.mock.calls[0][1]).hostname).toBe(
      'www.cloudflare.com',
    );

    transport.mockReset();
    transport
      .mockRejectedValueOnce(new Error('unreachable'))
      .mockResolvedValueOnce(Response.json({ ip: '1.2.3.4' }));
    expect(await testProxy(profile)).toMatchObject({
      ip: '1.2.3.4',
      matches: false,
    });
    expect(new URL(transport.mock.calls[1][1]).hostname).toBe('ipinfo.io');
  });

  it('tests unsaved values, rejects invalid ones without a request, and never echoes the password', async () => {
    await expect(
      testProxy({ url: 'http://10.0.0.1:8080', egressIp: proxy.ip }),
    ).rejects.toThrow(/public/);
    expect(transport).not.toHaveBeenCalled();
    transport.mockRejectedValue(
      new Error(`407 from ${proxy.url} for proxy-user:proxy-secret`),
    );
    const error = await testProxy(profile).catch((e: Error) => e);
    expect((error as Error).message).toMatch(/Could not connect/);
    expect((error as Error).message).not.toMatch(/proxy-secret|proxy-user/);
    expect(getProxyProfile()).toBeNull();
  });
});

describe('account persistence and routing', () => {
  it('does not route other registrars through the proxy transport', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('porkbun', {
      apiKey: 'test-key',
      secretApiKey: 'test-secret',
    });
    const native = vi
      .fn<typeof fetch>()
      .mockResolvedValue(Response.json({ status: 'SUCCESS' }));
    vi.stubGlobal('fetch', native);
    await getRegistrarClient('porkbun').testConnection();
    expect(native).toHaveBeenCalledOnce();
    expect(transport).not.toHaveBeenCalled();
  });

  it('seals the proxy at rest and carries it, with the toggle of each account, through export and import', async () => {
    const disk = new MemoryDocStore();
    configureStore(
      new EncryptedDocStore(
        disk,
        await aesGcmCipher(crypto.getRandomValues(new Uint8Array(32))),
      ),
    );
    await hydrateStores();
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    await flushWrites();
    expect(await disk.get('registrar-proxies', 'default')).toMatchObject({
      __sealed: 1,
    });
    expect(JSON.stringify(await disk.list('registrar-proxies'))).not.toContain(
      'proxy-secret',
    );
    const bundle = exportBundle({ version: 'test', platform: 'web' });
    expect(JSON.parse(bundle).version).toBe(18);

    configureStore(new MemoryDocStore());
    await hydrateStores();
    await importBundle(bundle);
    await flushWrites();
    await hydrateStores();
    expect(getProxyProfile()).toMatchObject(profile);
    expect(namecheapMeta()).toMatchObject({ configured: true, proxy: true });
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
  });

  it('rejects a bundle with a private-range proxy or an account pointing at a missing one', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    const good = JSON.parse(exportBundle({ version: 'test', platform: 'web' }));

    const privateProxy = structuredClone(good);
    privateProxy.namespaces['registrar-proxies'].default.url =
      'http://127.0.0.1:8080';
    await expect(importBundle(JSON.stringify(privateProxy))).rejects.toThrow(
      /public/,
    );
    const mismatched = structuredClone(good);
    mismatched.namespaces['registrar-proxies'].default.id = 'other';
    await expect(importBundle(JSON.stringify(mismatched))).rejects.toThrow(
      /Malformed/,
    );
    const dangling = structuredClone(good);
    delete dangling.namespaces['registrar-proxies'];
    await expect(importBundle(JSON.stringify(dangling))).rejects.toThrow(
      /does not contain/,
    );
    // Legacy per-account fields are still validated on the way in.
    const legacy = structuredClone(good);
    legacy.namespaces['registrar-credentials'].namecheap = {
      ...configured,
      proxyUrl: 'http://127.0.0.1:8080',
    };
    await expect(importBundle(JSON.stringify(legacy))).rejects.toThrow(
      /public/,
    );
    expect(getProxyProfile()).toMatchObject(profile);
  });

  it('supports a proxy-only account with no direct IP, and restores direct routing when switched off', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', proxyOnly, undefined, true);
    expect(namecheapMeta()).toMatchObject({ configured: true, proxy: true });
    // The proxy's address is supplied when the client is built, never stored
    // as though it were the user's own.
    expect(getStoredCredentials('namecheap').clientIp).toBeUndefined();
    transport.mockImplementation(() => Promise.resolve(new Response(xml)));
    const proxied = getRegistrarClient('namecheap');
    await proxied.listDomains();
    expect(
      new URL(transport.mock.calls[0][1]).searchParams.get('ClientIp'),
    ).toBe(proxy.ip);

    // Off without a direct IP: the account is incomplete, not silently direct.
    await saveRegistrarCredentials('namecheap', proxyOnly, undefined, false);
    expect(namecheapMeta()).toMatchObject({ configured: false, proxy: false });

    await saveRegistrarCredentials('namecheap', credentials, undefined, false);
    const direct = getRegistrarClient('namecheap');
    expect(direct).not.toBe(proxied);
    const native = vi.fn<typeof fetch>().mockResolvedValue(new Response(xml));
    vi.stubGlobal('fetch', native);
    transport.mockClear();
    await direct.testConnection();
    expect(native).toHaveBeenCalledOnce();
    expect(transport).not.toHaveBeenCalled();
  });

  it('rebuilds a proxied client when the proxy itself changes', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    const before = getRegistrarClient('namecheap');
    expect(getRegistrarClient('namecheap')).toBe(before);
    await saveProxyProfile({ ...profile, egressIp: '8.8.8.8' });
    expect(getRegistrarClient('namecheap')).not.toBe(before);
  });

  it('connects a new account through the proxy and records the toggle', async () => {
    await saveProxyProfile(profile);
    transport.mockImplementation(() => Promise.resolve(new Response(xml)));
    const account = await connectAccount(
      'namecheap',
      proxyOnly,
      'Agency',
      true,
    );
    expect(account.proxyId).toBe('default');
    expect(transport).toHaveBeenCalled();
    expect(getStoredCredentials(account.id)).toEqual(proxyOnly);
    await expect(
      connectRegistrarAccount('namecheap', proxyOnly, 'Direct', false),
    ).rejects.toThrow(/Client IP is required/);
  });

  it("answers a Dynadot key it doesn't accept yet with the 401, saving nothing", async () => {
    const native = vi.fn<typeof fetch>().mockResolvedValue(
      Response.json(
        {
          code: 401,
          message: 'Unauthorized',
          error: {
            description:
              'The provided API key is invalid, expired, or missing. Please verify your key is correct and active.',
          },
        },
        { status: 401, statusText: 'Unauthorized' },
      ),
    );
    vi.stubGlobal('fetch', native);
    await expect(
      connectRegistrarAccount('dynadot', {
        apiKey: 'new-key',
        apiSecret: 'new-secret',
      }),
    ).resolves.toEqual({
      success: false,
      message:
        'The provided API key is invalid, expired, or missing. Please verify your key is correct and active.',
      status: 401,
    });
    expect(native).toHaveBeenCalledOnce();
    expect(
      getRegistrarMetadata().filter((a) => a.name === 'dynadot' && a.saved),
    ).toEqual([]);
  });

  it('keeps the proxy password out of sync errors', async () => {
    await saveProxyProfile(profile);
    await saveRegistrarCredentials('namecheap', credentials, undefined, true);
    transport.mockRejectedValue(
      new Error(`tunnel to ${proxy.url} failed for proxy-secret`),
    );
    await syncRegistrar('namecheap');
    const text = JSON.stringify(getMergedPortfolio().errors);
    expect(text).not.toContain('proxy-secret');
    expect(getMergedPortfolio().errors).toHaveLength(1);
  });
});

describe('migration from per-account proxy fields', () => {
  it('lifts the proxy of a Namecheap account into the default profile, once', async () => {
    await setStoredCredentials('namecheap', configured);
    expect(await migrateLegacyProxies()).toBe(1);
    expect(getProxyProfile()).toMatchObject(profile);
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
    expect(namecheapMeta()).toMatchObject({ configured: true, proxy: true });
    expect(await migrateLegacyProxies()).toBe(0);
    expect(listProxyProfiles()).toHaveLength(1);
  });

  it('drops a Client IP that was only ever the address of the proxy', async () => {
    await setStoredCredentials('namecheap', {
      ...configured,
      clientIp: proxy.ip,
    });
    await migrateLegacyProxies();
    expect(getStoredCredentials('namecheap').clientIp).toBeUndefined();
    expect(namecheapMeta().configured).toBe(true);
  });

  it('shares one profile between accounts with the same proxy and keeps a different one working', async () => {
    await setStoredCredentials('namecheap', configured);
    transport.mockImplementation(() => Promise.resolve(new Response(xml)));
    // The two extra accounts connect directly; never reach the real API.
    vi.stubGlobal(
      'fetch',
      vi.fn(() => Promise.resolve(new Response(xml))),
    );
    await migrateLegacyProxies();
    const same = await connectAccount(
      'namecheap',
      { ...credentials, username: 'second' },
      'Second',
    );
    const other = await connectAccount(
      'namecheap',
      { ...credentials, username: 'third' },
      'Third',
    );
    await setStoredCredentials(same.id, {
      ...getStoredCredentials(same.id),
      proxyUrl: proxy.url,
      proxyIp: proxy.ip,
    });
    await setStoredCredentials(other.id, {
      ...getStoredCredentials(other.id),
      proxyUrl: 'http://9.9.9.9:3128',
      proxyIp: '9.9.9.10',
    });
    expect(await migrateLegacyProxies()).toBe(2);
    const byId = Object.fromEntries(listAccounts().map((a) => [a.id, a]));
    expect(byId[same.id].proxyId).toBe('default');
    expect(byId[other.id].proxyId).not.toBe('default');
    expect(listProxyProfiles()).toHaveLength(2);
    expect(getProxySettings().proxy).toEqual(profile);
    resetRegistrarClients();
    transport.mockClear();
    await getRegistrarClient('namecheap', other.id).listDomains();
    expect(transport.mock.calls[0][0]).toEqual({
      url: 'http://9.9.9.9:3128/',
      ip: '9.9.9.10',
    });
  });

  it('drops an invalid stored proxy instead of failing startup', async () => {
    await setStoredCredentials('namecheap', {
      ...configured,
      proxyUrl: 'http://127.0.0.1:8080',
    });
    expect(await migrateLegacyProxies()).toBe(1);
    expect(getProxyProfile()).toBeNull();
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
    expect(namecheapMeta().proxy).toBe(false);
  });

  it('migrates a version 2 bundle on import', async () => {
    await setStoredCredentials('namecheap', credentials);
    const bundle = JSON.parse(
      exportBundle({ version: 'test', platform: 'web' }),
    );
    // A real v2 file: pre-v4 names, the proxy still inside the credentials.
    bundle.version = 2;
    bundle.namespaces.credentials = {
      ...bundle.namespaces['registrar-credentials'],
      namecheap: configured,
    };
    delete bundle.namespaces['registrar-credentials'];
    await importBundle(JSON.stringify(bundle));
    expect(getProxyProfile()).toMatchObject(profile);
    expect(getStoredCredentials('namecheap')).toEqual(credentials);
    expect(namecheapMeta().proxy).toBe(true);
  });
});
