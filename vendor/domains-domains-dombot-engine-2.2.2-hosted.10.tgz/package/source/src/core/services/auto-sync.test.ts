import { beforeEach, describe, expect, it, vi } from 'vitest';

const getActiveRegistrars = vi.fn<() => string[]>();
const getCachedPortfolio = vi.fn<() => { fetchedAt: number | null } | null>();
const getPortfolio = vi.fn();
const retryDeferredSyncs = vi.fn();
vi.mock('./registrars', () => ({
  getActiveRegistrars: () => getActiveRegistrars(),
  getCachedPortfolio: () => getCachedPortfolio(),
  getPortfolio: (...a: unknown[]) => getPortfolio(...a),
  retryDeferredSyncs: async () => false,
}));
const isBulkRunning = vi.fn<() => boolean>();
vi.mock('./bulk-jobs', () => ({ isBulkRunning: () => isBulkRunning() }));
const broadcastPortfolioChanged = vi.fn();
vi.mock('../events', () => ({
  broadcastPortfolioChanged: () => broadcastPortfolioChanged(),
}));
const syncMarkets = vi.fn<(ifOlderThanMs?: number) => Promise<number>>();
vi.mock('./markets/sync', () => ({
  syncMarkets: (ms?: number) => syncMarkets(ms),
}));
vi.mock('./settings', () => ({
  getSettings: () => ({ autoSyncIntervalMinutes: 60 }),
}));

import { syncAll } from './auto-sync';

beforeEach(() => {
  vi.clearAllMocks();
  vi.useFakeTimers();
  vi.setSystemTime(Date.parse('2026-06-01T12:00:00Z'));
  getActiveRegistrars.mockReturnValue(['dynadot']);
  isBulkRunning.mockReturnValue(false);
  getCachedPortfolio.mockReturnValue({ fetchedAt: Date.now() - 30 * 60_000 });
  getPortfolio.mockResolvedValue({});
  syncMarkets.mockResolvedValue(0);
  retryDeferredSyncs.mockResolvedValue(false);
});

describe('syncAll', () => {
  it('syncs and notifies', async () => {
    expect(await syncAll()).toBe(true);
    expect(getPortfolio).toHaveBeenCalledWith(true, 'scheduled');
    expect(broadcastPortfolioChanged).toHaveBeenCalledTimes(1);
  });

  it('skips with nothing configured or a bulk job running', async () => {
    getActiveRegistrars.mockReturnValue([]);
    expect(await syncAll()).toBe(false);
    getActiveRegistrars.mockReturnValue(['dynadot']);
    isBulkRunning.mockReturnValue(true);
    expect(await syncAll()).toBe(false);
    expect(getPortfolio).not.toHaveBeenCalled();
  });

  it('syncs market accounts too, with or without registrars', async () => {
    getActiveRegistrars.mockReturnValue([]);
    syncMarkets.mockResolvedValue(1);
    expect(await syncAll(60_000)).toBe(true);
    expect(syncMarkets).toHaveBeenCalledWith(60_000);
    expect(getPortfolio).not.toHaveBeenCalled();
  });

  it('honors ifOlderThanMs: fresh cache → no sync; stale or missing → sync', async () => {
    // Cache is 30 min old.
    expect(await syncAll(60 * 60_000)).toBe(false);
    expect(await syncAll(10 * 60_000)).toBe(true);
    getCachedPortfolio.mockReturnValue(null);
    expect(await syncAll(24 * 60 * 60_000)).toBe(true);
    expect(getPortfolio).toHaveBeenCalledTimes(2);
  });

  it('reports false and does not notify when the sync throws', async () => {
    getPortfolio.mockRejectedValue(new Error('boom'));
    expect(await syncAll()).toBe(false);
    expect(broadcastPortfolioChanged).not.toHaveBeenCalled();
  });
});
