/** Stable host contract for the pinned DomBot Worker/UI artifact. */
export interface DomBotEnvironment {
  DOMBOT_PARKIO_ENABLED?: string;
  DB: D1Database;
  ASSETS: Fetcher;
  DOMBOT_AUTH: string;
  DOMBOT_MANAGED_PROXY_URL?: string;
  DOMBOT_MANAGED_PROXY_IP?: string;
  DOMBOT_PROXY_SCHEDULER_IP?: string;
  DOMBOT_PROXY_SCHEDULER?: Fetcher;
  DOMBOT_PUBLIC_DIRECTORY?: Fetcher;
  DOMBOT_PROXY_RELAY_URL?: string;
  DOMBOT_PROXY_ALTERNATE_HOST?: string;
  DOMBOT_PROXY_ALTERNATE_IP?: string;
  DOMBOT_OWNER_SITE_V2?: string;
  DOMBOT_OWNER_SITE_V3?: string;
  DOMBOT_COMPOSITE_PUBLISH?: string;
  DOMBOT_SALES_DNS_CONTROL?: string;
  SALES_DNS_CONTROL_ENABLED?: string;
  DOMBOT_SALES_V1?: string;
  DOMBOT_LANDER_DNS_PROVIDERS?: string;
  DYNDNS_SETUP_FIXTURE?: string;
  DOMBOT_NOTIFICATION_V1?: string;
  SALES_INQUIRIES_ENABLED?: string;
  SALES_PRIVACY_REVIEWED?: string;
  SALES_MAIL_ENABLED?: string;
  SALES_TURNSTILE_SITEKEY?: string;
  SALES_TURNSTILE_SECRET?: string;
  DOMBOT_SALES_ORIGIN?: string;
  DOMBOT_SALES_EDGE_SECRET?: string;
  DOMBOT_SECRET?: string;
  DOMBOT_PASSWORD?: string;
  DOMBOT_GATEWAY_SECRET?: string;
  DOMBOT_WORKSPACE_ID?: string;
  DOMBOT_PUBLIC_BASE_PATH?: string;
  CF_ACCESS_TEAM_DOMAIN?: string;
  CF_ACCESS_AUD?: string;
}
export interface DomBotContext {
  waitUntil(work: Promise<unknown>): void;
}
export interface DomBotSchedule {
  cron: string;
  scheduledTime: number;
  noRetry(): void;
}
export interface DomBotEngine {
  adminInventory(env: DomBotEnvironment, query: unknown): Promise<unknown>;
  maintenanceState(env: DomBotEnvironment): Promise<DomBotMaintenanceState>;
  syncMonitor(env: DomBotEnvironment, revision?: string): Promise<unknown>;
  fetch(
    request: Request,
    env: DomBotEnvironment,
    context: DomBotContext,
  ): Promise<Response>;
  scheduled(event: DomBotSchedule, env: DomBotEnvironment): Promise<void>;
}

export interface DomBotMaintenanceState {
  version: 1;
  state: 'empty' | 'work' | 'unknown';
  reason: string;
  revision: string | null;
}

declare const engine: DomBotEngine;
export default engine;
export declare function mcpPreflight(request: Request, env: DomBotEnvironment): Promise<Response | null>;
