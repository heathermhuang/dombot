import {
  pageMembership,
  pageMembershipLabel,
  matchesPageScope,
} from '../../shared/page-membership';
import { useLocation, useNavigate } from 'react-router-dom';
import { portfolioPagePath } from '../lib/portfolio-navigation';
import { useDomainList, type DomainScope } from '../store/domain-list';
import {
  buildDomainCatalog,
  portfolioTotals,
  withInventory,
  matchesRegistrarFilters,
  sortManagementRows,
} from '../../shared/domain-catalog';
import { domainKey } from '../../shared/account-key';
import { importedRows } from '../../shared/imported-domains';
import { HIDDEN_FOLDER_ID } from '../../shared/ipc';
import { useRegistrarManagement } from '../components/domain-workspace/RegistrarManagement';
import LegacyDomains from './Domains';
import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Copy,
  Eye,
  FolderPlus,
  Globe,
  MoreHorizontal,
  Search,
  Settings2,
  Upload,
  X,
  AlertCircle,
  Undo2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAppStore } from '../store/app';
import { portfolioEditor, usePortfolioEditor } from '../lib/publication-client';
import { hostPath } from '../lib/platform';
import { importPublication } from '../../shared/publication-import';
import {
  previewSnapshot,
  publicationChanges,
  revertListing,
} from '../../shared/publication-edit';
import {
  collectionTokens,
  editPortfolioSelection,
  filterPortfolio,
  isCurrent,
  type BulkPortfolioEdit,
  type OwnershipFilter,
} from '../../shared/portfolio-management';
import { portfolioIssues } from '../../shared/portfolio-validation';
import { bindPortfolioPreview } from '../lib/portfolio-preview';
import { renderPortfolio } from '../../shared/render-portfolio';
import type {
  PortfolioDraft,
  PortfolioListing,
} from '../../shared/publication';
import {
  PortfolioInspector,
  ownershipLabel,
} from '../components/portfolio/PortfolioInspector';
import { PortfolioSettings } from '../components/portfolio/PortfolioSettings';
import { PortfolioReview } from '../components/portfolio/PortfolioReview';
import '../components/portfolio/portfolio.css';
import { usePreferences } from '../lib/preferences';

export default function DomainWorkspace({
  area,
}: {
  area: 'domains' | 'page';
}) {
  const pageSize = usePreferences((s) => s.pageSize);
  const density = usePreferences((s) => s.density);
  const {
    state,
    draft: savedDraft,
    status,
    error,
    errorKind,
  } = usePortfolioEditor();
  const syncedInventory = useAppStore((s) => s.portfolio);
  const importedInventory = useAppStore((s) => s.importedDomains);
  const inventory = useMemo(
    () => [
      ...syncedInventory,
      ...importedRows(importedInventory, syncedInventory),
    ],
    [syncedInventory, importedInventory],
  );
  const enriched = useAppStore((s) => s.enriched);
  const pricing = useAppStore((s) => s.pricing);
  const accounts = useAppStore((s) => s.registrars);
  const folders = useAppStore((s) => s.folders);
  const assignments = useAppStore((s) => s.folderAssignments);
  const loadRegistrars = useAppStore((s) => s.loadRegistrars);
  const effectiveInventory = useMemo(
    () =>
      inventory.map((record) =>
        enriched[domainKey(record)]
          ? {
              ...record,
              ...enriched[domainKey(record)],
              accountId: record.accountId,
              accountLabel: record.accountLabel,
              registrar: record.registrar,
              domainName: record.domainName,
            }
          : record,
      ),
    [inventory, enriched],
  );
  const draft = useMemo(
    () => (savedDraft ? withInventory(savedDraft, inventory) : null),
    [savedDraft, inventory],
  );
  const navigate = useNavigate();
  const location = useLocation();
  const requestedView = new URLSearchParams(location.search).get('view');
  const view =
    area === 'domains'
      ? 'domains'
      : requestedView === 'preview' || requestedView === 'review'
        ? requestedView
        : 'settings';
  const list = useDomainList();
  const initializeScope = list.initializeScope;
  useEffect(() => {
    if (area !== 'domains' || !draft || !state || accounts === null) return;
    initializeScope(
      inventory.length > 0 || accounts.some((account) => account.configured),
      draft.listings.some((item) => item.visibility === 'private'),
    );
  }, [area, draft, state, accounts, inventory.length, initializeScope]);
  const { mode, scope, query, collection, sort, page, picked } = list;
  const hasActiveFilters =
    [
      list.query,
      list.collection,
      list.account,
      list.tld,
      list.expiry,
      list.folder,
      list.nameserver,
    ].some(Boolean) || list.ownership !== 'all';
  const ownershipFilter = list.ownership;
  const setPage = list.setPage,
    setPicked = list.setPicked;
  const setQuery = (query: string) => list.setFilters({ query });
  const setCollection = (collection: string) => list.setFilters({ collection });
  const setSort = (sort: string) => list.setFilters({ sort });
  const setOwnershipFilter = (ownership: OwnershipFilter) =>
    list.setFilters({ ownership });
  const refreshTick = useAppStore((s) => s.refreshTick);
  const [editing, setEditing] = useState<string | null>(null);
  const [registrarExpanded, setRegistrarExpanded] = useState<Set<string>>(
    new Set(),
  );
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');
  const [notice, setNotice] = useState('');
  const [undo, setUndo] = useState<PortfolioDraft | null>(null);
  const [importing, setImporting] = useState(false);
  const [importText, setImportText] = useState('');
  const importPreview = useMemo(() => {
    if (!importing || !importText.trim() || !draft) return null;
    try {
      return {
        result: importPublication(importText, draft.listings),
        error: '',
      };
    } catch (error) {
      return { result: null, error: (error as Error).message };
    }
  }, [importing, importText, draft]);
  const [collectionAction, setCollectionAction] = useState(false);
  const [collectionMode, setCollectionMode] = useState<
    'add' | 'remove' | 'replace'
  >('add');
  const [collectionValue, setCollectionValue] = useState('');
  const [historyNames, setHistoryNames] = useState<Set<string> | null>(null);
  const [mobile, setMobile] = useState(false);
  const [previewQuery, setPreviewQuery] = useState('');
  const [addIntent, setAddIntent] = useState<'showcase' | 'inquiry'>(
    'showcase',
  );
  const [receipt, setReceipt] = useState<{ url: string; time: number } | null>(
    null,
  );
  const [confirmUnpublish, setConfirmUnpublish] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false);
  useEffect(() => {
    void portfolioEditor.load().catch(() => {});
    void loadRegistrars();
    window.scrollTo(0, 0);
  }, [loadRegistrars]);
  useEffect(() => {
    if (refreshTick)
      void portfolioEditor
        .refreshReview()
        .catch((e: Error) => setActionError(e.message));
  }, [refreshTick]);
  useEffect(() => {
    setUndo(null);
    setEditing(null);
    setNotice('');
    setCollectionAction(false);
  }, [area]);
  const checks = useMemo(
    () => new Map(state?.review.map((item) => [item.domain, item]) ?? []),
    [state],
  );
  // The public document is rendered only when requested, never on each table edit.
  const preview = useMemo(
    () =>
      view === 'preview' && draft
        ? renderPortfolio(
            previewSnapshot(draft),
            new URL(
              `${window.location.origin}${hostPath('/publishing/preview')}${previewQuery}`,
            ),
            true,
            true,
          )
        : '',
    [view, draft, previewQuery],
  );
  const catalog = useMemo(
    () =>
      buildDomainCatalog(
        draft?.listings ?? [],
        effectiveInventory,
        accounts,
        list.account,
      ),
    [draft, effectiveInventory, accounts, list.account],
  );
  const filtered = useMemo(() => {
    if (!draft || !state) return [];
    const candidates = filterPortfolio(draft.listings, state.review, {
      scope: scope === 'registered' || scope === 'listed' ? 'all' : scope,
      ownership: ownershipFilter,
      query,
      collection,
      sort,
    }).filter(
      (item) =>
        matchesPageScope(
          item,
          state.publishedSnapshot?.listings.find(
            (entry) => entry.domain === item.domain,
          ),
          scope,
          !!catalog.get(item.domain)?.records.length,
        ) &&
        matchesRegistrarFilters(
          catalog.get(item.domain)!,
          {
            account: list.account,
            tld: list.tld,
            expiry: list.expiry,
            folder: list.folder,
            nameserver: list.nameserver,
          },
          assignments,
          new Set(folders.map((folder) => folder.id)),
          HIDDEN_FOLDER_ID,
        ),
    );
    return sortManagementRows(candidates, catalog, pricing, sort);
  }, [
    draft,
    state,
    scope,
    ownershipFilter,
    query,
    collection,
    sort,
    catalog,
    list.account,
    list.tld,
    list.expiry,
    list.folder,
    list.nameserver,
    assignments,
    pricing,
    folders,
  ]);
  const displayedPage = Math.min(
    page,
    Math.max(1, Math.ceil(filtered.length / pageSize)),
  );
  const visibleNames = filtered
    .slice((displayedPage - 1) * pageSize, displayedPage * pageSize)
    .map((item) => item.domain);
  const management = useRegistrarManagement({
    catalog,
    selected: picked,
    visible: visibleNames,
    active: area === 'domains' && mode === 'manage',
    needsAllDetails: !!list.nameserver,
    clearSelection: () => setPicked(new Set()),
  });
  const collections = useMemo(
    () =>
      [
        ...new Set(
          draft?.listings.flatMap((item) =>
            collectionTokens(item.collection),
          ) ?? [],
        ),
      ].sort(),
    [draft],
  );
  const run = async (action: () => Promise<void>) => {
    setBusy(true);
    setActionError('');
    try {
      await action();
    } catch (e) {
      setActionError(e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  };
  if (area === 'domains' && requestedView === 'archive')
    return <LegacyDomains hidePublication />;
  if ((!draft || !state) && error && area === 'domains')
    return (
      <>
        <div className="pf-alert" role="alert">
          Public-page metadata is unavailable. Registrar management remains
          available.
        </div>
        <LegacyDomains hidePublication />
      </>
    );
  if (!draft || !state)
    return (
      <section
        className={`pf-workspace${density === 'compact' ? ' compact' : ''}`}
      >
        <header className="pf-header">
          <div>
            <span className="pf-eyebrow">Portfolio</span>
            <h1>Your collection</h1>
            <p className="pf-subtitle">
              {error || 'Loading your domain portfolio…'}
            </p>
          </div>
        </header>
        {error ? (
          <Button onClick={() => void portfolioEditor.load().catch(() => {})}>
            Try again
          </Button>
        ) : (
          <div className="pf-shell" aria-label="Loading domains" role="status">
            {Array.from({ length: 8 }, (_, i) => (
              <div key={i} className="pf-skeleton" />
            ))}
          </div>
        )}
      </section>
    );
  const liveItems = new Map(
    state.publishedSnapshot?.listings.map((item) => [item.domain, item]) ?? [],
  );
  const totals = portfolioTotals(catalog);
  const emptyPortfolio = draft.listings.length === 0 && totals.total === 0;
  const current = draft.listings.filter(isCurrent);
  const history = draft.listings.filter(
    (item) => item.visibility === 'historical',
  );
  const privateNames = draft.listings.filter((item) =>
    matchesPageScope(item, liveItems.get(item.domain), 'private'),
  );
  const blockers = current.filter(
    (item) => checks.get(item.domain)?.ownership !== 'owned',
  );
  const unmatched = privateNames.filter(
    (item) => checks.get(item.domain)?.ownership !== 'owned',
  );
  const issues = portfolioIssues(draft);
  const changes = publicationChanges(draft, state.publishedSnapshot);
  const saveStatus =
    status === 'saving'
      ? 'Saving…'
      : status === 'unsaved'
        ? 'Saving shortly…'
        : status === 'error'
          ? 'Not saved'
          : changes.count > 0
            ? 'Draft saved'
            : 'No pending changes';
  const publicUrl = window.location.origin + hostPath(`/p/${draft.handle}`);
  const liveUrl = state.published
    ? hostPath(`/p/${state.published.handle}`)
    : null;
  const rows = filtered.slice(
    (Math.min(page, Math.max(1, Math.ceil(filtered.length / pageSize))) - 1) *
      pageSize,
    Math.min(page, Math.max(1, Math.ceil(filtered.length / pageSize))) *
      pageSize,
  );
  const actualPage = Math.min(
    page,
    Math.max(1, Math.ceil(filtered.length / pageSize)),
  );
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const visibleSelected = rows.filter((item) => picked.has(item.domain)).length;
  const chosen = draft.listings.filter((item) => picked.has(item.domain));
  const selectedPrivate = chosen.filter(
    (item) => item.visibility === 'private' && !liveItems.has(item.domain),
  );
  const cannotAdd = selectedPrivate.some(
    (item) => checks.get(item.domain)?.ownership !== 'owned',
  );
  const editedItems = new Set(changes.edited.map((item) => item.domain));
  const pageListCount = draft.listings.filter(
    (item) => item.visibility !== 'private' || liveItems.has(item.domain),
  ).length;
  const allPrivate =
    chosen.length > 0 && chosen.every((item) => item.visibility === 'private');
  const allCurrent = chosen.length > 0 && chosen.every(isCurrent);
  const inspector =
    draft.listings.find((item) => item.domain === editing) ?? null;
  const clearSelection = () => {
    setPicked(new Set());
    setCollectionAction(false);
  };
  const selectPage = (checked: boolean) => {
    const next = new Set(picked);
    rows.forEach((item) =>
      checked ? next.add(item.domain) : next.delete(item.domain),
    );
    setPicked(next);
  };
  const openInspector = (domain: string) => {
    clearSelection();
    setEditing(domain);
  };
  const change = (patch: Partial<PortfolioDraft>) => {
    portfolioEditor.update({ ...draft, ...patch });
    setUndo(null);
    setNotice('');
    setActionError('');
  };
  const update = (domain: string, patch: Partial<PortfolioListing>) =>
    change({
      listings: draft.listings.map((item) =>
        item.domain === domain ? { ...item, ...patch } : item,
      ),
    });
  const apply = (edit: BulkPortfolioEdit, names = picked) => {
    try {
      const next = editPortfolioSelection(
        draft,
        names,
        edit.kind === 'include' ? { ...edit, intent: addIntent } : edit,
      );
      const affected = next.listings.filter(
        (item, i) => JSON.stringify(item) !== JSON.stringify(draft.listings[i]),
      ).length;
      portfolioEditor.update(next);
      setUndo(affected ? draft : null);
      setNotice(
        edit.kind === 'collection'
          ? `Collections updated for ${affected} ${affected === 1 ? 'domain' : 'domains'}.`
          : edit.kind === 'include'
            ? `${affected} ${affected === 1 ? 'domain' : 'domains'} added to the page draft (${addIntent === 'inquiry' ? 'accept inquiries' : 'display only; prices stay private'}). Review changes to put them online.`
            : edit.value === 'private'
              ? `${affected} ${affected === 1 ? 'domain' : 'domains'} marked for removal. Review changes to update the live page.`
              : edit.value === 'historical'
                ? `${affected} ${affected === 1 ? 'domain' : 'domains'} added to history.`
                : `${affected} ${affected === 1 ? 'domain' : 'domains'} updated in your draft.`,
      );
      setActionError('');
      clearSelection();
      if (edit.kind === 'include') window.scrollTo(0, 0);
      return true;
    } catch (e) {
      setActionError((e as Error).message);
      return false;
    }
  };
  const selectScope = (next: DomainScope, owner: OwnershipFilter = 'all') => {
    list.startTask(next, owner);
    clearSelection();
    window.scrollTo(0, 0);
  };
  const resetFilters = () =>
    list.setFilters({
      query: '',
      collection: '',
      ownership: 'all',
      sort: 'az',
      account: '',
      tld: '',
      expiry: '',
      folder: '',
      nameserver: '',
    });
  const filterChange = (action: () => void) => {
    action();
    setPage(1);
    clearSelection();
  };
  function collectionFilter() {
    return (
      <select
        aria-label="Filter collection"
        value={collection}
        onChange={(e) => filterChange(() => setCollection(e.target.value))}
      >
        <option value="">All collections</option>
        {collections.map((name) => (
          <option key={name}>{name}</option>
        ))}
      </select>
    );
  }
  function ownershipFilterControl() {
    return (
      <select
        aria-label="Filter ownership"
        value={ownershipFilter}
        onChange={(e) =>
          filterChange(() =>
            setOwnershipFilter(e.target.value as OwnershipFilter),
          )
        }
      >
        <option value="all">Ownership: all</option>
        <option value="owned">Verified for publication</option>
        <option value="attention">Needs review</option>
        <option value="blocking">Blocks publishing</option>
      </select>
    );
  }
  const navigateView = (
    next: 'domains' | 'settings' | 'preview' | 'review',
  ) => {
    navigate(portfolioPagePath(next, location.search));
    setNotice('');
    setUndo(null);
    window.scrollTo(0, 0);
  };
  const review = () =>
    void run(async () => {
      await portfolioEditor.flush();
      await portfolioEditor.refreshReview();
      navigateView('review');
    });
  const registrarRows = filtered.flatMap((item) =>
    catalog.get(item.domain)?.target ? [catalog.get(item.domain)!.target!] : [],
  );
  const copyLink = () =>
    void navigator.clipboard
      .writeText(
        window.location.origin + (liveUrl ?? hostPath(`/p/${draft.handle}`)),
      )
      .then(() => setNotice('Page link copied.'))
      .catch(() =>
        setActionError(
          'Could not copy the link. Open the live page and copy its address.',
        ),
      );

  return (
    <section
      className={`pf-workspace${density === 'compact' ? ' compact' : ''}`}
    >
      {area === 'page' && (
        <button className="pf-back" onClick={() => navigateView('domains')}>
          <ArrowLeft />
          Back to domains
        </button>
      )}
      <header className="pf-header">
        <div>
          <span className="pf-eyebrow">
            {view === 'settings'
              ? 'Page settings'
              : view === 'review'
                ? 'Publish review'
                : view === 'preview'
                  ? 'Private preview'
                  : 'Your domains'}
          </span>
          <h1>
            {view === 'domains'
              ? 'Domains'
              : view === 'review'
                ? 'Review your changes'
                : draft.title || 'Your public profile'}
          </h1>
          <div className="pf-status">
            {area === 'domains' && (
              <span>
                {totals.total} domains in portfolio · {totals.imported} imported
                · {totals.registrarVerified} registrar verified
              </span>
            )}
            {(area === 'page' || mode === 'publish') && (
              <>
                {state.published ? (
                  <span>
                    <i className="pf-live-dot" />
                    {area === 'domains'
                      ? `${state.published.count} live on public profile`
                      : `Live · ${state.published.count} names`}
                  </span>
                ) : (
                  <span>Not published</span>
                )}
                <span aria-hidden="true">/</span>
                <span role="status">
                  {status === 'saved' && <Check />}
                  {saveStatus}
                </span>
                {changes.count > 0 && (
                  <span>
                    · {changes.count} unpublished{' '}
                    {changes.count === 1 ? 'change' : 'changes'}
                  </span>
                )}
              </>
            )}
          </div>
        </div>
        <div className="pf-actions">
          {view === 'domains' && !emptyPortfolio && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigateView('settings')}
              >
                <Settings2 />
                Public profile
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="hidden sm:inline-flex"
                onClick={() => navigateView('preview')}
              >
                <Eye />
                Preview profile
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="pf-icon-button"
                    aria-label="More domain options"
                  >
                    <MoreHorizontal />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    className="sm:hidden"
                    onSelect={() => navigateView('preview')}
                  >
                    Preview public profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => list.setMode('manage')}>
                    Show registrar details
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => list.setMode('publish')}>
                    Show listing details
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onSelect={() => selectScope('history')}>
                    Show previously owned names
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => selectScope('private', 'attention')}
                  >
                    Show names needing verification
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => selectScope('all')}>
                    Show all records
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  {allPrivate && picked.size > 0 && (
                    <DropdownMenuItem
                      onSelect={() => setHistoryNames(new Set(picked))}
                    >
                      Mark selected as previously owned…
                    </DropdownMenuItem>
                  )}
                  {liveUrl && (
                    <>
                      <DropdownMenuItem asChild>
                        <a href={liveUrl} target="_blank" rel="noreferrer">
                          <ArrowUpRight />
                          View live profile
                        </a>
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={copyLink}>
                        <Copy />
                        Copy profile link
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                    </>
                  )}
                  <DropdownMenuItem
                    disabled={!registrarRows.length}
                    onSelect={() => void management.exportRows(registrarRows)}
                  >
                    Export {registrarRows.length} registered domains (CSV)
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => setImporting(true)}>
                    <Upload />
                    Import domains
                  </DropdownMenuItem>
                  {area === 'page' && state.published && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onSelect={() => setConfirmUnpublish(true)}
                      >
                        Unpublish…
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}
          {area === 'page' && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  selectScope('private');
                  navigateView('domains');
                }}
              >
                Add domains
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  selectScope('listed');
                  navigateView('domains');
                }}
              >
                Choose profile domains
              </Button>
              {view !== 'settings' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => navigateView('settings')}
                >
                  Edit page
                </Button>
              )}
              {changes.count > 0 && view !== 'review' && (
                <Button size="sm" disabled={busy} onClick={review}>
                  Review changes ({changes.count}) →
                </Button>
              )}
              {liveUrl && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      size="sm"
                      variant="ghost"
                      aria-label="Public profile options"
                    >
                      <MoreHorizontal />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {liveUrl && (
                      <>
                        <DropdownMenuItem asChild>
                          <a href={liveUrl} target="_blank" rel="noreferrer">
                            View live profile
                          </a>
                        </DropdownMenuItem>
                        <DropdownMenuItem onSelect={copyLink}>
                          Copy profile link
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onSelect={() => setConfirmUnpublish(true)}
                        >
                          Unpublish…
                        </DropdownMenuItem>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </>
          )}
          {view === 'settings' && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigateView('preview')}
            >
              <Eye />
              Preview profile
            </Button>
          )}
          {view === 'preview' && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setMobile(!mobile)}
              >
                {mobile ? 'Desktop view' : 'Mobile view'}
              </Button>
            </>
          )}
        </div>
      </header>
      {area === 'page' && liveUrl && (
        <div className="pf-share">
          <a href={liveUrl} target="_blank" rel="noreferrer">
            {window.location.origin + liveUrl}
          </a>
          <Button size="sm" variant="outline" asChild>
            <a href={liveUrl} target="_blank" rel="noreferrer">
              View live profile
            </a>
          </Button>
          <Button size="sm" variant="outline" onClick={copyLink}>
            Copy link
          </Button>
        </div>
      )}
      {receipt && (
        <div className="pf-alert" role="status">
          <strong>Publication complete</strong>
          <span>{new Date(receipt.time).toLocaleString()}</span>
          <a href={receipt.url} target="_blank" rel="noreferrer">
            View published page ↗
          </a>
        </div>
      )}
      {issues.length > 0 && (
        <div className="pf-alert" role="alert">
          <strong>
            Fix these fields. Valid edits can save while you correct them.
          </strong>
          {issues.map((issue) => (
            <button
              key={`${issue.domain ?? 'page'}-${issue.field}`}
              className="pf-text-button"
              onClick={() => {
                if (issue.domain) setEditing(issue.domain);
                else navigateView('settings');
                setTimeout(
                  () =>
                    document.getElementById(`pf-field-${issue.field}`)?.focus(),
                  100,
                );
              }}
            >
              {issue.domain ?? 'Page settings'}: {issue.message}
            </button>
          ))}
        </div>
      )}
      {area === 'domains' && changes.count > 0 && (
        <div className="page-pending-banner" role="status">
          <div>
            <strong>
              {changes.count} {changes.count === 1 ? 'change' : 'changes'}{' '}
              waiting to publish
            </strong>
            <span>Your live page has not changed yet.</span>
          </div>
          <Button size="sm" disabled={busy} onClick={review}>
            Review changes →
          </Button>
        </div>
      )}
      {area === 'domains' && (scope === 'history' || scope === 'all') && (
        <p className="pf-hint">
          {scope === 'history'
            ? 'Previously owned names'
            : 'All registered and imported records'}{' '}
          ·{' '}
          <button
            className="pf-text-button"
            onClick={() => selectScope('registered')}
          >
            Back to inventory
          </button>
        </p>
      )}
      {((error && errorKind !== 'validation') || actionError) && (
        <div role="alert" className="pf-alert">
          <span>{actionError || error}</span>
          <div className="pf-actions">
            <Button
              size="sm"
              variant="outline"
              disabled={busy}
              onClick={() => void run(() => portfolioEditor.flush())}
            >
              Retry save
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setConfirmDiscard(true)}
            >
              Reload saved draft…
            </Button>
          </div>
        </div>
      )}
      {notice && (
        <div role="status" className="pf-alert">
          <span>{notice}</span>
          {undo && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                portfolioEditor.update(undo);
                setUndo(null);
                setNotice('Change undone in your draft.');
              }}
            >
              <Undo2 />
              Undo
            </Button>
          )}
          <button
            className="pf-row-edit"
            aria-label="Dismiss message"
            onClick={() => {
              setNotice('');
              setUndo(null);
            }}
          >
            <X />
          </button>
        </div>
      )}
      {(blockers.length > 0 || ownershipFilter === 'attention') && (
        <details
          className="pf-recovery"
          open={ownershipFilter === 'blocking' || view === 'review'}
        >
          <summary>
            {blockers.length} selected listings need verification · resolve by
            registrar
          </summary>
          <p>
            Connected accounts and past syncs do not guarantee fresh ownership
            evidence. Refresh affected accounts before publishing.
          </p>
          {(accounts ?? [])
            .filter((account) => account.saved || account.configured)
            .map((account) => {
              const label = `${account.displayName} · ${account.accountLabel ?? 'Default'}`;
              const affected = blockers.filter((item) =>
                checks.get(item.domain)?.accountLabels.includes(label),
              );
              if (!affected.length) return null;
              return (
                <div
                  className="pf-recovery-account"
                  key={account.accountId ?? account.name}
                >
                  <div>
                    <strong>
                      {label} · {affected.length} listings
                    </strong>
                    <p>
                      {account.configured ? 'Connected' : 'Not connected'} ·{' '}
                      {account.enabled ? 'Enabled' : 'Disabled'}
                    </p>
                    <p>
                      Last successful sync:{' '}
                      {account.sync.lastSyncedAt
                        ? new Date(account.sync.lastSyncedAt).toLocaleString()
                        : 'Never'}
                    </p>
                    <p>
                      {account.sync.lastError
                        ? 'Last sync failed. Check account settings and refresh.'
                        : 'Fresh verification required before publication.'}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => {
                      if (!account.configured || !account.enabled)
                        navigate('/settings?tab=registrars');
                      else
                        void run(async () => {
                          await useAppStore
                            .getState()
                            .syncRegistrar(account.name, account.accountId);
                          await portfolioEditor.refreshReview();
                        });
                    }}
                  >
                    {account.configured && account.enabled
                      ? 'Refresh verification'
                      : 'Connect / enable account'}
                  </Button>
                </div>
              );
            })}
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              selectScope('listed', 'blocking');
              navigateView('domains');
            }}
          >
            Inspect affected listings
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => navigate('/settings?tab=registrars')}
          >
            Registrar settings
          </Button>
        </details>
      )}
      {view === 'settings' ? (
        <div className="pf-shell">
          <PortfolioSettings
            draft={draft}
            onChange={change}
            publicUrl={publicUrl}
            issues={issues.filter((issue) => !issue.domain)}
          />
        </div>
      ) : view === 'preview' ? (
        <>
          <div className="pf-preview-frame" data-mobile={mobile}>
            <div className="pf-preview-toolbar">
              <span>
                {current.length} current listings · {history.length} historical
              </span>
              <div className="pf-preview-switches">
                <button
                  aria-pressed={!previewQuery.includes('history')}
                  onClick={() => setPreviewQuery('')}
                >
                  Current holdings
                </button>
                {history.length > 0 && (
                  <button
                    aria-pressed={previewQuery.includes('history')}
                    onClick={() => setPreviewQuery('?view=history')}
                  >
                    Previously owned
                  </button>
                )}
              </div>
            </div>
            <iframe
              title="Portfolio draft preview"
              sandbox="allow-same-origin"
              onLoad={(event) => {
                const document = event.currentTarget.contentDocument;
                if (document) bindPortfolioPreview(document, setPreviewQuery);
              }}
              srcDoc={preview}
            />
          </div>
          <div className="pf-preview-foot">
            <p>
              Interactive draft · search, collections and pagination work here.
              Inquiries are disabled.
            </p>
            <Button
              variant="outline"
              disabled={busy || issues.length > 0}
              onClick={() => {
                const tab = window.open('about:blank', '_blank');
                if (!tab) {
                  setActionError(
                    'Allow pop-ups to open the interactive preview.',
                  );
                  return;
                }
                tab.opener = null;
                void run(async () => {
                  try {
                    await portfolioEditor.flush();
                    tab.location.href = hostPath('/publishing/preview');
                  } catch (error) {
                    tab.close();
                    throw error;
                  }
                });
              }}
            >
              Open interactive draft preview ↗
            </Button>
          </div>
        </>
      ) : view === 'review' ? (
        <PortfolioReview
          draft={draft}
          published={state.publishedSnapshot}
          blockers={blockers.length}
          busy={busy}
          ready={status === 'saved'}
          publicUrl={publicUrl}
          onEdit={openInspector}
          onRevert={(domain) =>
            change(revertListing(draft, state.publishedSnapshot, domain))
          }
          onEditPage={() => navigateView('settings')}
          onRevertPage={(field) => {
            if (state.publishedSnapshot)
              change({ [field]: state.publishedSnapshot[field] });
          }}
          onResolve={() => {
            if (
              current.some((item) => item.visibility === 'inquiry') &&
              !draft.contactEmail
            )
              navigateView('settings');
            else {
              list.setMode('publish');
              selectScope('listed', 'blocking');
              navigateView('domains');
            }
          }}
          onPublish={() =>
            void run(async () => {
              await portfolioEditor.publish();
              navigateView('settings');
              const published = portfolioEditor.getSnapshot().state?.published;
              if (published)
                setReceipt({
                  url:
                    window.location.origin + hostPath(`/p/${published.handle}`),
                  time: published.publishedAt,
                });
            })
          }
        />
      ) : emptyPortfolio ? (
        <div className="pf-shell pf-empty">
          <Globe />
          <h2>Bring your domains together</h2>
          <p>
            Connect your first registrar to bring your domains into one
            portfolio. You can also import a CSV.
          </p>
          <div className="pf-actions justify-center">
            <Button onClick={() => navigate('/settings?tab=registrars')}>
              Connect your first registrar
            </Button>
            <Button variant="outline" onClick={() => setImporting(true)}>
              <Upload />
              Import CSV
            </Button>
          </div>
          <p className="pf-onboarding-note">
            Private until you publish. Importing does not grant registrar access
            or verify ownership.
          </p>
        </div>
      ) : (
        <>
          <div className="pf-shell">
            <div className="pf-scopes">
              {(
                [
                  [
                    'registered',
                    'Inventory',
                    new Set(
                      inventory.map((item) => item.domainName.toLowerCase()),
                    ).size,
                  ],
                  ['listed', 'Profile domains', pageListCount],
                  ['private', 'Private domains', privateNames.length],
                ] as [DomainScope, string, number][]
              ).map(([key, label, count]) => (
                <button
                  key={key}
                  aria-pressed={scope === key}
                  onClick={() => selectScope(key)}
                >
                  {label}
                  <span>{count}</span>
                </button>
              ))}
            </div>
            <div className="pf-filter-summary">
              <span>
                {filtered.length} matching ·{' '}
                {scope === 'listed'
                  ? `${pageListCount} selected or live, including ${history.length} historical`
                  : scope === 'private'
                    ? `${privateNames.length} private names`
                    : 'registered inventory'}
              </span>
              {(
                [
                  'query',
                  'collection',
                  'ownership',
                  'account',
                  'tld',
                  'expiry',
                  'folder',
                  'nameserver',
                ] as const
              )
                .filter((key) => list[key] && list[key] !== 'all')
                .map((key) => (
                  <button
                    key={key}
                    onClick={() =>
                      list.setFilters({
                        [key]: key === 'ownership' ? 'all' : '',
                      })
                    }
                  >
                    {key}:{' '}
                    {key === 'account'
                      ? (accounts?.find(
                          (a) => (a.accountId ?? a.name) === list.account,
                        )?.accountLabel ?? list[key])
                      : list[key]}{' '}
                    ×
                  </button>
                ))}
              {hasActiveFilters && (
                <button onClick={resetFilters}>Clear filters</button>
              )}
            </div>
            {scope === 'private' && (
              <label className="pf-add-intent">
                When adding domains{' '}
                <select
                  aria-label="Inquiry intent for new additions"
                  value={addIntent}
                  onChange={(e) =>
                    setAddIntent(e.target.value as 'showcase' | 'inquiry')
                  }
                >
                  <option value="showcase">Display only</option>
                  <option value="inquiry">Accept inquiries</option>
                </select>
                <span className="pf-hint">
                  {addIntent === 'inquiry'
                    ? 'A public email is required before publishing.'
                    : 'Prices stay private. You can enable inquiries later.'}
                </span>
              </label>
            )}
            <div className="pf-toolbar">
              <div className="pf-search">
                <Search />
                <Input
                  type="search"
                  aria-label="Search domains"
                  placeholder="Find a domain to add or manage…"
                  value={query}
                  onChange={(e) => filterChange(() => setQuery(e.target.value))}
                />
              </div>
              <span className="domain-desktop-filter">
                {collectionFilter()}
              </span>
              <span className="domain-desktop-filter">
                {ownershipFilterControl()}
              </span>
              <select
                aria-label="Sort domains"
                className="pf-sort"
                value={sort}
                onChange={(e) => filterChange(() => setSort(e.target.value))}
              >
                <option value="az">Name A–Z</option>
                <option value="za">Name Z–A</option>
                <option value="price">Asking price by currency</option>
                <option value="expiry">Expiration soonest</option>
                <option value="expiry-desc">Expiration latest</option>
                <option value="renewal">Renewal cost highest</option>
                <option value="renewal-asc">Renewal cost lowest</option>
              </select>
            </div>
            <details className="domain-more-filters">
              <summary>
                More filters
                {[
                  list.collection,
                  list.ownership === 'all' ? '' : list.ownership,
                  list.account,
                  list.tld,
                  list.expiry,
                  list.folder,
                  list.nameserver,
                ].filter(Boolean).length
                  ? ` · ${[list.collection, list.ownership === 'all' ? '' : list.ownership, list.account, list.tld, list.expiry, list.folder, list.nameserver].filter(Boolean).length} active`
                  : ''}
              </summary>
              <div>
                <button className="pf-text-button" onClick={resetFilters}>
                  Reset all filters
                </button>
                <label className="domain-mobile-filter">
                  Collection
                  {collectionFilter()}
                </label>
                <label className="domain-mobile-filter">
                  Ownership
                  {ownershipFilterControl()}
                </label>
                <label>
                  Account
                  <select
                    aria-label="Filter registrar account"
                    value={list.account}
                    onChange={(e) =>
                      list.setFilters({ account: e.target.value })
                    }
                  >
                    <option value="">All connected accounts</option>
                    {accounts
                      ?.filter((a) => a.configured)
                      .map((a) => (
                        <option
                          key={a.accountId ?? a.name}
                          value={a.accountId ?? a.name}
                        >
                          {a.displayName}
                          {accounts.filter(
                            (x) => x.name === a.name && x.configured,
                          ).length > 1
                            ? ` · ${a.accountLabel}`
                            : ''}
                        </option>
                      ))}
                  </select>
                </label>
                <label>
                  TLD
                  <select
                    aria-label="Filter TLD"
                    value={list.tld}
                    onChange={(e) => list.setFilters({ tld: e.target.value })}
                  >
                    <option value="">All TLDs</option>
                    {[
                      ...new Set(
                        draft.listings.map((i) =>
                          i.domain.split('.').slice(1).join('.'),
                        ),
                      ),
                    ]
                      .sort()
                      .map((value) => (
                        <option key={value}>{value}</option>
                      ))}
                  </select>
                </label>
                <label>
                  Expiration
                  <select
                    aria-label="Filter expiration"
                    value={list.expiry}
                    onChange={(e) =>
                      list.setFilters({ expiry: e.target.value })
                    }
                  >
                    <option value="">Any expiration</option>
                    <option value="30">Within 30 days</option>
                    <option value="90">Within 90 days</option>
                    <option value="365">Within one year</option>
                    <option value="expired">Expired</option>
                  </select>
                </label>
                <label>
                  Folder
                  <select
                    aria-label="Filter folder"
                    value={list.folder}
                    onChange={(e) =>
                      list.setFilters({ folder: e.target.value })
                    }
                  >
                    <option value="">Visible folders</option>
                    <option value="unassigned">Unassigned</option>
                    {folders.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                    <option value={HIDDEN_FOLDER_ID}>Hidden</option>
                  </select>
                </label>
                <label>
                  Nameserver
                  <Input
                    aria-label="Filter nameserver"
                    placeholder="e.g. cloudflare.com"
                    value={list.nameserver}
                    onChange={(e) =>
                      list.setFilters({ nameserver: e.target.value })
                    }
                  />
                </label>
              </div>
            </details>
            {picked.size > 0 && (
              <div className="pf-bulk">
                <strong>{picked.size} selected</strong>
                {selectedPrivate.length > 0 && (
                  <Button
                    size="sm"
                    disabled={busy || cannotAdd}
                    onClick={() =>
                      apply(
                        { kind: 'include' },
                        new Set(selectedPrivate.map((item) => item.domain)),
                      )
                    }
                  >
                    Add {selectedPrivate.length} to public profile
                  </Button>
                )}
                {allCurrent && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        Inquiries
                        <ChevronDown />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      <DropdownMenuItem
                        onSelect={() =>
                          apply({ kind: 'inquiries', value: 'inquiry' })
                        }
                      >
                        Accept inquiries
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onSelect={() =>
                          apply({ kind: 'inquiries', value: 'showcase' })
                        }
                      >
                        Display without inquiries
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCollectionAction(!collectionAction)}
                >
                  <FolderPlus />
                  Collections
                </Button>
                {!allPrivate && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      apply({ kind: 'visibility', value: 'private' })
                    }
                  >
                    Remove from page
                  </Button>
                )}
                <button
                  className="pf-text-button pf-clear"
                  onClick={clearSelection}
                >
                  Clear selection
                </button>
                {selectedPrivate.length > 0 && cannotAdd && (
                  <span className="pf-hint w-full">
                    Some selected names need verification. See each row’s reason
                    and recovery action before adding them.
                  </span>
                )}
              </div>
            )}
            {collectionAction && picked.size > 0 && (
              <div className="pf-bulk-form">
                <label className="pf-field">
                  Action
                  <select
                    aria-label="Collection edit action"
                    value={collectionMode}
                    onChange={(e) =>
                      setCollectionMode(e.target.value as typeof collectionMode)
                    }
                  >
                    <option value="add">Add collection</option>
                    <option value="remove">Remove collection</option>
                    <option value="replace">Replace collections</option>
                  </select>
                </label>
                <label className="pf-field">
                  Collection name
                  <Input
                    aria-label="Bulk collection name"
                    value={collectionValue}
                    onChange={(e) => setCollectionValue(e.target.value)}
                    placeholder="e.g. Short names"
                  />
                </label>
                <Button
                  size="sm"
                  disabled={!collectionValue.trim()}
                  onClick={() => {
                    const applied = apply({
                      kind: 'collection',
                      mode: collectionMode,
                      value: collectionValue,
                    });
                    if (applied) setCollectionValue('');
                  }}
                >
                  Apply to {picked.size}
                </Button>
                <button
                  className="pf-text-button"
                  onClick={() => setCollectionAction(false)}
                >
                  Cancel
                </button>
              </div>
            )}
            {picked.size > 0 && filtered.length > rows.length && (
              <div className="pf-selection-banner">
                <span>{picked.size} selected across this result.</span>
                {!filtered.every((item) => picked.has(item.domain)) && (
                  <button
                    className="pf-text-button"
                    onClick={() =>
                      setPicked(new Set(filtered.map((item) => item.domain)))
                    }
                  >
                    Select all {filtered.length} matching domains
                  </button>
                )}
              </div>
            )}
            {management.toolbar}
            <label className="pf-mobile-select">
              <Checkbox
                aria-label="Select visible domains"
                checked={
                  visibleSelected === 0
                    ? false
                    : visibleSelected === rows.length
                      ? true
                      : 'indeterminate'
                }
                onCheckedChange={(checked) => selectPage(checked === true)}
              />
              Select this page
            </label>
            <div className="domain-table-scroll">
              <table className="pf-table" data-mode={mode}>
                <thead>
                  <tr>
                    <th>
                      <Checkbox
                        aria-label="Select this page"
                        checked={
                          visibleSelected === 0
                            ? false
                            : visibleSelected === rows.length
                              ? true
                              : 'indeterminate'
                        }
                        onCheckedChange={(checked) => {
                          const next = new Set(picked);
                          rows.forEach((item) =>
                            checked
                              ? next.add(item.domain)
                              : next.delete(item.domain),
                          );
                          setPicked(next);
                        }}
                      />
                    </th>
                    <th>Domain</th>
                    {mode === 'publish' && <th>Public profile</th>}
                    {mode === 'manage' ? (
                      <>
                        <th>Registrar / account</th>
                        <th>Folder</th>
                        <th>Created</th>
                        <th>Expires</th>
                        <th>Status</th>
                        <th>Renewal</th>
                        <th>Auto renew</th>
                        <th>Privacy</th>
                        <th>Locked</th>
                        <th>Nameservers</th>
                        <th>
                          <span className="sr-only">Actions</span>
                        </th>
                      </>
                    ) : (
                      <>
                        <th>Availability</th>
                        <th className="pf-collection-cell">Collections</th>
                        <th>Asking price</th>
                        <th className="pf-check-column">Ownership</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((item) => {
                    const check =
                      checks.get(item.domain)?.ownership ?? 'unmatched';
                    return (
                      <tr
                        key={item.domain}
                        data-selected={picked.has(item.domain)}
                        data-registrar-expanded={registrarExpanded.has(
                          item.domain,
                        )}
                      >
                        <td>
                          <Checkbox
                            aria-label={`Select ${item.domain}`}
                            checked={picked.has(item.domain)}
                            onCheckedChange={(checked) => {
                              const next = new Set(picked);
                              if (checked) next.add(item.domain);
                              else next.delete(item.domain);
                              setPicked(next);
                            }}
                          />
                        </td>
                        <td className="pf-domain-cell">
                          <button
                            className="pf-domain"
                            onClick={() => openInspector(item.domain)}
                            aria-label={`Edit ${item.domain}`}
                          >
                            {item.domain}
                          </button>
                          {mode === 'manage' && (
                            <button
                              className="pf-mobile-registrar-toggle"
                              aria-label={`More details for ${item.domain}`}
                              aria-expanded={registrarExpanded.has(item.domain)}
                              onClick={() =>
                                setRegistrarExpanded((previous) => {
                                  const next = new Set(previous);
                                  if (next.has(item.domain))
                                    next.delete(item.domain);
                                  else next.add(item.domain);
                                  return next;
                                })
                              }
                            >
                              {registrarExpanded.has(item.domain)
                                ? 'Hide details'
                                : 'More details'}
                            </button>
                          )}
                        </td>
                        {mode === 'publish' && (
                          <td className="page-action-cell">
                            <div>
                              <span
                                data-page-state={pageMembership(
                                  item,
                                  liveItems.get(item.domain),
                                  editedItems.has(item.domain),
                                )}
                              >
                                {
                                  pageMembershipLabel[
                                    pageMembership(
                                      item,
                                      liveItems.get(item.domain),
                                      editedItems.has(item.domain),
                                    )
                                  ]
                                }
                              </span>
                              {check !== 'owned' &&
                                item.visibility !== 'historical' && (
                                  <button
                                    className="pf-verification-reason"
                                    onClick={() => openInspector(item.domain)}
                                  >
                                    {ownershipLabel[check]} · Resolve
                                  </button>
                                )}
                              <div className="page-row-actions">
                                {item.visibility === 'private' ? (
                                  liveItems.has(item.domain) ? (
                                    <button
                                      className="pf-text-button"
                                      onClick={() =>
                                        update(item.domain, {
                                          visibility: liveItems.get(
                                            item.domain,
                                          )!.visibility,
                                        })
                                      }
                                    >
                                      Keep on page
                                    </button>
                                  ) : (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={check !== 'owned'}
                                      onClick={() =>
                                        apply(
                                          { kind: 'include' },
                                          new Set([item.domain]),
                                        )
                                      }
                                    >
                                      Add to public profile
                                    </Button>
                                  )
                                ) : (
                                  <>
                                    <button
                                      className="pf-text-button"
                                      onClick={() =>
                                        apply(
                                          {
                                            kind: 'visibility',
                                            value: 'private',
                                          },
                                          new Set([item.domain]),
                                        )
                                      }
                                    >
                                      Remove
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          </td>
                        )}
                        {mode === 'manage' ? (
                          management.cells(catalog.get(item.domain))
                        ) : (
                          <>
                            <td className="pf-availability-cell">
                              {isCurrent(item) ? (
                                <select
                                  className="pf-inline-availability"
                                  aria-label={`Availability for ${item.domain}`}
                                  value={item.visibility}
                                  onChange={(e) =>
                                    update(item.domain, {
                                      visibility: e.target.value as
                                        'inquiry' | 'showcase',
                                    })
                                  }
                                >
                                  <option value="inquiry">Inquiries on</option>
                                  <option value="showcase">Display only</option>
                                </select>
                              ) : item.visibility === 'historical' ? (
                                <span className="pf-availability">
                                  Previously owned
                                </span>
                              ) : (
                                <span className="pf-availability">—</span>
                              )}
                            </td>
                            <td className="pf-collection-cell">
                              <div className="pf-collection">
                                {collectionTokens(item.collection)
                                  .slice(0, 2)
                                  .map((name) => (
                                    <span key={name} className="pf-tag">
                                      {name}
                                    </span>
                                  ))}
                                {collectionTokens(item.collection).length >
                                  2 && (
                                  <span className="pf-hint">
                                    +
                                    {collectionTokens(item.collection).length -
                                      2}
                                  </span>
                                )}
                                {!item.collection && (
                                  <span className="pf-hint">—</span>
                                )}
                              </div>
                            </td>
                            <td className="pf-price-cell">
                              <span className="pf-price">
                                {item.visibility !== 'inquiry' ? (
                                  'Not public'
                                ) : item.askingPrice === null ? (
                                  <span className="pf-hint">On request</span>
                                ) : (
                                  `${item.currency} ${item.askingPrice.toLocaleString()}`
                                )}
                              </span>
                            </td>
                            <td className="pf-check-column">
                              <span
                                className="pf-evidence-label"
                                data-ok={check === 'owned'}
                              >
                                {item.visibility === 'historical' ? (
                                  'Owner-declared'
                                ) : check === 'owned' ? (
                                  <>
                                    <Check />
                                    Verified
                                  </>
                                ) : (
                                  <>
                                    <AlertCircle />
                                    {check === 'unmatched'
                                      ? 'No match'
                                      : check === 'stale'
                                        ? 'Needs sync'
                                        : 'Conflict'}
                                  </>
                                )}
                              </span>
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {!rows.length && (
              <div className="pf-empty">
                <Globe />
                <h2>
                  {draft.listings.length === 0
                    ? 'Connect your domains'
                    : 'No matching domains'}
                </h2>
                <p>
                  {draft.listings.length === 0
                    ? 'Connect a registrar to manage your domains, or import names to prepare your public profile.'
                    : 'Try another view or clear the active filters.'}
                </p>
                {draft.listings.length === 0 ? (
                  <div className="pf-actions justify-center">
                    <Button
                      onClick={() => navigate('/settings?tab=registrars')}
                    >
                      Connect registrar
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setImporting(true)}
                    >
                      Import collection
                    </Button>
                  </div>
                ) : (
                  <Button variant="outline" onClick={resetFilters}>
                    Clear filters
                  </Button>
                )}
              </div>
            )}
            <div className="pf-footer">
              <span>
                {filtered.length
                  ? `${(actualPage - 1) * pageSize + 1}–${Math.min(actualPage * pageSize, filtered.length)} of ${filtered.length} domains`
                  : '0 domains'}
                {picked.size ? ` · ${picked.size} selected` : ''}
              </span>
              <div className="pf-pagination">
                <Button
                  size="sm"
                  variant="ghost"
                  aria-label="Previous portfolio page"
                  disabled={actualPage === 1}
                  onClick={() => {
                    setPage(actualPage - 1);
                    window.scrollTo(0, 0);
                  }}
                >
                  <ChevronLeft />
                </Button>
                <span>
                  {actualPage} / {pages}
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  aria-label="Next portfolio page"
                  disabled={actualPage === pages}
                  onClick={() => {
                    setPage(actualPage + 1);
                    window.scrollTo(0, 0);
                  }}
                >
                  <ChevronRight />
                </Button>
              </div>
            </div>
          </div>
          {mode === 'publish' && (
            <div className="pf-health-line">
              <Check />
              <span>
                {state.accounts.filter((account) => account.healthy).length}/
                {state.accounts.length} accounts ready for publication (fresh
                verification).
              </span>
              {blockers.length > 0 ? (
                <button
                  className="pf-text-button"
                  onClick={() => selectScope('listed', 'blocking')}
                >
                  {blockers.length} listed names block publishing
                </button>
              ) : (
                <span>No ownership blockers on your page.</span>
              )}
              {unmatched.length > 0 && (
                <button
                  className="pf-text-button"
                  onClick={() => selectScope('private', 'attention')}
                >
                  {unmatched.length} unlisted names need review
                </button>
              )}
            </div>
          )}
        </>
      )}
      {management.dialogs}
      <PortfolioInspector
        item={inspector}
        check={inspector ? checks.get(inspector.domain) : undefined}
        onClose={() => setEditing(null)}
        onChange={(patch) => {
          if (inspector) update(inspector.domain, patch);
        }}
        onHistory={() => {
          if (inspector) {
            setHistoryNames(new Set([inspector.domain]));
            setEditing(null);
          }
        }}
        issues={issues.filter((issue) => issue.domain === inspector?.domain)}
        onResolve={() => {
          const record = inspector
            ? catalog.get(inspector.domain)?.target
            : null;
          if (
            !record ||
            checks.get(inspector!.domain)?.ownership === 'conflict'
          ) {
            navigate('/settings?tab=registrars');
            setEditing(null);
            return;
          }
          void run(async () => {
            const account = accounts?.find(
              (item) =>
                (item.accountId ?? item.name) ===
                (record.accountId ?? record.registrar),
            );
            if (!account)
              throw new Error('Connect this registrar account first.');
            await useAppStore
              .getState()
              .syncRegistrar(account.name, account.accountId);
            await portfolioEditor.refreshReview();
          });
        }}
        saveStatus={saveStatus}
        error={errorKind === 'validation' ? '' : error}
      />
      <Dialog
        open={!!historyNames}
        onOpenChange={(open) => {
          if (!open) setHistoryNames(null);
        }}
      >
        <DialogContent>
          <DialogTitle>Add {historyNames?.size} names to history?</DialogTitle>
          <DialogDescription>
            This is your statement that you previously owned these names. They
            will appear under Previously owned, without inquiries, after you
            publish.
          </DialogDescription>
          <p className="break-words text-sm">
            {[...(historyNames ?? [])].slice(0, 5).join(', ')}
            {(historyNames?.size ?? 0) > 5
              ? ` and ${historyNames!.size - 5} more`
              : ''}
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setHistoryNames(null)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (historyNames)
                  apply(
                    { kind: 'visibility', value: 'historical' },
                    historyNames,
                  );
                setHistoryNames(null);
              }}
            >
              Confirm previous ownership
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog open={importing} onOpenChange={setImporting}>
        <DialogContent>
          <DialogTitle>Import domains</DialogTitle>
          <DialogDescription>
            Imported names start private. Existing edits and public selections
            are preserved.
          </DialogDescription>
          <p className="text-sm text-muted-foreground">
            Paste one domain per line, or upload CSV, TSV, JSON or text. CSV
            fields: domain, collection, description, askingPrice, currency.
          </p>
          <a
            className="text-sm underline"
            download="domains-template.csv"
            href={
              'data:text/csv;charset=utf-8,' +
              encodeURIComponent(
                'domain,collection,description,askingPrice,currency\nsample.example,Examples,Sample domain,,USD\n',
              )
            }
          >
            Download CSV template
          </a>
          <input
            type="file"
            accept=".csv,.tsv,.json,.txt"
            aria-label="Import collection file"
            className="min-w-0 w-full"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              if (file.size > 4 * 1024 * 1024) {
                setActionError('Choose a file smaller than 4 MB.');
                return;
              }
              void file
                .text()
                .then(setImportText)
                .catch(() => setActionError('Could not read that file.'));
            }}
          />
          <Textarea
            aria-label="Collection import text"
            className="h-40 resize-y [field-sizing:fixed]"
            rows={6}
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder={'garden.example\nstudio.example'}
          />
          {importPreview && (
            <div className="text-sm" aria-live="polite">
              {importPreview.error ? (
                <p role="alert" className="text-destructive">
                  {importPreview.error}
                </p>
              ) : (
                importPreview.result && (
                  <>
                    <p>
                      Recognized fields:{' '}
                      {importPreview.result.fields.join(', ')}
                    </p>
                    <p>
                      {importPreview.result.added} new names ·{' '}
                      {importPreview.result.duplicates} duplicates kept
                      unchanged
                    </p>
                    <p className="text-muted-foreground">
                      Review complete. New names will be saved privately.
                    </p>
                  </>
                )
              )}
            </div>
          )}
          <Button
            disabled={!importPreview?.result || busy}
            onClick={() => {
              try {
                const result = importPublication(importText, draft.listings);
                change({ listings: result.listings });
                setNotice(
                  `${result.added} names imported privately. ${result.duplicates} existing names kept.`,
                );
                setImportText('');
                setImporting(false);
                selectScope('private');
              } catch (e) {
                setActionError((e as Error).message);
              }
            }}
          >
            Import privately
          </Button>
          {actionError && (
            <p role="alert" className="text-sm text-destructive">
              {actionError}
            </p>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={confirmUnpublish} onOpenChange={setConfirmUnpublish}>
        <DialogContent>
          <DialogTitle>Unpublish this portfolio?</DialogTitle>
          <DialogDescription>
            The public profile will be removed. Your draft and registrar
            inventory remain.
          </DialogDescription>
          <Button
            disabled={busy}
            onClick={() =>
              void run(async () => {
                setUndo(null);
                clearSelection();
                setEditing(null);
                await portfolioEditor.unpublish();
                setConfirmUnpublish(false);
                setNotice('Portfolio unpublished. Your draft is retained.');
              })
            }
          >
            Confirm unpublish
          </Button>
        </DialogContent>
      </Dialog>
      <Dialog open={confirmDiscard} onOpenChange={setConfirmDiscard}>
        <DialogContent>
          <DialogTitle>Discard unsaved edits?</DialogTitle>
          <DialogDescription>
            This loads the latest saved draft, including any changes made in
            another tab.
          </DialogDescription>
          <Button
            disabled={busy}
            onClick={() =>
              void run(async () => {
                setUndo(null);
                clearSelection();
                setEditing(null);
                await portfolioEditor.discardAndReload();
                setConfirmDiscard(false);
                setNotice('Latest saved draft loaded.');
              })
            }
          >
            Discard edits and reload
          </Button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
