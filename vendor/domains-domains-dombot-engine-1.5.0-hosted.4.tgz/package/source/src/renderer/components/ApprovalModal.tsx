import { useCallback, useEffect, useState } from 'react';
import type { McpPendingApproval } from '../../shared/ipc';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

/**
 * App-wide modal that surfaces MCP connection requests. The main process brings
 * the window forward and emits an event; we (re)load the pending list and let
 * the user approve or deny each one.
 */
export default function ApprovalModal() {
  const [pending, setPending] = useState<McpPendingApproval[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setPending(await window.api.listPendingApprovals());
  }, []);

  useEffect(() => {
    void refresh();
    const off = window.api.onApprovalsChanged(() => void refresh());
    return off;
  }, [refresh]);

  const decide = async (id: string, approve: boolean) => {
    setBusy(id);
    try {
      await window.api.resolveApproval(id, approve);
      await refresh();
    } finally {
      setBusy(null);
    }
  };

  const req = pending[0];

  return (
    <Dialog open={Boolean(req)}>
      <DialogContent showCloseButton={false} className="sm:max-w-md">
        {req && (
          <>
            <DialogHeader>
              <DialogTitle>Approve MCP connection</DialogTitle>
              <DialogDescription>
                A client wants to connect to your DomBot portfolio. Approve only
                if you started this connection. The name is whatever the client
                claimed; the callback address is where its access will go.
              </DialogDescription>
            </DialogHeader>

            <dl className="flex flex-col gap-2 text-sm">
              <div className="flex justify-between border-b pb-2">
                <dt className="text-muted-foreground">Client</dt>
                <dd className="font-medium">{req.clientName}</dd>
              </div>
              <div className="flex justify-between gap-4 border-b pb-2">
                <dt className="shrink-0 text-muted-foreground">Callback</dt>
                <dd
                  className="truncate font-mono text-xs"
                  title={req.redirectUri}
                >
                  {req.redirectUri}
                </dd>
              </div>
              <div className="flex justify-between border-b pb-2">
                <dt className="text-muted-foreground">Confirm code</dt>
                <dd className="font-mono tracking-widest text-primary">
                  {req.code}
                </dd>
              </div>
            </dl>
            {req.scopes && (
              <div className="rounded-md border p-3 text-sm">
                <p className="font-medium">Requested permissions</p>
                <ul className="mt-2 space-y-1">
                  {req.scopes.map((scope) => (
                    <li key={scope}>
                      {scope === 'portfolio:read'
                        ? 'Read and sync your portfolio'
                        : scope === 'domains:write'
                          ? 'Change domain settings and access transfer codes'
                          : scope === 'domains:spend'
                            ? 'Register, transfer, and renew domains using your registrar funds'
                            : scope}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 break-all text-xs text-muted-foreground">
                  Workspace: {req.resource}
                </p>
              </div>
            )}
            <p className="text-xs text-muted-foreground">
              The same code is shown in the client&apos;s browser window — make
              sure they match.
            </p>

            <DialogFooter>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => void decide(req.id, false)}
                disabled={busy === req.id}
              >
                Deny
              </Button>
              <Button
                className="flex-1"
                onClick={() => void decide(req.id, true)}
                disabled={busy === req.id}
              >
                Approve
              </Button>
            </DialogFooter>

            {pending.length > 1 && (
              <p className="text-center text-xs text-muted-foreground">
                {pending.length - 1} more request
                {pending.length - 1 === 1 ? '' : 's'} waiting
              </p>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
