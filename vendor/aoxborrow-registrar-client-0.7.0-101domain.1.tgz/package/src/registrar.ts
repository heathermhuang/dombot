import { DEFAULT_OPTIONS } from './constants';
import { ConfigurationError, NotImplementedError } from './errors';
import { HttpClient, type HttpClientConfig } from './http';
import { CORE_FEATURES, FEATURE_CALLS, type RegistrarFeature } from './features';
import type {
  ConnectionResult,
  ContactSet,
  DnsRecord,
  Domain,
  DomainAvailability,
  DomainForward,
  DnssecStatus,
  EmailForward,
  ListDomainsOptions,
  OperationResult,
  Registrar,
  RegisterDomainInput,
  RegistrarClientOptions,
  RegistrarCredentials,
  RegistrarEnvironment,
  FeatureCall,
  RegistrarOptions,
  RequestOptions,
  TldPricing,
  TransferDomainInput,
} from './types';

// pick the base URL for the requested environment. Throws if `sandbox` is
// requested but the provider defines no sandbox URL — so integration tests
// fail loudly rather than silently hitting production.
export function selectBaseUrl(
  registrar: string,
  environment: RegistrarEnvironment | undefined,
  urls: { production: string; sandbox?: string }
): string {
  if (environment === 'sandbox') {
    if (!urls.sandbox) {
      throw new ConfigurationError(`${registrar} does not provide a sandbox environment`);
    }
    return urls.sandbox;
  }
  return urls.production;
}

// Abstract base for registrar providers. Owns the shared HTTP/auth/retry
// plumbing (via `HttpClient`) and provides `NotImplementedError`-rejecting
// defaults for every operation. Concrete providers extend this, build their
// base URL + auth from the credentials passed to `super()`, and override the
// operations their API supports.
export abstract class BaseRegistrar implements Registrar {
  abstract readonly name: string;

  protected http: HttpClient;
  protected credentials: RegistrarCredentials;
  protected options: RegistrarClientOptions;
  readonly environment: RegistrarEnvironment;

  // Extended capabilities this provider opts into, beyond the core contract.
  // Subclasses override this; core features are inherited and not re-declared.
  static readonly extendedFeatures: readonly RegistrarFeature[] = [];

  // The provider's full capability set: the core contract plus its extended
  // features. Available statically (no instance/credentials needed) for catalog
  // UIs and MCP tooling.
  static get features(): readonly RegistrarFeature[] {
    return [...CORE_FEATURES, ...this.extendedFeatures];
  }

  // HTTP methods this provider's API reserves for reads; see
  // `HttpClientConfig.safeMethods`. REST providers set `REST_SAFE_METHODS`.
  static readonly safeMethods: readonly string[] = [];

  // instance mirror of the static `features`
  get features(): readonly RegistrarFeature[] {
    return (this.constructor as typeof BaseRegistrar).features;
  }

  // whether this provider supports a given capability
  supports(feature: RegistrarFeature): boolean {
    return this.features.includes(feature);
  }

  // See Registrar.requiresNameserversFetch. Defaults true, so a provider
  // whose getNameservers hits a real endpoint keeps the enrichment fallback
  // without opting in; the providers whose getNameservers just re-reads getDomain
  // override this to false to drop the redundant call.
  readonly requiresNameserversFetch: boolean = true;

  constructor(
    credentials: RegistrarCredentials,
    httpConfig: Omit<HttpClientConfig, 'options'>,
    options?: RegistrarOptions
  ) {
    const { environment = 'production', ...clientOptions } = options ?? {};
    this.credentials = credentials;
    this.environment = environment;
    this.options = { ...DEFAULT_OPTIONS, ...clientOptions };
    this.http = new HttpClient({
      safeMethods: (this.constructor as typeof BaseRegistrar).safeMethods,
      ...httpConfig,
      options: this.options,
    });
    this.threadFeatureCalls();
  }

  // Wrap each feature method so its `RequestOptions` carry a `FeatureCall`:
  // the read/write intent the HTTP layer needs to decide what may be re-sent,
  // and a slot where it reports a write whose outcome is unknown. Providers
  // already forward their options into every request, so nothing else changes.
  //
  // A feature calling another feature (a write re-reading the domain, say)
  // goes through that feature's own wrapper, so the inner read is still a read.
  // Providers fold most failures into an `OperationResult`; the unknown outcome
  // is copied onto that result so it is not lost along with the error.
  private threadFeatureCalls(): void {
    const self = this as unknown as Record<string, unknown>;
    for (const [feature, { intent, optsIndex }] of Object.entries(FEATURE_CALLS)) {
      const original = self[feature];
      if (typeof original !== 'function') continue;
      // Not `async`: a provider that validates its arguments by throwing
      // synchronously keeps doing so.
      self[feature] = (...args: unknown[]): unknown => {
        const call: FeatureCall = { intent, feature };
        const next = [...args];
        while (next.length <= optsIndex) next.push(undefined);
        next[optsIndex] = { ...(next[optsIndex] as RequestOptions | undefined), call };
        const result: unknown = (original as (...a: unknown[]) => unknown).apply(this, next);
        if (!(result instanceof Promise)) return result;
        return result.then((value: unknown) =>
          call.outcomeUnknown &&
          value !== null &&
          typeof value === 'object' &&
          (value as OperationResult).success === false
            ? { ...value, outcome: 'unknown' }
            : value
        );
      };
    }
  }

  testConnection(_opts?: RequestOptions): Promise<ConnectionResult> {
    return Promise.reject(
      new NotImplementedError(`${this.name}: testConnection is not implemented`)
    );
  }

  listDomains(_opts?: ListDomainsOptions): Promise<Domain[]> {
    return Promise.reject(new NotImplementedError(`${this.name}: listDomains is not implemented`));
  }

  renewDomain(
    _domainName: string,
    _years?: number,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return Promise.reject(new NotImplementedError(`${this.name}: renewDomain is not implemented`));
  }

  updateNameservers(
    _domainName: string,
    _nameservers: string[],
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return Promise.reject(
      new NotImplementedError(`${this.name}: updateNameservers is not implemented`)
    );
  }

  lockDomain(_domainName: string, _opts?: RequestOptions): Promise<OperationResult> {
    return Promise.reject(new NotImplementedError(`${this.name}: lockDomain is not implemented`));
  }

  unlockDomain(_domainName: string, _opts?: RequestOptions): Promise<OperationResult> {
    return Promise.reject(new NotImplementedError(`${this.name}: unlockDomain is not implemented`));
  }

  getDomain(_domainName: string, _opts?: RequestOptions): Promise<Domain> {
    return this.notImplemented('getDomain');
  }

  checkAvailability(_domainNames: string[], _opts?: RequestOptions): Promise<DomainAvailability[]> {
    return this.notImplemented('checkAvailability');
  }

  getPricing(_tldOrDomain: string, _opts?: RequestOptions): Promise<TldPricing> {
    return this.notImplemented('getPricing');
  }

  registerDomain(
    _domainName: string,
    _input: RegisterDomainInput,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('registerDomain');
  }

  setAutoRenew(
    _domainName: string,
    _enabled: boolean,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('setAutoRenew');
  }

  transferIn(
    _domainName: string,
    _input: TransferDomainInput,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('transferIn');
  }

  getNameservers(_domainName: string, _opts?: RequestOptions): Promise<string[]> {
    return this.notImplemented('getNameservers');
  }

  setPrivacy(
    _domainName: string,
    _enabled: boolean,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('setPrivacy');
  }

  getContacts(_domainName: string, _opts?: RequestOptions): Promise<ContactSet> {
    return this.notImplemented('getContacts');
  }

  updateContacts(
    _domainName: string,
    _contacts: ContactSet,
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('updateContacts');
  }

  getDnsRecords(_domainName: string, _opts?: RequestOptions): Promise<DnsRecord[]> {
    return this.notImplemented('getDnsRecords');
  }

  setDnsRecords(
    _domainName: string,
    _records: DnsRecord[],
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('setDnsRecords');
  }

  // --- extended capabilities (opt-in; default to NotImplementedError) ---

  getEmailForwarding(_domainName: string, _opts?: RequestOptions): Promise<EmailForward[]> {
    return this.notImplemented('getEmailForwarding');
  }

  setEmailForwarding(
    _domainName: string,
    _forwards: EmailForward[],
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('setEmailForwarding');
  }

  getDomainForwarding(_domainName: string, _opts?: RequestOptions): Promise<DomainForward[]> {
    return this.notImplemented('getDomainForwarding');
  }

  setDomainForwarding(
    _domainName: string,
    _forwards: DomainForward[],
    _opts?: RequestOptions
  ): Promise<OperationResult> {
    return this.notImplemented('setDomainForwarding');
  }

  getAuthCode(_domainName: string, _opts?: RequestOptions): Promise<string> {
    return this.notImplemented('getAuthCode');
  }

  getDnssec(_domainName: string, _opts?: RequestOptions): Promise<DnssecStatus> {
    return this.notImplemented('getDnssec');
  }

  disableDnssec(_domainName: string, _opts?: RequestOptions): Promise<OperationResult> {
    return this.notImplemented('disableDnssec');
  }

  // shared rejection for a capability a provider hasn't wired up yet
  protected notImplemented(method: string): Promise<never> {
    return Promise.reject(new NotImplementedError(`${this.name}: ${method} is not implemented`));
  }
}
