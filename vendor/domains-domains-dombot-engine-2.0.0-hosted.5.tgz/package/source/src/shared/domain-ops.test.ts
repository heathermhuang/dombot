import { describe, it, expect } from 'vitest';

import {
  friendlyError,
  isApiUnsupportedMessage,
  missingFeatureReason,
  opSummary,
  reportsPrivacy,
  unsupportedReason,
} from './domain-ops';
import type { DomainOp, RegistrarName } from './ipc';

// A provider with every extended feature, and one with none.
const ALL = [
  'getAuthCode',
  'setDomainForwarding',
  'setEmailForwarding',
  'getDomainForwarding',
  'getEmailForwarding',
];
const NONE: string[] = [];

const ops: Record<string, DomainOp> = {
  autoOn: { kind: 'autoRenew', enabled: true },
  privacyOn: { kind: 'privacy', enabled: true },
  privacyOff: { kind: 'privacy', enabled: false },
  lock: { kind: 'lock', locked: true },
  ns: { kind: 'nameservers', nameservers: ['ns1.example.net'] },
  url: { kind: 'urlForwarding', forwards: [] },
  email: { kind: 'emailForwarding', forwards: [] },
  auth: { kind: 'authCode' },
  renew: { kind: 'renew', years: 1 },
};

describe('reportsPrivacy', () => {
  it('is false only for registrars whose API omits privacy', () => {
    expect(reportsPrivacy('101domain')).toBe(false);
    expect(reportsPrivacy('dynadot')).toBe(true);
  });
});

describe('unsupportedReason', () => {
  it('blocks unavailable 101domain mutations while allowing nameservers and permanent apex forwarding', () => {
    const features = ['getDomainForwarding', 'setDomainForwarding'];
    for (const op of [
      ops.autoOn,
      ops.privacyOn,
      ops.privacyOff,
      ops.lock,
      ops.renew,
    ])
      expect(unsupportedReason('101domain', features, op)).toMatch(/101domain/);
    expect(unsupportedReason('101domain', features, ops.ns)).toBeNull();
    expect(unsupportedReason('101domain', features, ops.auth)).toMatch(
      /auth code/,
    );
    expect(unsupportedReason('101domain', features, ops.email)).toMatch(
      /email forwarding/,
    );
    expect(
      unsupportedReason('101domain', features, {
        kind: 'urlForwarding',
        forwards: [
          { host: '@', type: 'permanent', url: 'https://example.net' },
        ],
      }),
    ).toBeNull();
    expect(
      unsupportedReason('101domain', features, {
        kind: 'urlForwarding',
        forwards: [
          { host: 'www', type: 'temporary', url: 'https://example.net' },
        ],
      }),
    ).toMatch(/domain root/);
  });
  it('allows every op on a fully-featured registrar with no known gaps', () => {
    for (const op of Object.values(ops)) {
      expect(unsupportedReason('dynadot', ALL, op)).toBeNull();
    }
  });

  it('gates extended-feature ops on the feature list', () => {
    expect(unsupportedReason('namecheap', NONE, ops.auth)).toMatch(/auth code/);
    expect(unsupportedReason('namecheap', NONE, ops.url)).toMatch(
      /URL forwarding/,
    );
    expect(unsupportedReason('namecheap', NONE, ops.email)).toMatch(
      /email forwarding/,
    );
    // Core ops don't need any extended feature.
    expect(unsupportedReason('namecheap', NONE, ops.autoOn)).toBeNull();
    expect(unsupportedReason('namecheap', NONE, ops.renew)).toBeNull();
  });

  it('knows Cloudflare has no post-registration update for four core ops', () => {
    for (const op of [ops.autoOn, ops.lock, ops.ns, ops.renew]) {
      expect(unsupportedReason('cloudflare', ALL, op)).toMatch(/Cloudflare/);
    }
    expect(unsupportedReason('cloudflare', ALL, ops.privacyOn)).toBeNull();
    expect(unsupportedReason('cloudflare', ALL, ops.url)).toBeNull();
  });

  it('knows Porkbun can’t change lock or privacy', () => {
    expect(unsupportedReason('porkbun', ALL, ops.lock)).toMatch(/Porkbun/);
    expect(unsupportedReason('porkbun', ALL, ops.privacyOff)).toMatch(
      /Porkbun/,
    );
    expect(unsupportedReason('porkbun', ALL, ops.autoOn)).toBeNull();
  });

  it('lets GoDaddy turn privacy on and off', () => {
    expect(unsupportedReason('godaddy', ALL, ops.privacyOn)).toBeNull();
    expect(unsupportedReason('godaddy', ALL, ops.privacyOff)).toBeNull();
    expect(unsupportedReason('godaddy', ALL, ops.auth)).toBeNull();
  });

  it('allows GoDaddy forwarding on an account whose Optional settings unlock it', () => {
    expect(unsupportedReason('godaddy', ALL, ops.url)).toBeNull();
    // Without them the account's list lacks it, and the reason says why.
    expect(unsupportedReason('godaddy', ['getAuthCode'], ops.url)).toBe(
      'Add this account’s Optional settings in Settings › Registrars to use URL forwarding.',
    );
  });

  it('names the Optional settings only for features they unlock', () => {
    expect(
      missingFeatureReason(
        'godaddy',
        'approveTransferOut',
        'transfer approval',
      ),
    ).toMatch(/Optional settings/);
    // GoDaddy has no email forwarding API at all.
    expect(
      missingFeatureReason('godaddy', 'setEmailForwarding', 'email forwarding'),
    ).toBe('This registrar doesn’t offer email forwarding through its API.');
    expect(
      missingFeatureReason('dynadot', 'setDomainForwarding', 'URL forwarding'),
    ).toBe('This registrar doesn’t offer URL forwarding through its API.');
  });

  it('checks the feature list before the gap map', () => {
    // GoDaddy without getAuthCode in its list → the feature reason wins.
    expect(unsupportedReason('godaddy', NONE, ops.auth)).toMatch(/auth code/);
  });

  it('has no gaps for registrars not in the map', () => {
    const rest: RegistrarName[] = [
      'gandi',
      'namebright',
      'namesilo',
      'spaceship',
    ];
    for (const r of rest) {
      for (const op of Object.values(ops)) {
        expect(unsupportedReason(r, ALL, op)).toBeNull();
      }
    }
  });
});

describe('opSummary', () => {
  it('phrases each op in the past tense', () => {
    expect(opSummary(ops.autoOn)).toBe('Auto-renew enabled');
    expect(opSummary(ops.privacyOff)).toBe('WHOIS privacy disabled');
    expect(opSummary(ops.lock)).toBe('Locked');
    expect(opSummary({ kind: 'lock', locked: false })).toBe('Unlocked');
    expect(opSummary(ops.ns)).toBe('Nameservers updated');
    expect(opSummary(ops.url)).toBe('URL forwarding cleared');
    expect(opSummary(ops.renew)).toBe('Renewed for 1 year');
    expect(opSummary({ kind: 'renew', years: 3 })).toBe('Renewed for 3 years');
  });
});

describe('friendlyError', () => {
  const wrapped = (body: string) =>
    `Request to 'https://api.example.com/x' failed with 400 Bad Request: ${body}`;

  it('digs the description out of a nested JSON error body', () => {
    expect(
      friendlyError(
        wrapped(
          '{"code":400,"message":"Bad Request","error":{"description":"This TLD isn\'t supported via the API."}}',
        ),
      ),
    ).toBe("This TLD isn't supported via the API.");
  });

  it('falls back to a top-level message', () => {
    expect(friendlyError(wrapped('{"message":"Domain not found"}'))).toBe(
      'Domain not found',
    );
  });

  it('returns a non-JSON body as-is', () => {
    expect(friendlyError(wrapped('Forbidden for this account'))).toBe(
      'Forbidden for this account',
    );
  });

  it('leaves messages that are not HTTP wrappers untouched', () => {
    expect(friendlyError('namecheap: example.com has no WhoisGuard')).toBe(
      'namecheap: example.com has no WhoisGuard',
    );
  });
});

describe('isApiUnsupportedMessage', () => {
  it('recognizes the registrar wording', () => {
    expect(
      isApiUnsupportedMessage("This TLD isn't supported via the API."),
    ).toBe(true);
    expect(isApiUnsupportedMessage('renewals are not yet in the API')).toBe(
      false,
    );
    expect(isApiUnsupportedMessage('Domain not found')).toBe(false);
  });
});
