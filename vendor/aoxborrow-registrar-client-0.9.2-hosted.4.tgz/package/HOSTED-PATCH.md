This private hosted fork is based on @aoxborrow/registrar-client 0.9.2 (MIT).
The upstream release remains 0.9.2; this is not an upstream-published version.

Dynadot .ai price-only renewal quotes use the mandatory two-year term and divide
the returned term fee by two to preserve TldPricing's annual estimate. Classic
quote rate-limit/transient errors retain their retry class instead of falling
through to another request. No paid renew/register implementation is changed.

The upstream source and unchanged public declarations are included. Rebuild JS:
esbuild src/index.ts --bundle --packages=external --platform=neutral --target=es2022 --format=esm --outfile=dist/index.js
esbuild src/index.ts --bundle --packages=external --platform=neutral --target=es2022 --format=cjs --outfile=dist/index.cjs

Security hardening in hosted.2 validates Gandi DNS domain names (including IDNA) and encodes path components, rejecting separators and empty/dot segments, and serializes Cloudflare forwarding-host expressions as quoted literals. Public declarations remain unchanged. Apply registrar-client-renewal-quotes.patch followed by registrar-client-path-literals.patch to upstream 0.9.2 source, set version 0.9.2-hosted.2, then run the ESM/CJS build commands above.

Hosted.4 uses the exact authenticated owned-domain renewalPrice when Core rejects .in per-name pricing with HTTP 422. Only GET requests are added; authentication/rate-limit/server failures and other TLDs retain their existing behavior. No generic TLD estimate or paid operation is used.
